'use client'

import { ReactNode, useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import VoltarInicio from '@/components/VoltarInicio'

type Empresa = {
  id: string
  nome: string
  slug: string
  logo_url?: string | null
  cor_primaria?: string | null
  cor_secundaria?: string | null
}

export default function PainelLayout({
  children,
}: {
  children: ReactNode
}) {
  const pathname = usePathname()

  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    carregarEmpresa()
  }, [])

  async function carregarEmpresa() {
    try {
      const slug =
        process.env.NEXT_PUBLIC_EMPRESA_SLUG_PADRAO || 'espaco-aurea'

      const res = await fetch(
        `${process.env.NEXT_PUBLIC_SUPABASE_URL}/rest/v1/empresas?slug=eq.${slug}&select=*`,
        {
          headers: {
            apikey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
            Authorization: `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`,
          },
        }
      )

      const data = await res.json()

      if (data?.length) {
        setEmpresa(data[0])
      }
    } catch (error) {
      console.error('Erro ao carregar empresa', error)
    } finally {
      setLoading(false)
    }
  }

  const corPrimaria = empresa?.cor_primaria || '#b8956f'
  const corSecundaria = empresa?.cor_secundaria || '#6f4b3d'

  const mostrarBotaoVoltar = pathname !== '/inicio'

  return (
    <div
      style={{
        minHeight: '100vh',
        background: '#f5f3f2',
      }}
    >
      {/* HEADER */}
      <header
        style={{
          background: '#ffffff',
          padding: '16px 24px',
          borderBottom: '1px solid #eee',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          {/* LOGO */}
          <div
            style={{
              width: 44,
              height: 44,
              borderRadius: 12,
              overflow: 'hidden',
              background: '#eee',
            }}
          >
            {empresa?.logo_url ? (
              <img
                src={empresa.logo_url}
                alt="logo"
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              />
            ) : (
              <div
                style={{
                  width: '100%',
                  height: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontWeight: 800,
                }}
              >
                {empresa?.nome?.charAt(0) || 'E'}
              </div>
            )}
          </div>

          {/* NOME */}
          <div>
            <div style={{ fontWeight: 800 }}>{empresa?.nome || 'Empresa'}</div>
            <div style={{ fontSize: 12, color: '#6b7280' }}>
              Painel administrativo
            </div>
          </div>
        </div>

        {/* DIREITA */}
        <div style={{ fontWeight: 600, color: '#374151' }}>
          Bem-vindo 👋
        </div>
      </header>

      {/* LINHA DE TEMA */}
      <div
        style={{
          height: 4,
          width: '100%',
          background: `linear-gradient(90deg, ${corSecundaria}, ${corPrimaria})`,
        }}
      />

      {/* CONTEÚDO */}
      <main
        style={{
          maxWidth: 1200,
          margin: '0 auto',
          padding: '24px 20px',
        }}
      >
        {/* BOTÃO VOLTAR */}
        {!loading && mostrarBotaoVoltar && (
          <div style={{ marginBottom: 16 }}>
            <VoltarInicio />
          </div>
        )}

        {/* CONTEÚDO DAS PÁGINAS */}
        {loading ? (
          <div
            style={{
              background: '#fff',
              padding: 24,
              borderRadius: 16,
              boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
            }}
          >
            Carregando painel...
          </div>
        ) : (
          children
        )}
      </main>
    </div>
  )
}