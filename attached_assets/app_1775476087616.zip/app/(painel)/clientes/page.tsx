'use client'

import React, { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import ProtegePagina from '@/components/ProtegePagina'
import ProtegeOnboarding from '@/components/ProtegeOnboarding'
import { useSessaoEmpresa } from '@/lib/useSessaoEmpresa'
import AppShell from '@/components/ui/AppShell'
import HeroHeader from '@/components/ui/HeroHeader'
import { ui } from '@/styles/tema'
import { getTemaEmpresa } from '@/lib/temaEmpresa'
import {
  botaoPrimarioTema,
  botaoSecundarioTema,
  cardTema,
} from '@/lib/temaStyles'

type Cliente = {
  id: string
  empresa_id?: string
  nome: string
  telefone: string
  email: string
  cep: string
  endereco: string
  numero: string
  complemento: string
  bairro: string
  data_nascimento: string
  created_at: string
}

type AnamneseCliente = {
  id?: string
  empresa_id: string
  cliente_id?: string
  diabetes: boolean
  gestante: boolean
  alergia_produtos: boolean
  alergia_descricao: string
  uso_medicacao: boolean
  medicacao_descricao: string
  sensibilidade_cutanea: boolean
  problema_circulatorio: boolean
  observacoes_gerais: string
}

type ViaCepResponse = {
  logradouro?: string
  bairro?: string
  erro?: boolean
}

type Aba = 'cadastro' | 'cadastrados' | 'busca'

function formatarNomePadrao(nome: string) {
  if (!nome) return ''

  const palavrasMinusculas = ['da', 'de', 'do', 'das', 'dos', 'e']

  return nome
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .map((palavra, index) => {
      if (index > 0 && palavrasMinusculas.includes(palavra)) {
        return palavra
      }

      return palavra.charAt(0).toUpperCase() + palavra.slice(1)
    })
    .join(' ')
}

export default function ClientesPage() {
  return (
    <ProtegePagina>
      <ProtegeOnboarding>
        <ClientesConteudo />
      </ProtegeOnboarding>
    </ProtegePagina>
  )
}

function ClientesConteudo() {
  const { empresa, loading } = useSessaoEmpresa()
  const tema = getTemaEmpresa(empresa)

  const empresaId = empresa?.id || ''
  const empresaNome = empresa?.nome || 'Empresa'

  const [clientes, setClientes] = useState<Cliente[]>([])
  const [resultadoBusca, setResultadoBusca] = useState<Cliente[]>([])
  const [busca, setBusca] = useState('')
  const [editandoId, setEditandoId] = useState<string | null>(null)
  const [abaAtiva, setAbaAtiva] = useState<Aba>('cadastrados')

  const [nome, setNome] = useState('')
  const [telefone, setTelefone] = useState('')
  const [email, setEmail] = useState('')
  const [cep, setCep] = useState('')
  const [endereco, setEndereco] = useState('')
  const [numero, setNumero] = useState('')
  const [complemento, setComplemento] = useState('')
  const [bairro, setBairro] = useState('')
  const [dataNascimento, setDataNascimento] = useState('')

  const [diabetes, setDiabetes] = useState(false)
  const [gestante, setGestante] = useState(false)
  const [alergiaProdutos, setAlergiaProdutos] = useState(false)
  const [alergiaDescricao, setAlergiaDescricao] = useState('')
  const [usoMedicacao, setUsoMedicacao] = useState(false)
  const [medicacaoDescricao, setMedicacaoDescricao] = useState('')
  const [sensibilidadeCutanea, setSensibilidadeCutanea] = useState(false)
  const [problemaCirculatorio, setProblemaCirculatorio] = useState(false)
  const [observacoesGerais, setObservacoesGerais] = useState('')

  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')

  useEffect(() => {
    if (!empresaId) return
    buscarClientes()
  }, [empresaId])

  async function buscarClientes() {
    if (!empresaId) return

    const { data, error } = await supabase
      .from('clientes')
      .select('*')
      .eq('empresa_id', empresaId)
      .order('created_at', { ascending: false })

    if (error) {
      setErro('Não foi possível carregar os clientes.')
      return
    }

    setClientes((data || []) as Cliente[])
  }

  async function buscarClientesPorNome() {
    if (!empresaId) return

    let query = supabase
      .from('clientes')
      .select('*')
      .eq('empresa_id', empresaId)
      .order('nome')

    if (busca.trim()) {
      query = query.ilike('nome', `%${busca.trim()}%`)
    }

    const { data, error } = await query

    if (error) {
      setErro('Não foi possível realizar a busca.')
      return
    }

    setResultadoBusca((data || []) as Cliente[])
  }

  function limparMensagens() {
    setErro('')
    setSucesso('')
  }

  function limparFormulario() {
    setNome('')
    setTelefone('')
    setEmail('')
    setCep('')
    setEndereco('')
    setNumero('')
    setComplemento('')
    setBairro('')
    setDataNascimento('')
    setEditandoId(null)

    setDiabetes(false)
    setGestante(false)
    setAlergiaProdutos(false)
    setAlergiaDescricao('')
    setUsoMedicacao(false)
    setMedicacaoDescricao('')
    setSensibilidadeCutanea(false)
    setProblemaCirculatorio(false)
    setObservacoesGerais('')
  }

  async function consultarCEP(valor: string) {
    const cepLimpo = valor.replace(/\D/g, '')
    if (cepLimpo.length !== 8) return

    try {
      const res = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`)
      const data: ViaCepResponse = await res.json()

      if (!data.erro) {
        setEndereco(data.logradouro || '')
        setBairro(data.bairro || '')
      }
    } catch (error) {
      console.error(error)
    }
  }

  async function salvarCliente(e: React.FormEvent) {
    e.preventDefault()
    limparMensagens()

    if (!empresaId) {
      setErro('Empresa não identificada.')
      return
    }

    const payloadCliente = {
      empresa_id: empresaId,
      nome: formatarNomePadrao(nome),
      telefone,
      email,
      cep,
      endereco,
      numero,
      complemento,
      bairro,
      data_nascimento: dataNascimento || null,
    }

    try {
      let clienteSalvaId = editandoId

      if (editandoId) {
        const { error } = await supabase
          .from('clientes')
          .update(payloadCliente)
          .eq('id', editandoId)
          .eq('empresa_id', empresaId)

        if (error) {
          setErro('Não foi possível atualizar a cliente.')
          return
        }
      } else {
        const { data, error } = await supabase
          .from('clientes')
          .insert([payloadCliente])
          .select()
          .single()

        if (error || !data) {
          setErro('Não foi possível salvar a cliente.')
          return
        }

        clienteSalvaId = data.id
      }

      if (!clienteSalvaId) {
        setErro('Não foi possível identificar a cliente salva.')
        return
      }

      const payloadAnamnese: AnamneseCliente = {
        empresa_id: empresaId,
        cliente_id: clienteSalvaId,
        diabetes,
        gestante,
        alergia_produtos: alergiaProdutos,
        alergia_descricao: alergiaDescricao || '',
        uso_medicacao: usoMedicacao,
        medicacao_descricao: medicacaoDescricao || '',
        sensibilidade_cutanea: sensibilidadeCutanea,
        problema_circulatorio: problemaCirculatorio,
        observacoes_gerais: observacoesGerais || '',
      }

      const { error: anamneseError } = await supabase
        .from('anamnese_clientes')
        .upsert([payloadAnamnese], {
          onConflict: 'cliente_id',
        })

      if (anamneseError) {
        setErro('Cliente salva, mas houve erro ao salvar a anamnese.')
        return
      }

      setSucesso(
        editandoId
          ? 'Cliente atualizada com sucesso.'
          : 'Cliente cadastrada com sucesso.'
      )

      limparFormulario()
      await buscarClientes()
      setAbaAtiva('cadastrados')
    } catch (error) {
      console.error(error)
      setErro('Ocorreu um erro ao salvar a cliente.')
    }
  }

  async function carregarAnamneseCliente(clienteId: string) {
    const { data: anamnese } = await supabase
      .from('anamnese_clientes')
      .select('*')
      .eq('cliente_id', clienteId)
      .maybeSingle()

    if (anamnese) {
      setDiabetes(!!anamnese.diabetes)
      setGestante(!!anamnese.gestante)
      setAlergiaProdutos(!!anamnese.alergia_produtos)
      setAlergiaDescricao(anamnese.alergia_descricao || '')
      setUsoMedicacao(!!anamnese.uso_medicacao)
      setMedicacaoDescricao(anamnese.medicacao_descricao || '')
      setSensibilidadeCutanea(!!anamnese.sensibilidade_cutanea)
      setProblemaCirculatorio(!!anamnese.problema_circulatorio)
      setObservacoesGerais(anamnese.observacoes_gerais || '')
    } else {
      setDiabetes(false)
      setGestante(false)
      setAlergiaProdutos(false)
      setAlergiaDescricao('')
      setUsoMedicacao(false)
      setMedicacaoDescricao('')
      setSensibilidadeCutanea(false)
      setProblemaCirculatorio(false)
      setObservacoesGerais('')
    }
  }

  async function editarCliente(cliente: Cliente) {
    setEditandoId(cliente.id)
    setNome(cliente.nome || '')
    setTelefone(cliente.telefone || '')
    setEmail(cliente.email || '')
    setCep(cliente.cep || '')
    setEndereco(cliente.endereco || '')
    setNumero(cliente.numero || '')
    setComplemento(cliente.complemento || '')
    setBairro(cliente.bairro || '')
    setDataNascimento(
      cliente.data_nascimento ? cliente.data_nascimento.split('T')[0] : ''
    )

    await carregarAnamneseCliente(cliente.id)

    setAbaAtiva('cadastro')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function formatarDataCadastro(dataISO: string) {
    if (!dataISO) return ''

    try {
      const dataCorreta = dataISO.endsWith('Z')
        ? dataISO
        : dataISO.split('+')[0] + 'Z'

      return new Intl.DateTimeFormat('pt-BR', {
        timeZone: 'America/Sao_Paulo',
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      }).format(new Date(dataCorreta))
    } catch {
      return 'Data inválida'
    }
  }

  async function excluirCliente(id: string) {
    if (!empresaId) return

    const confirmado = window.confirm('Excluir esta cliente?')
    if (!confirmado) return

    const { error: deleteAnamneseError } = await supabase
      .from('anamnese_clientes')
      .delete()
      .eq('cliente_id', id)

    if (deleteAnamneseError) {
      console.error(deleteAnamneseError)
    }

    const { error } = await supabase
      .from('clientes')
      .delete()
      .eq('id', id)
      .eq('empresa_id', empresaId)

    if (error) {
      setErro('Não foi possível excluir a cliente.')
      return
    }

    setSucesso('Cliente excluída com sucesso.')
    await buscarClientes()

    if (abaAtiva === 'busca') {
      await buscarClientesPorNome()
    }
  }

  if (loading) {
    return (
      <AppShell>
        <div style={cardTema(tema)}>
          <h2 style={ui.sectionTitle}>Carregando empresa...</h2>
        </div>
      </AppShell>
    )
  }

  if (!empresaId) {
    return (
      <AppShell>
        <div style={cardTema(tema)}>
          <h2 style={ui.sectionTitle}>Empresa não identificada.</h2>
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell>
      <HeroHeader
        titulo="Clientes"
        subtitulo={`Cadastro e gestão de clientes • ${empresaNome}`}
        eyebrow="CRM do salão"
      />

      {(erro || sucesso) && (
        <div style={s.noticeWrap}>
          {erro ? <div style={s.erro}>{erro}</div> : null}
          {sucesso ? <div style={s.sucesso}>{sucesso}</div> : null}
        </div>
      )}

      <div style={{ ...ui.tabsWrap, marginTop: 10 }}>
        <button
          type="button"
          onClick={() => {
            setAbaAtiva('cadastro')
            limparFormulario()
            limparMensagens()
          }}
          style={abaAtiva === 'cadastro' ? botaoPrimarioTema(tema) : botaoSecundarioTema(tema)}
        >
          ➕ Novo
        </button>

        <button
          type="button"
          onClick={() => {
            setAbaAtiva('cadastrados')
            limparMensagens()
          }}
          style={abaAtiva === 'cadastrados' ? botaoPrimarioTema(tema) : botaoSecundarioTema(tema)}
        >
          📋 Cadastrados
        </button>

        <button
          type="button"
          onClick={() => {
            setAbaAtiva('busca')
            limparMensagens()
          }}
          style={abaAtiva === 'busca' ? botaoPrimarioTema(tema) : botaoSecundarioTema(tema)}
        >
          🔍 Busca
        </button>
      </div>

      {abaAtiva === 'cadastro' && (
        <div style={cardTema(tema)}>
          <div style={s.sectionHeader}>
            <div style={s.sectionTitleWrap}>
              <h2 style={ui.sectionTitle}>
                {editandoId ? 'Editar cliente' : 'Novo cliente'}
              </h2>
              <p style={ui.sectionSub}>
                Cadastre clientes com dados principais e ficha de anamnese.
              </p>
            </div>
          </div>

          <form onSubmit={salvarCliente} style={s.form}>
            <div style={s.fieldFull}>
              <label style={ui.label}>Nome da cliente *</label>
              <input
                value={nome}
                onChange={e => setNome(e.target.value)}
                style={ui.input}
                required
              />
            </div>

            <div style={s.gridDois}>
              <div style={s.field}>
                <label style={ui.label}>Telefone *</label>
                <input
                  value={telefone}
                  onChange={e => setTelefone(e.target.value)}
                  style={ui.input}
                  required
                />
              </div>

              <div style={s.field}>
                <label style={ui.label}>Data de nascimento</label>
                <input
                  type="date"
                  value={dataNascimento}
                  onChange={e => setDataNascimento(e.target.value)}
                  style={ui.input}
                />
              </div>
            </div>

            <div style={s.fieldFull}>
              <label style={ui.label}>E-mail</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                style={ui.input}
              />
            </div>

            <div style={s.gridDois}>
              <div style={s.field}>
                <label style={ui.label}>CEP</label>
                <input
                  value={cep}
                  onBlur={e => consultarCEP(e.target.value)}
                  onChange={e => setCep(e.target.value)}
                  style={ui.input}
                  placeholder="00000-000"
                />
              </div>

              <div style={s.field}>
                <label style={ui.label}>Bairro</label>
                <input
                  value={bairro}
                  onChange={e => setBairro(e.target.value)}
                  style={ui.input}
                />
              </div>
            </div>

            <div style={s.gridEnder}>
              <div style={{ flex: 3, display: 'grid', gap: 8 }}>
                <label style={ui.label}>Endereço</label>
                <input
                  value={endereco}
                  onChange={e => setEndereco(e.target.value)}
                  style={ui.input}
                />
              </div>

              <div style={{ flex: 1, display: 'grid', gap: 8 }}>
                <label style={ui.label}>Nº</label>
                <input
                  value={numero}
                  onChange={e => setNumero(e.target.value)}
                  style={ui.input}
                />
              </div>
            </div>

            <div style={s.fieldFull}>
              <label style={ui.label}>Complemento</label>
              <input
                value={complemento}
                onChange={e => setComplemento(e.target.value)}
                style={ui.input}
              />
            </div>

            <div
              style={{
                ...cardTema(tema),
                borderLeft: `4px solid ${tema.corPrimaria}`,
                marginTop: 8,
              }}
            >
              <h3 style={{ marginTop: 0, marginBottom: 14 }}>Ficha de anamnese</h3>

              <div style={{ display: 'grid', gap: 12 }}>
                <label style={s.checkLabel}>
                  <input
                    type="checkbox"
                    checked={diabetes}
                    onChange={e => setDiabetes(e.target.checked)}
                  />
                  Possui diabetes
                </label>

                <label style={s.checkLabel}>
                  <input
                    type="checkbox"
                    checked={gestante}
                    onChange={e => setGestante(e.target.checked)}
                  />
                  Gestante
                </label>

                <label style={s.checkLabel}>
                  <input
                    type="checkbox"
                    checked={alergiaProdutos}
                    onChange={e => setAlergiaProdutos(e.target.checked)}
                  />
                  Alergia a produtos
                </label>

                {alergiaProdutos && (
                  <input
                    value={alergiaDescricao}
                    onChange={e => setAlergiaDescricao(e.target.value)}
                    style={ui.input}
                    placeholder="Descreva a alergia"
                  />
                )}

                <label style={s.checkLabel}>
                  <input
                    type="checkbox"
                    checked={usoMedicacao}
                    onChange={e => setUsoMedicacao(e.target.checked)}
                  />
                  Usa medicação contínua
                </label>

                {usoMedicacao && (
                  <input
                    value={medicacaoDescricao}
                    onChange={e => setMedicacaoDescricao(e.target.value)}
                    style={ui.input}
                    placeholder="Descreva a medicação"
                  />
                )}

                <label style={s.checkLabel}>
                  <input
                    type="checkbox"
                    checked={sensibilidadeCutanea}
                    onChange={e => setSensibilidadeCutanea(e.target.checked)}
                  />
                  Sensibilidade cutânea
                </label>

                <label style={s.checkLabel}>
                  <input
                    type="checkbox"
                    checked={problemaCirculatorio}
                    onChange={e => setProblemaCirculatorio(e.target.checked)}
                  />
                  Problema circulatório
                </label>

                <div style={s.fieldFull}>
                  <label style={ui.label}>Observações gerais</label>
                  <textarea
                    value={observacoesGerais}
                    onChange={e => setObservacoesGerais(e.target.value)}
                    style={{ ...ui.input, minHeight: 100, resize: 'vertical' }}
                    placeholder="Observações importantes para o atendimento"
                  />
                </div>
              </div>
            </div>

            <div style={s.actionsRow}>
              <button type="submit" style={botaoPrimarioTema(tema)}>
                {editandoId ? 'Atualizar cliente' : 'Salvar cadastro'}
              </button>

              <button
                type="button"
                style={botaoSecundarioTema(tema)}
                onClick={limparFormulario}
              >
                Limpar campos
              </button>
            </div>
          </form>
        </div>
      )}

      {abaAtiva === 'cadastrados' && (
        <div style={s.gridClientes}>
          {clientes.map(c => (
            <div
              key={c.id}
              style={{
                ...cardTema(tema),
                ...s.cardPremium,
                borderLeft: `4px solid ${tema.corPrimaria}`,
              }}
              onMouseEnter={e => {
                e.currentTarget.style.transform = 'translateY(-4px)'
                e.currentTarget.style.boxShadow = '0 10px 25px rgba(0,0,0,0.08)'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.transform = 'translateY(0)'
                e.currentTarget.style.boxShadow = '0 6px 18px rgba(0,0,0,0.06)'
              }}
            >
              <div style={s.clienteCardHeader}>
                <strong style={s.nomeCliente}>{formatarNomePadrao(c.nome)}</strong>

                <div style={s.btnMiniWrap}>
                  <button
                    onClick={() => editarCliente(c)}
                    style={s.btnMini}
                    type="button"
                    title="Editar"
                  >
                    ✏️
                  </button>

                  <button
                    onClick={() => excluirCliente(c.id)}
                    style={s.btnMini}
                    type="button"
                    title="Excluir"
                  >
                    🗑️
                  </button>
                </div>
              </div>

              <div style={s.infoBox}>
                <p style={{ ...s.textoInfo, fontWeight: 600 }}>
                  📞 {c.telefone || '-'}
                </p>

                <p style={s.textoInfo}>
                  🎂{' '}
                  {c.data_nascimento
                    ? new Date(
                        c.data_nascimento.split('T')[0] + 'T00:00:00'
                      ).toLocaleDateString('pt-BR')
                    : '--/--'}
                </p>

                <p style={s.textoInfo}>
                  📍 {c.endereco || 'S/E'}
                  {c.numero ? `, ${c.numero}` : ''}
                  {c.bairro ? ` ${c.bairro}` : ''}
                </p>
              </div>

              <p style={s.dataCadastro}>🕒 {formatarDataCadastro(c.created_at)}</p>
            </div>
          ))}
        </div>
      )}

      {abaAtiva === 'busca' && (
        <div style={cardTema(tema)}>
          <div style={s.buscaTop}>
            <input
              placeholder="Digite o nome..."
              value={busca}
              onChange={e => setBusca(e.target.value)}
              style={{ ...ui.input, flex: 1 }}
            />
            <button
              onClick={buscarClientesPorNome}
              style={botaoPrimarioTema(tema)}
              type="button"
            >
              Buscar
            </button>
          </div>

          <div style={s.gridClientesBusca}>
            {resultadoBusca.map(c => (
              <div
                style={{
                  ...cardTema(tema),
                  borderLeft: `4px solid ${tema.corPrimaria}`,
                }}
                key={c.id}
              >
                <div style={s.clienteCardHeader}>
                  <strong style={s.nomeClienteBusca}>
                    {formatarNomePadrao(c.nome)}
                  </strong>

                  <div style={s.btnMiniWrap}>
                    <button
                      onClick={() => editarCliente(c)}
                      style={s.btnMini}
                      type="button"
                      title="Editar"
                    >
                      ✏️
                    </button>

                    <button
                      onClick={() => excluirCliente(c.id)}
                      style={s.btnMini}
                      type="button"
                      title="Excluir"
                    >
                      🗑️
                    </button>
                  </div>
                </div>

                <div style={s.infoBox}>
                  <p style={{ ...s.textoInfo, fontWeight: 600 }}>
                    📞 {c.telefone || '-'}
                  </p>

                  <p style={s.textoInfo}>
                    🎂{' '}
                    {c.data_nascimento
                      ? new Date(
                          c.data_nascimento.split('T')[0] + 'T00:00:00'
                        ).toLocaleDateString('pt-BR')
                      : '--/--'}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </AppShell>
  )
}

const s: Record<string, React.CSSProperties> = {
  noticeWrap: {
    display: 'grid',
    gap: 12,
    marginTop: 10,
  },
  erro: {
    background: '#fff2f1',
    border: '1px solid #ffd1cd',
    color: '#a33227',
    padding: '14px 16px',
    borderRadius: 16,
    fontWeight: 600,
  },
  sucesso: {
    background: '#eefbf2',
    border: '1px solid #c7eed3',
    color: '#16643b',
    padding: '14px 16px',
    borderRadius: 16,
    fontWeight: 600,
  },
  sectionHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 14,
    flexWrap: 'wrap',
    marginBottom: 18,
  },
  sectionTitleWrap: {
    display: 'grid',
    gap: 4,
  },
  form: {
    display: 'grid',
    gap: 16,
  },
  field: {
    display: 'grid',
    gap: 8,
  },
  fieldFull: {
    display: 'grid',
    gap: 8,
  },
  gridDois: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 16,
  },
  gridEnder: {
    display: 'flex',
    gap: 16,
  },
  actionsRow: {
    display: 'flex',
    gap: 12,
    flexWrap: 'wrap',
    marginTop: 8,
  },
  gridClientes: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
    gap: 20,
  },
  gridClientesBusca: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
    gap: 16,
    marginTop: 20,
  },
  cardPremium: {
    borderRadius: 16,
    padding: 18,
    boxShadow: '0 6px 18px rgba(0,0,0,0.06)',
    transition: 'all 0.2s ease',
  },
  clienteCardHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 12,
  },
  nomeCliente: {
    fontSize: 20,
    color: '#3a2f28',
    fontWeight: 600,
    lineHeight: 1.2,
  },
  nomeClienteBusca: {
    fontSize: 16,
    color: '#3a2f28',
    fontWeight: 600,
  },
  infoBox: {
    marginTop: 12,
    display: 'grid',
    gap: 8,
  },
  textoInfo: {
    margin: 0,
    fontSize: 13,
    color: '#7b6858',
  },
  dataCadastro: {
    margin: '15px 0 0',
    fontSize: 12,
    color: '#a08b7a',
    fontStyle: 'italic',
    borderTop: '1px solid #f1e7de',
    paddingTop: '10px',
  },
  btnMiniWrap: {
    display: 'flex',
    gap: 8,
  },
  btnMini: {
    background: '#f9f6f2',
    border: '1px solid #eee',
    borderRadius: 10,
    padding: '6px 9px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
  buscaTop: {
    display: 'flex',
    gap: 12,
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  checkLabel: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    fontSize: 14,
    color: '#57493f',
    fontWeight: 500,
  },
}