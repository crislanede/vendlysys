'use client'

import { useEffect, useState } from 'react'
import VoltarInicio from '@/components/VoltarInicio'

type UsuarioEmpresa = {
  id: string
  auth_user_id: string
  empresa_id: string
  nome: string
  email: string
  perfil: 'admin' | 'agenda' | string
  ativo: boolean
}

type Empresa = {
  id: string
  nome: string
  slug: string
  cor_primaria?: string | null
  cor_secundaria?: string | null
}

export default function UsuariosPage() {
  const [usuarios, setUsuarios] = useState<UsuarioEmpresa[]>([])
  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [loading, setLoading] = useState(true)

  const [nome, setNome] = useState('')
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')
  const [perfil, setPerfil] = useState('agenda')

  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')
  const [salvando, setSalvando] = useState(false)

  useEffect(() => {
    carregarUsuarios()
  }, [])

  async function carregarUsuarios() {
    try {
      setLoading(true)
      setErro('')
      setSucesso('')

      const baseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
      const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
      const slug =
        process.env.NEXT_PUBLIC_EMPRESA_SLUG_PADRAO || 'espaco-aurea'

      if (!baseUrl || !anonKey) {
        throw new Error('Variáveis do Supabase não configuradas.')
      }

      const headers = {
        apikey: anonKey,
        Authorization: `Bearer ${anonKey}`,
      }

      const empresaRes = await fetch(
        `${baseUrl}/rest/v1/empresas?slug=eq.${slug}&select=id,nome,slug,cor_primaria,cor_secundaria&limit=1`,
        { headers, cache: 'no-store' }
      )

      if (!empresaRes.ok) {
        const texto = await empresaRes.text()
        throw new Error(`Erro ao buscar empresa: ${texto}`)
      }

      const empresaData: Empresa[] = await empresaRes.json()

      if (!empresaData.length) {
        throw new Error('Empresa não encontrada.')
      }

      const empresaAtual = empresaData[0]
      setEmpresa(empresaAtual)

      const usuariosRes = await fetch(
        `${baseUrl}/rest/v1/usuarios_empresa?empresa_id=eq.${empresaAtual.id}&select=id,auth_user_id,empresa_id,nome,email,perfil,ativo&order=nome.asc`,
        { headers, cache: 'no-store' }
      )

      if (!usuariosRes.ok) {
        const texto = await usuariosRes.text()
        throw new Error(`Erro ao buscar usuários: ${texto}`)
      }

      const usuariosData: UsuarioEmpresa[] = await usuariosRes.json()
      setUsuarios(usuariosData)
    } catch (err: any) {
      setErro(err?.message || 'Erro ao carregar usuários.')
    } finally {
      setLoading(false)
    }
  }

  async function criarUsuario() {
    try {
      setErro('')
      setSucesso('')
      setSalvando(true)

      if (!empresa?.id) {
        throw new Error('Empresa não encontrada.')
      }

      if (!nome || !email || !senha || !perfil) {
        throw new Error('Preencha nome, email, senha e perfil.')
      }

      const res = await fetch('/api/usuarios/criar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nome,
          email,
          senha,
          perfil,
          empresa_id: empresa.id,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data?.error || 'Erro ao criar usuário.')
      }

      setSucesso('Usuário criado com sucesso! 🎉')
      setNome('')
      setEmail('')
      setSenha('')
      setPerfil('agenda')

      await carregarUsuarios()
    } catch (err: any) {
      setErro(err?.message || 'Erro ao criar usuário.')
    } finally {
      setSalvando(false)
    }
  }

  async function alternarStatus(usuario: UsuarioEmpresa) {
    try {
      setErro('')
      setSucesso('')

      const baseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
      const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      if (!baseUrl || !anonKey) {
        throw new Error('Variáveis do Supabase não configuradas.')
      }

      const headers = {
        apikey: anonKey,
        Authorization: `Bearer ${anonKey}`,
        'Content-Type': 'application/json',
      }

      const res = await fetch(
        `${baseUrl}/rest/v1/usuarios_empresa?id=eq.${usuario.id}`,
        {
          method: 'PATCH',
          headers,
          body: JSON.stringify({
            ativo: !usuario.ativo,
          }),
        }
      )

      if (!res.ok) {
        const texto = await res.text()
        throw new Error(`Erro ao atualizar status: ${texto}`)
      }

      setSucesso(
        usuario.ativo
          ? 'Usuário desativado com sucesso.'
          : 'Usuário ativado com sucesso.'
      )

      await carregarUsuarios()
    } catch (err: any) {
      setErro(err?.message || 'Erro ao alterar status.')
    }
  }

  async function resetarSenha(usuario: UsuarioEmpresa) {
    try {
      setErro('')
      setSucesso('')

      const novaSenha = window.prompt(
        `Digite a nova senha para ${usuario.nome}:`
      )

      if (!novaSenha) return

      if (novaSenha.length < 6) {
        throw new Error('A nova senha deve ter pelo menos 6 caracteres.')
      }

      const res = await fetch('/api/usuarios/resetar-senha', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: usuario.auth_user_id,
          nova_senha: novaSenha,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data?.error || 'Erro ao resetar senha.')
      }

      setSucesso(`Senha de ${usuario.nome} redefinida com sucesso.`)
    } catch (err: any) {
      setErro(err?.message || 'Erro ao resetar senha.')
    }
  }

  const corPrimaria = empresa?.cor_primaria || '#b8956f'
  const corSecundaria = empresa?.cor_secundaria || '#6f4b3d'

  if (loading) {
    return <div style={boxStyle}>Carregando usuários...</div>
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <section
        style={{
          ...boxStyle,
          borderTop: `5px solid ${corPrimaria}`,
          background: `linear-gradient(180deg, #ffffff 0%, #fcfaf9 100%)`,
        }}
      >
        <p
          style={{
            margin: 0,
            fontSize: 12,
            fontWeight: 800,
            letterSpacing: 1,
            textTransform: 'uppercase',
            color: '#6b7280',
          }}
        >
          Usuários
        </p>

        <h1
          style={{
            margin: '8px 0 0 0',
            fontSize: 32,
            color: '#111827',
          }}
        >
          Gestão de acessos
        </h1>

        <p
          style={{
            margin: '8px 0 0 0',
            fontSize: 15,
            color: '#6b7280',
          }}
        >
          Crie usuários internos, defina perfis e controle o acesso ao sistema.
        </p>
      </section>

      <section style={boxStyle}>
        <h2 style={secaoTituloStyle}>Criar novo usuário</h2>

        <div style={gridStyle}>
          <div>
            <label style={labelStyle}>Nome</label>
            <input
              placeholder="Nome do usuário"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              style={inputStyle}
            />
          </div>

          <div>
            <label style={labelStyle}>Email</label>
            <input
              placeholder="email@empresa.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={inputStyle}
            />
          </div>

          <div>
            <label style={labelStyle}>Senha provisória</label>
            <input
              placeholder="Digite uma senha"
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              style={inputStyle}
            />
          </div>

          <div>
            <label style={labelStyle}>Perfil</label>
            <select
              value={perfil}
              onChange={(e) => setPerfil(e.target.value)}
              style={inputStyle}
            >
              <option value="agenda">Agenda</option>
              <option value="admin">Admin</option>
            </select>
          </div>
        </div>

        {erro ? <div style={erroStyle}>{erro}</div> : null}
        {sucesso ? <div style={sucessoStyle}>{sucesso}</div> : null}

        <div style={{ marginTop: 20 }}>
          <button
            onClick={criarUsuario}
            style={{
              ...botaoPrimarioStyle,
              background: `linear-gradient(135deg, ${corSecundaria}, ${corPrimaria})`,
              opacity: salvando ? 0.7 : 1,
            }}
            disabled={salvando}
          >
            {salvando ? 'Criando...' : 'Criar usuário'}
          </button>
        </div>
      </section>

      <section style={boxStyle}>
        <div style={secaoHeaderStyle}>
          <div>
            <h2 style={secaoTituloStyle}>Usuários da empresa</h2>
            <p style={secaoTextoStyle}>
              Gerencie perfis, status e redefinição de senha.
            </p>
          </div>
        </div>

        <div style={{ display: 'grid', gap: 14 }}>
          {usuarios.length === 0 ? (
            <div style={vazioStyle}>Nenhum usuário cadastrado ainda.</div>
          ) : (
            usuarios.map((u) => (
              <div
                key={u.id}
                style={{
                  background: '#f9fafb',
                  borderRadius: 16,
                  padding: 18,
                  border: '1px solid #ececec',
                  display: 'grid',
                  gridTemplateColumns: '1.5fr 1.5fr 0.8fr 0.8fr 1.5fr',
                  gap: 12,
                  alignItems: 'center',
                }}
              >
                <div>
                  <div style={itemLabelStyle}>Nome</div>
                  <div style={itemValorStyle}>{u.nome}</div>
                </div>

                <div>
                  <div style={itemLabelStyle}>Email</div>
                  <div style={itemValorStyle}>{u.email}</div>
                </div>

                <div>
                  <div style={itemLabelStyle}>Perfil</div>
                  <div style={itemValorStyle}>{u.perfil}</div>
                </div>

                <div>
                  <div style={itemLabelStyle}>Status</div>
                  <div
                    style={{
                      ...badgeStatusStyle,
                      background: u.ativo ? '#ecfdf3' : '#fef2f2',
                      color: u.ativo ? '#166534' : '#b91c1c',
                      borderColor: u.ativo ? '#bbf7d0' : '#fecaca',
                    }}
                  >
                    {u.ativo ? 'Ativo' : 'Inativo'}
                  </div>
                </div>

                <div
                  style={{
                    display: 'flex',
                    gap: 8,
                    justifyContent: 'flex-end',
                    flexWrap: 'wrap',
                  }}
                >
                  <button
                    onClick={() => resetarSenha(u)}
                    style={botaoSecundarioStyle}
                  >
                    Resetar senha
                  </button>

                  <button
                    onClick={() => alternarStatus(u)}
                    style={{
                      ...botaoSecundarioStyle,
                      borderColor: u.ativo ? '#fecaca' : '#bbf7d0',
                      color: u.ativo ? '#b91c1c' : '#166534',
                    }}
                  >
                    {u.ativo ? 'Desativar' : 'Ativar'}
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  )
}

const boxStyle: React.CSSProperties = {
  background: '#ffffff',
  borderRadius: 20,
  padding: 24,
  boxShadow: '0 4px 14px rgba(0,0,0,0.06)',
}

const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
  gap: 16,
}

const labelStyle: React.CSSProperties = {
  display: 'block',
  marginBottom: 8,
  fontSize: 14,
  fontWeight: 700,
  color: '#374151',
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  border: '1px solid #d1d5db',
  borderRadius: 12,
  padding: '12px 14px',
  fontSize: 14,
  background: '#fff',
  outline: 'none',
}

const botaoPrimarioStyle: React.CSSProperties = {
  border: 0,
  color: '#ffffff',
  padding: '12px 18px',
  borderRadius: 14,
  cursor: 'pointer',
  fontWeight: 800,
  boxShadow: '0 8px 20px rgba(45,36,31,0.16)',
}

const botaoSecundarioStyle: React.CSSProperties = {
  border: '1px solid #d1d5db',
  background: '#ffffff',
  color: '#374151',
  padding: '10px 14px',
  borderRadius: 12,
  cursor: 'pointer',
  fontWeight: 700,
}

const erroStyle: React.CSSProperties = {
  marginTop: 16,
  background: '#fef2f2',
  border: '1px solid #fecaca',
  color: '#b91c1c',
  padding: 12,
  borderRadius: 12,
}

const sucessoStyle: React.CSSProperties = {
  marginTop: 16,
  background: '#ecfdf3',
  border: '1px solid #bbf7d0',
  color: '#166534',
  padding: 12,
  borderRadius: 12,
}

const secaoHeaderStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  gap: 12,
  flexWrap: 'wrap',
  marginBottom: 14,
}

const secaoTituloStyle: React.CSSProperties = {
  margin: 0,
  fontSize: 22,
  color: '#111827',
}

const secaoTextoStyle: React.CSSProperties = {
  margin: '6px 0 0 0',
  color: '#6b7280',
  fontSize: 14,
}

const itemLabelStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  color: '#6b7280',
  textTransform: 'uppercase',
  letterSpacing: 0.5,
  marginBottom: 6,
}

const itemValorStyle: React.CSSProperties = {
  fontSize: 14,
  color: '#111827',
  fontWeight: 600,
  wordBreak: 'break-word',
}

const badgeStatusStyle: React.CSSProperties = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: '6px 10px',
  borderRadius: 999,
  fontSize: 12,
  fontWeight: 800,
  border: '1px solid transparent',
}

const vazioStyle: React.CSSProperties = {
  background: '#f9fafb',
  borderRadius: 16,
  padding: 18,
  border: '1px solid #ececec',
  color: '#6b7280',
}