'use client'

import { useEffect, useMemo, useState } from 'react'

type Empresa = {
  id: string
  nome: string
  slug: string
  logo_url?: string | null
  cor_primaria?: string | null
  cor_secundaria?: string | null
}

type Agendamento = {
  id: string
  data_agendamento: string | null
  valor_cobrado: number | null
  valor_pago: number | null
  servico_id?: string | null
  profissional_id?: string | null
}

type Servico = {
  id: string
  nome: string
}

type Profissional = {
  id: string
  nome: string
}

type MensalItem = {
  label: string
  valorAtual: number
  valorAnterior: number
}

type SemestralItem = {
  label: string
  atual: number
  anterior: number
}

const MESES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']

export default function DashboardPage() {
  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([])
  const [servicos, setServicos] = useState<Servico[]>([])
  const [profissionais, setProfissionais] = useState<Profissional[]>([])
  const [loading, setLoading] = useState(true)
  const [erro, setErro] = useState('')

  const hoje = new Date()
  const primeiroDiaMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1)
  const hojeIso = formatDateInput(hoje)
  const primeiroDiaMesIso = formatDateInput(primeiroDiaMes)

  const [dataInicio, setDataInicio] = useState(primeiroDiaMesIso)
  const [dataFim, setDataFim] = useState(hojeIso)
  const [filtroRapido, setFiltroRapido] = useState('mes-atual')
  const [servicoSelecionado, setServicoSelecionado] = useState('')
  const [profissionalSelecionado, setProfissionalSelecionado] = useState('')

  useEffect(() => {
    carregarDashboard()
  }, [])

  async function carregarDashboard() {
    try {
      setLoading(true)
      setErro('')

      const slugPadrao =
        process.env.NEXT_PUBLIC_EMPRESA_SLUG_PADRAO || 'espaco-aurea'
      const baseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
      const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

      if (!baseUrl || !anonKey) {
        throw new Error('Variáveis do Supabase não configuradas no .env.local')
      }

      const headers = {
        apikey: anonKey,
        Authorization: `Bearer ${anonKey}`,
        'Content-Type': 'application/json',
      }

      const empresaRes = await fetch(
        `${baseUrl}/rest/v1/empresas?slug=eq.${slugPadrao}&select=id,nome,slug,logo_url,cor_primaria,cor_secundaria&limit=1`,
        {
          headers,
          cache: 'no-store',
        }
      )

      if (!empresaRes.ok) {
        const texto = await empresaRes.text()
        throw new Error(`Erro ao buscar empresa: ${texto}`)
      }

      const empresas: Empresa[] = await empresaRes.json()

      if (!empresas.length) {
        throw new Error('Empresa não encontrada.')
      }

      const empresaAtual = empresas[0]
      setEmpresa(empresaAtual)

      const [agendamentosRes, servicosRes, profissionaisRes] = await Promise.all([
        fetch(
          `${baseUrl}/rest/v1/agendamentos?empresa_id=eq.${empresaAtual.id}&select=id,data_agendamento,valor_cobrado,valor_pago,servico_id,profissional_id`,
          {
            headers,
            cache: 'no-store',
          }
        ),
        fetch(
          `${baseUrl}/rest/v1/servicos?empresa_id=eq.${empresaAtual.id}&select=id,nome&order=nome.asc`,
          {
            headers,
            cache: 'no-store',
          }
        ),
        fetch(
          `${baseUrl}/rest/v1/profissionais?empresa_id=eq.${empresaAtual.id}&select=id,nome&order=nome.asc`,
          {
            headers,
            cache: 'no-store',
          }
        ),
      ])

      if (!agendamentosRes.ok) {
        const texto = await agendamentosRes.text()
        throw new Error(`Erro ao buscar agendamentos: ${texto}`)
      }

      if (!servicosRes.ok) {
        const texto = await servicosRes.text()
        throw new Error(`Erro ao buscar serviços: ${texto}`)
      }

      if (!profissionaisRes.ok) {
        const texto = await profissionaisRes.text()
        throw new Error(`Erro ao buscar profissionais: ${texto}`)
      }

      const agendamentosData: Agendamento[] = await agendamentosRes.json()
      const servicosData: Servico[] = await servicosRes.json()
      const profissionaisData: Profissional[] = await profissionaisRes.json()

      setAgendamentos(agendamentosData)
      setServicos(servicosData)
      setProfissionais(profissionaisData)
    } catch (error: unknown) {
      const mensagem =
        error instanceof Error ? error.message : 'Erro ao carregar dashboard.'
      setErro(mensagem)
      console.error('Erro dashboard:', error)
    } finally {
      setLoading(false)
    }
  }

  function aplicarFiltroRapido(tipo: string) {
    const agora = new Date()
    let inicio = new Date()
    let fim = new Date()

    if (tipo === 'hoje') {
      inicio = new Date(agora)
      fim = new Date(agora)
    }

    if (tipo === '7-dias') {
      inicio = new Date(agora)
      inicio.setDate(agora.getDate() - 6)
      fim = new Date(agora)
    }

    if (tipo === '30-dias') {
      inicio = new Date(agora)
      inicio.setDate(agora.getDate() - 29)
      fim = new Date(agora)
    }

    if (tipo === 'mes-atual') {
      inicio = new Date(agora.getFullYear(), agora.getMonth(), 1)
      fim = new Date(agora)
    }

    if (tipo === 'semestre-atual') {
      const mes = agora.getMonth()
      if (mes <= 5) {
        inicio = new Date(agora.getFullYear(), 0, 1)
      } else {
        inicio = new Date(agora.getFullYear(), 6, 1)
      }
      fim = new Date(agora)
    }

    if (tipo === 'ano-atual') {
      inicio = new Date(agora.getFullYear(), 0, 1)
      fim = new Date(agora)
    }

    setFiltroRapido(tipo)
    setDataInicio(formatDateInput(inicio))
    setDataFim(formatDateInput(fim))
  }

  function limparFiltro() {
    const agora = new Date()
    const inicio = new Date(agora.getFullYear(), agora.getMonth(), 1)
    setFiltroRapido('mes-atual')
    setDataInicio(formatDateInput(inicio))
    setDataFim(formatDateInput(agora))
    setServicoSelecionado('')
    setProfissionalSelecionado('')
  }

  const corPrimaria = empresa?.cor_primaria || '#b8956f'
  const corSecundaria = empresa?.cor_secundaria || '#6f4b3d'

  const analytics = useMemo(() => {
    const anoAtual = new Date().getFullYear()
    const anoAnterior = anoAtual - 1
    const hojeStr = formatDateInput(new Date())

    const inicio = dataInicio || '0000-01-01'
    const fim = dataFim || '9999-12-31'

    const filtrados = agendamentos.filter((item) => {
      if (!item.data_agendamento) return false

      const dentroPeriodo =
        item.data_agendamento >= inicio && item.data_agendamento <= fim

      const filtroServico =
        !servicoSelecionado || item.servico_id === servicoSelecionado

      const filtroProfissional =
        !profissionalSelecionado || item.profissional_id === profissionalSelecionado

      return dentroPeriodo && filtroServico && filtroProfissional
    })

    let agendamentosHoje = 0
    let faturamento = 0
    let recebido = 0

    filtrados.forEach((item) => {
      faturamento += Number(item.valor_cobrado || 0)
      recebido += Number(item.valor_pago || 0)

      if (item.data_agendamento === hojeStr) {
        agendamentosHoje += 1
      }
    })

    const pendente = faturamento - recebido

    const mensalAtual = Array(12).fill(0)
    const mensalAnterior = Array(12).fill(0)

    agendamentos.forEach((item) => {
      if (!item.data_agendamento) return

      const ano = Number(item.data_agendamento.slice(0, 4))
      const mes = Number(item.data_agendamento.slice(5, 7)) - 1
      const valorCobrado = Number(item.valor_cobrado || 0)

      if (ano === anoAtual) {
        mensalAtual[mes] += valorCobrado
      }

      if (ano === anoAnterior) {
        mensalAnterior[mes] += valorCobrado
      }
    })

    const mensal: MensalItem[] = MESES.map((mes, index) => ({
      label: mes,
      valorAtual: mensalAtual[index],
      valorAnterior: mensalAnterior[index],
    }))

    let semestreAtualS1 = 0
    let semestreAtualS2 = 0
    let semestreAnteriorS1 = 0
    let semestreAnteriorS2 = 0

    agendamentos.forEach((item) => {
      if (!item.data_agendamento) return

      const ano = Number(item.data_agendamento.slice(0, 4))
      const mes = Number(item.data_agendamento.slice(5, 7)) - 1
      const valorCobrado = Number(item.valor_cobrado || 0)

      if (ano === anoAtual) {
        if (mes <= 5) semestreAtualS1 += valorCobrado
        else semestreAtualS2 += valorCobrado
      }

      if (ano === anoAnterior) {
        if (mes <= 5) semestreAnteriorS1 += valorCobrado
        else semestreAnteriorS2 += valorCobrado
      }
    })

    const semestral: SemestralItem[] = [
      {
        label: '1º semestre',
        atual: semestreAtualS1,
        anterior: semestreAnteriorS1,
      },
      {
        label: '2º semestre',
        atual: semestreAtualS2,
        anterior: semestreAnteriorS2,
      },
    ]

    const totalAnoAtual = mensalAtual.reduce((acc, n) => acc + n, 0)
    const totalAnoAnterior = mensalAnterior.reduce((acc, n) => acc + n, 0)

    const variacaoAno =
      totalAnoAnterior > 0
        ? ((totalAnoAtual - totalAnoAnterior) / totalAnoAnterior) * 100
        : totalAnoAtual > 0
          ? 100
          : 0

    return {
      resumo: {
        agendamentosHoje,
        faturamento,
        recebido,
        pendente,
      },
      filtrados,
      anoAtual,
      anoAnterior,
      totalAnoAtual,
      totalAnoAnterior,
      variacaoAno,
      mensal,
      semestral,
    }
  }, [agendamentos, dataInicio, dataFim, servicoSelecionado, profissionalSelecionado])

  if (loading) {
    return <div style={boxStyle}>Carregando dashboard...</div>
  }

  if (erro) {
    return (
      <div
        style={{
          ...boxStyle,
          background: '#fff1f2',
          border: '1px solid #fecdd3',
          color: '#b91c1c',
        }}
      >
        <strong>Erro ao carregar dashboard:</strong>
        <div style={{ marginTop: 8 }}>{erro}</div>
      </div>
    )
  }

  if (!empresa) {
    return <div style={boxStyle}>Empresa não encontrada.</div>
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <section
        style={{
          ...boxStyle,
          borderTop: `5px solid ${corPrimaria}`,
          background: `linear-gradient(180deg, #ffffff 0%, #fcfaf9 100%)`,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div
            style={{
              width: 54,
              height: 54,
              borderRadius: 16,
              background: `linear-gradient(135deg, ${corSecundaria}, ${corPrimaria})`,
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 800,
              fontSize: 20,
              flexShrink: 0,
              boxShadow: '0 8px 20px rgba(0,0,0,0.10)',
            }}
          >
            {empresa.nome.charAt(0).toUpperCase()}
          </div>

          <div>
            <p
              style={{
                margin: 0,
                fontSize: 12,
                fontWeight: 800,
                letterSpacing: 1,
                textTransform: 'uppercase',
                color: '#6b7280',
              }}
            >
              Dashboard
            </p>

            <h1
              style={{
                margin: '6px 0 0 0',
                fontSize: 34,
                lineHeight: 1.1,
                color: '#111827',
              }}
            >
              Olá, Crislane 👋
            </h1>

            <p
              style={{
                margin: '8px 0 0 0',
                fontSize: 15,
                color: '#6b7280',
              }}
            >
              Aqui está o resumo da operação da empresa {empresa.nome}.
            </p>
          </div>
        </div>
      </section>

      <section style={boxStyle}>
        <div style={secaoHeaderStyle}>
          <div>
            <h2 style={secaoTituloStyle}>Filtro por período</h2>
            <p style={secaoTextoStyle}>
              Selecione um intervalo e refine por serviço ou profissional.
            </p>
          </div>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            gap: 12,
            marginBottom: 16,
          }}
        >
          <BotaoFiltro ativo={filtroRapido === 'hoje'} onClick={() => aplicarFiltroRapido('hoje')} label="Hoje" cor={corPrimaria} />
          <BotaoFiltro ativo={filtroRapido === '7-dias'} onClick={() => aplicarFiltroRapido('7-dias')} label="7 dias" cor={corPrimaria} />
          <BotaoFiltro ativo={filtroRapido === '30-dias'} onClick={() => aplicarFiltroRapido('30-dias')} label="30 dias" cor={corPrimaria} />
          <BotaoFiltro ativo={filtroRapido === 'mes-atual'} onClick={() => aplicarFiltroRapido('mes-atual')} label="Mês atual" cor={corPrimaria} />
          <BotaoFiltro ativo={filtroRapido === 'semestre-atual'} onClick={() => aplicarFiltroRapido('semestre-atual')} label="Semestre atual" cor={corPrimaria} />
          <BotaoFiltro ativo={filtroRapido === 'ano-atual'} onClick={() => aplicarFiltroRapido('ano-atual')} label="Ano atual" cor={corPrimaria} />
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: 16,
            alignItems: 'end',
          }}
        >
          <CampoData label="Data inicial" value={dataInicio} onChange={setDataInicio} />
          <CampoData label="Data final" value={dataFim} onChange={setDataFim} />

          <div>
            <label style={labelStyle}>Serviço</label>
            <select
              value={servicoSelecionado}
              onChange={(e) => setServicoSelecionado(e.target.value)}
              style={inputStyle}
            >
              <option value="">Todos os serviços</option>
              {servicos.map((servico) => (
                <option key={servico.id} value={servico.id}>
                  {servico.nome}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label style={labelStyle}>Profissional</label>
            <select
              value={profissionalSelecionado}
              onChange={(e) => setProfissionalSelecionado(e.target.value)}
              style={inputStyle}
            >
              <option value="">Todos os profissionais</option>
              {profissionais.map((profissional) => (
                <option key={profissional.id} value={profissional.id}>
                  {profissional.nome}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={limparFiltro}
            style={{
              height: 44,
              borderRadius: 12,
              border: '1px solid #d1d5db',
              background: '#fff',
              color: '#374151',
              fontWeight: 700,
              cursor: 'pointer',
              padding: '0 16px',
            }}
          >
            Limpar filtro
          </button>
        </div>

        <div
          style={{
            marginTop: 12,
            fontSize: 13,
            color: '#6b7280',
          }}
        >
          Período selecionado: <strong>{formatarDataBR(dataInicio)}</strong> até <strong>{formatarDataBR(dataFim)}</strong>
        </div>
      </section>

      <section
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: 16,
        }}
      >
        <Card titulo="Agendamentos no período" valor={String(analytics.filtrados.length)} corDestaque={corPrimaria} />
        <Card titulo="Faturamento no período" valor={formatarMoeda(analytics.resumo.faturamento)} corDestaque={corPrimaria} />
        <Card titulo="Recebido no período" valor={formatarMoeda(analytics.resumo.recebido)} corDestaque={corPrimaria} />
        <Card titulo="Pendente no período" valor={formatarMoeda(analytics.resumo.pendente)} corDestaque={corSecundaria} />
      </section>

      <section style={boxStyle}>
        <div style={secaoHeaderStyle}>
          <div>
            <h2 style={secaoTituloStyle}>Comparação anual</h2>
            <p style={secaoTextoStyle}>
              Compare o faturamento do ano atual com o ano anterior.
            </p>
          </div>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: 16,
            marginBottom: 20,
          }}
        >
          <CardResumoComparativo titulo={`Ano ${analytics.anoAtual}`} valor={formatarMoeda(analytics.totalAnoAtual)} destaque={corPrimaria} />
          <CardResumoComparativo titulo={`Ano ${analytics.anoAnterior}`} valor={formatarMoeda(analytics.totalAnoAnterior)} destaque={corSecundaria} />
          <CardResumoComparativo titulo="Variação anual" valor={formatarPercentual(analytics.variacaoAno)} destaque={analytics.variacaoAno >= 0 ? '#16a34a' : '#dc2626'} />
        </div>

        <BarComparisonChart
          title="Faturamento por mês"
          subtitle={`${analytics.anoAtual} x ${analytics.anoAnterior}`}
          data={analytics.mensal}
          corAtual={corPrimaria}
          corAnterior="#cbd5e1"
        />
      </section>

      <section style={boxStyle}>
        <div style={secaoHeaderStyle}>
          <div>
            <h2 style={secaoTituloStyle}>Comparação por semestre</h2>
            <p style={secaoTextoStyle}>
              Visão consolidada do 1º e 2º semestre do ano atual contra o anterior.
            </p>
          </div>
        </div>

        <SemesterComparison
          data={analytics.semestral}
          corAtual={corPrimaria}
          corAnterior={corSecundaria}
          anoAtual={analytics.anoAtual}
          anoAnterior={analytics.anoAnterior}
        />
      </section>
    </div>
  )
}

function CampoData({
  label,
  value,
  onChange,
}: {
  label: string
  value: string
  onChange: (value: string) => void
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <label style={labelStyle}>{label}</label>
      <input
        type="date"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        style={{
          ...inputStyle,
          height: 44,
        }}
      />
    </div>
  )
}

function BotaoFiltro({
  ativo,
  onClick,
  label,
  cor,
}: {
  ativo: boolean
  onClick: () => void
  label: string
  cor: string
}) {
  return (
    <button
      onClick={onClick}
      style={{
        height: 42,
        borderRadius: 12,
        border: ativo ? `1px solid ${cor}` : '1px solid #e5e7eb',
        background: ativo ? cor : '#fff',
        color: ativo ? '#fff' : '#374151',
        fontWeight: 700,
        cursor: 'pointer',
        padding: '0 14px',
      }}
    >
      {label}
    </button>
  )
}

function Card({
  titulo,
  valor,
  corDestaque,
}: {
  titulo: string
  valor: string
  corDestaque: string
}) {
  return (
    <div
      style={{
        background: '#ffffff',
        borderRadius: 18,
        padding: 20,
        boxShadow: '0 6px 18px rgba(0,0,0,0.06)',
        border: '1px solid #f1f1f1',
        borderTop: `4px solid ${corDestaque}`,
      }}
    >
      <p
        style={{
          fontSize: 13,
          color: '#6b7280',
          margin: 0,
          fontWeight: 700,
          letterSpacing: 0.2,
        }}
      >
        {titulo}
      </p>

      <h3
        style={{
          marginTop: 14,
          marginBottom: 0,
          fontSize: 34,
          fontWeight: 800,
          color: '#111827',
          lineHeight: 1.1,
        }}
      >
        {valor}
      </h3>
    </div>
  )
}

function CardResumoComparativo({
  titulo,
  valor,
  destaque,
}: {
  titulo: string
  valor: string
  destaque: string
}) {
  return (
    <div
      style={{
        background: '#f9fafb',
        borderRadius: 16,
        padding: 18,
        border: '1px solid #ececec',
      }}
    >
      <div
        style={{
          width: 12,
          height: 12,
          borderRadius: 999,
          background: destaque,
          marginBottom: 10,
        }}
      />
      <p
        style={{
          margin: 0,
          color: '#6b7280',
          fontSize: 13,
          fontWeight: 700,
        }}
      >
        {titulo}
      </p>
      <h3
        style={{
          margin: '10px 0 0 0',
          fontSize: 28,
          lineHeight: 1.1,
          color: '#111827',
        }}
      >
        {valor}
      </h3>
    </div>
  )
}

function BarComparisonChart({
  title,
  subtitle,
  data,
  corAtual,
  corAnterior,
}: {
  title: string
  subtitle: string
  data: MensalItem[]
  corAtual: string
  corAnterior: string
}) {
  const maxValue = Math.max(
    1,
    ...data.flatMap((item) => [item.valorAtual, item.valorAnterior])
  )

  return (
    <div>
      <h3
        style={{
          margin: 0,
          fontSize: 18,
          color: '#111827',
        }}
      >
        {title}
      </h3>

      <p
        style={{
          margin: '6px 0 18px 0',
          fontSize: 14,
          color: '#6b7280',
        }}
      >
        {subtitle}
      </p>

      <div style={{ display: 'grid', gap: 14 }}>
        {data.map((item) => {
          const percentualAtual = (item.valorAtual / maxValue) * 100
          const percentualAnterior = (item.valorAnterior / maxValue) * 100

          return (
            <div key={item.label}>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: 6,
                  gap: 12,
                }}
              >
                <span
                  style={{
                    minWidth: 34,
                    fontSize: 13,
                    fontWeight: 700,
                    color: '#374151',
                  }}
                >
                  {item.label}
                </span>

                <div
                  style={{
                    display: 'flex',
                    gap: 14,
                    fontSize: 12,
                    color: '#6b7280',
                    flexWrap: 'wrap',
                  }}
                >
                  <span>{formatarMoeda(item.valorAtual)}</span>
                  <span>{formatarMoeda(item.valorAnterior)}</span>
                </div>
              </div>

              <div style={{ display: 'grid', gap: 6 }}>
                <div
                  style={{
                    height: 12,
                    background: '#f3f4f6',
                    borderRadius: 999,
                    overflow: 'hidden',
                  }}
                >
                  <div
                    style={{
                      width: `${percentualAtual}%`,
                      height: '100%',
                      background: corAtual,
                      borderRadius: 999,
                    }}
                  />
                </div>

                <div
                  style={{
                    height: 12,
                    background: '#f3f4f6',
                    borderRadius: 999,
                    overflow: 'hidden',
                  }}
                >
                  <div
                    style={{
                      width: `${percentualAnterior}%`,
                      height: '100%',
                      background: corAnterior,
                      borderRadius: 999,
                    }}
                  />
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <div
        style={{
          display: 'flex',
          gap: 16,
          marginTop: 18,
          flexWrap: 'wrap',
          fontSize: 13,
          color: '#6b7280',
        }}
      >
        <Legenda cor={corAtual} texto="Ano atual" />
        <Legenda cor={corAnterior} texto="Ano anterior" />
      </div>
    </div>
  )
}

function SemesterComparison({
  data,
  corAtual,
  corAnterior,
  anoAtual,
  anoAnterior,
}: {
  data: SemestralItem[]
  corAtual: string
  corAnterior: string
  anoAtual: number
  anoAnterior: number
}) {
  const maxValue = Math.max(
    1,
    ...data.flatMap((item) => [item.atual, item.anterior])
  )

  return (
    <div style={{ display: 'grid', gap: 16 }}>
      {data.map((item) => {
        const pctAtual = (item.atual / maxValue) * 100
        const pctAnterior = (item.anterior / maxValue) * 100

        return (
          <div
            key={item.label}
            style={{
              background: '#f9fafb',
              borderRadius: 16,
              padding: 16,
              border: '1px solid #ececec',
            }}
          >
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                gap: 12,
                flexWrap: 'wrap',
                marginBottom: 10,
              }}
            >
              <h3
                style={{
                  margin: 0,
                  fontSize: 16,
                  color: '#111827',
                }}
              >
                {item.label}
              </h3>

              <div
                style={{
                  display: 'flex',
                  gap: 14,
                  flexWrap: 'wrap',
                  fontSize: 13,
                  color: '#6b7280',
                }}
              >
                <span>{anoAtual}: {formatarMoeda(item.atual)}</span>
                <span>{anoAnterior}: {formatarMoeda(item.anterior)}</span>
              </div>
            </div>

            <div style={{ display: 'grid', gap: 8 }}>
              <div
                style={{
                  height: 14,
                  background: '#f3f4f6',
                  borderRadius: 999,
                  overflow: 'hidden',
                }}
              >
                <div
                  style={{
                    width: `${pctAtual}%`,
                    height: '100%',
                    background: corAtual,
                    borderRadius: 999,
                  }}
                />
              </div>

              <div
                style={{
                  height: 14,
                  background: '#f3f4f6',
                  borderRadius: 999,
                  overflow: 'hidden',
                }}
              >
                <div
                  style={{
                    width: `${pctAnterior}%`,
                    height: '100%',
                    background: corAnterior,
                    borderRadius: 999,
                  }}
                />
              </div>
            </div>
          </div>
        )
      })}

      <div
        style={{
          display: 'flex',
          gap: 16,
          flexWrap: 'wrap',
          fontSize: 13,
          color: '#6b7280',
        }}
      >
        <Legenda cor={corAtual} texto={`${anoAtual}`} />
        <Legenda cor={corAnterior} texto={`${anoAnterior}`} />
      </div>
    </div>
  )
}

function Legenda({ cor, texto }: { cor: string; texto: string }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8,
      }}
    >
      <span
        style={{
          width: 12,
          height: 12,
          borderRadius: 999,
          background: cor,
          display: 'inline-block',
        }}
      />
      {texto}
    </span>
  )
}

function formatarMoeda(valor: number) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    maximumFractionDigits: 2,
  }).format(valor)
}

function formatarPercentual(valor: number) {
  const sinal = valor > 0 ? '+' : ''
  return `${sinal}${valor.toFixed(1)}%`
}

function formatDateInput(data: Date) {
  return data.toISOString().split('T')[0]
}

function formatarDataBR(data: string) {
  if (!data) return '-'
  const [ano, mes, dia] = data.split('-')
  return `${dia}/${mes}/${ano}`
}

const boxStyle: React.CSSProperties = {
  background: '#ffffff',
  borderRadius: 20,
  padding: 24,
  boxShadow: '0 4px 14px rgba(0,0,0,0.06)',
}

const secaoHeaderStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  gap: 12,
  flexWrap: 'wrap',
  marginBottom: 14,
}

const secaoTituloStyle: React.CSSProperties = {
  margin: 0,
  fontSize: 22,
  color: '#111827',
}

const secaoTextoStyle: React.CSSProperties = {
  margin: '6px 0 0 0',
  color: '#6b7280',
  fontSize: 14,
}

const labelStyle: React.CSSProperties = {
  fontSize: 14,
  fontWeight: 700,
  color: '#374151',
  marginBottom: 6,
  display: 'block',
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  border: '1px solid #d1d5db',
  borderRadius: 12,
  padding: '12px 14px',
  fontSize: 14,
  background: '#fff',
}
