
'use client'

import React, { useEffect, useMemo, useState } from 'react'
import { supabase } from '@/lib/supabase'
import ProtegePagina from '@/components/ProtegePagina'
import ProtegeOnboarding from '@/components/ProtegeOnboarding'
import { useSessaoEmpresa } from '@/lib/useSessaoEmpresa'
import { getTemaEmpresa } from '@/lib/temaEmpresa'
import {
  botaoPrimarioTema,
  botaoSecundarioTema,
  cardTema,
} from '@/lib/temaStyles'

type Aba = 'novo' | 'calendario' | 'caixa'

type Cliente = {
  id: string
  empresa_id: string
  nome: string
  telefone?: string | null
  email?: string | null
}

type Profissional = {
  id: string
  empresa_id: string
  nome: string
}

type Servico = {
  id: string
  empresa_id: string
  nome: string
  categoria?: string | null
  preco?: number | null
  preco_promocional?: number | null
  duracao_padrao_minutos?: number | null
  ativo?: boolean | null
}

type AgendamentoServico = {
  id?: string
  agendamento_id?: string
  servico_id: string
  ordem?: number | null
  valor?: number | null
  duracao?: number | null
  servicos?: Servico | null
}

type Agendamento = {
  id: string
  empresa_id: string
  cliente_id: string
  profissional_id: string
  servico_id?: string | null
  data_agendamento: string
  hora: string
  status: string
  valor_cobrado?: number | null
  valor_pago?: number | null
  status_pagamento?: string | null
  forma_pagamento?: string | null
  agendamento_servicos?: AgendamentoServico[] | null
}

type AnamneseCliente = {
  id?: string
  empresa_id?: string
  cliente_id?: string
  diabetes?: boolean
  gestante?: boolean
  alergia_produtos?: boolean
  alergia_descricao?: string | null
  uso_medicacao?: boolean
  medicacao_descricao?: string | null
  sensibilidade_cutanea?: boolean
  problema_circulatorio?: boolean
  observacoes_gerais?: string | null
}

function hojeISO() {
  const agora = new Date()
  const ano = agora.getFullYear()
  const mes = String(agora.getMonth() + 1).padStart(2, '0')
  const dia = String(agora.getDate()).padStart(2, '0')
  return `${ano}-${mes}-${dia}`
}

function moeda(valor: number) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(Number(valor || 0))
}

function horaParaMinutos(hora?: string | null) {
  if (!hora) return 0
  const [h, m] = hora.slice(0, 5).split(':').map(Number)
  return (h || 0) * 60 + (m || 0)
}

function minutosParaHora(total: number) {
  const h = Math.floor(total / 60)
  const m = total % 60
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
}

function gerarHorarios() {
  const lista: string[] = []
  for (let i = 8 * 60; i <= 18 * 60; i += 10) {
    lista.push(minutosParaHora(i))
  }
  return lista
}

function labelStatusAgendamento(status?: string | null) {
  if (status === 'pendente') return 'Pendente'
  if (status === 'confirmado') return 'Confirmado'
  if (status === 'em_atendimento') return 'Em atendimento'
  if (status === 'finalizado') return 'Finalizado'
  if (status === 'cancelado') return 'Cancelado'
  if (status === 'faltou') return 'Faltou'
  return status || '-'
}

function labelStatusPagamento(status?: string | null) {
  if (status === 'nao_pago') return 'Não pago'
  if (status === 'pago') return 'Pago'
  if (status === 'parcial') return 'Parcial'
  if (status === 'estornado') return 'Estornado'
  return status || '-'
}

function statusPagamentoCor(status?: string | null) {
  switch (status) {
    case 'pago':
      return '#dcfce7'
    case 'parcial':
      return '#fef3c7'
    case 'estornado':
      return '#fee2e2'
    default:
      return '#f3f4f6'
  }
}

function limparTelefoneWhatsapp(telefone?: string | null) {
  return (telefone || '').replace(/\D/g, '')
}

function obterBaseUrl() {
  if (typeof window !== 'undefined' && window.location?.origin) {
    return window.location.origin
  }
  return process.env.NEXT_PUBLIC_BASE_URL || ''
}

function gerarLinkConfirmacao(id: string, slug?: string | null) {
  const baseUrl = obterBaseUrl()
  return `${baseUrl}/confirmar?id=${id}&empresa=${slug || ''}`
}

function gerarLinkReagendamento(id: string, slug?: string | null) {
  const baseUrl = obterBaseUrl()
  return `${baseUrl}/meu-espaco/reagendar?id=${id}&empresa=${slug || ''}`
}

function gerarLinkCancelamento(id: string, slug?: string | null) {
  const baseUrl = obterBaseUrl()
  return `${baseUrl}/meu-espaco/cancelar?id=${id}&empresa=${slug || ''}`
}

function normalizarServico(raw: any): Servico | null {
  if (!raw || Array.isArray(raw)) return null

  return {
    id: String(raw.id),
    empresa_id: String(raw.empresa_id),
    nome: String(raw.nome),
    categoria: raw.categoria || null,
    preco: raw.preco != null ? Number(raw.preco) : null,
    preco_promocional:
      raw.preco_promocional != null ? Number(raw.preco_promocional) : null,
    duracao_padrao_minutos:
      raw.duracao_padrao_minutos != null
        ? Number(raw.duracao_padrao_minutos)
        : null,
    ativo: raw.ativo ?? null,
  }
}

function gerarAlertasAnamnese(anamnese: AnamneseCliente | null) {
  if (!anamnese) return []

  const alertas: string[] = []

  if (anamnese.diabetes) alertas.push('Cliente com diabetes')
  if (anamnese.gestante) alertas.push('Cliente gestante')
  if (anamnese.alergia_produtos) {
    alertas.push(
      anamnese.alergia_descricao
        ? `Alergia a produtos: ${anamnese.alergia_descricao}`
        : 'Alergia a produtos'
    )
  }
  if (anamnese.uso_medicacao) {
    alertas.push(
      anamnese.medicacao_descricao
        ? `Uso de medicação: ${anamnese.medicacao_descricao}`
        : 'Uso de medicação contínua'
    )
  }
  if (anamnese.sensibilidade_cutanea) {
    alertas.push('Sensibilidade cutânea')
  }
  if (anamnese.problema_circulatorio) {
    alertas.push('Problema circulatório')
  }
  if (anamnese.observacoes_gerais) {
    alertas.push(`Observações: ${anamnese.observacoes_gerais}`)
  }

  return alertas
}

const HORARIOS_BASE = gerarHorarios()
const DESCANSO_MIN = 10

export default function AgendamentosPage() {
  return (
    <ProtegePagina>
      <ProtegeOnboarding>
        <AgendamentosConteudo />
      </ProtegeOnboarding>
    </ProtegePagina>
  )
}

function AgendamentosConteudo() {
  const { empresa, loading } = useSessaoEmpresa()
  const tema = getTemaEmpresa(empresa)

  const [abaAtiva, setAbaAtiva] = useState<Aba>('novo')
  const [carregandoDados, setCarregandoDados] = useState(true)

  const [clientes, setClientes] = useState<Cliente[]>([])
  const [profissionais, setProfissionais] = useState<Profissional[]>([])
  const [servicos, setServicos] = useState<Servico[]>([])
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([])
  const [anamnesesMap, setAnamnesesMap] = useState<Record<string, AnamneseCliente>>({})

  const [clienteId, setClienteId] = useState('')
  const [profissionalId, setProfissionalId] = useState('')
  const [dataAgendamento, setDataAgendamento] = useState(hojeISO())
  const [hora, setHora] = useState('')
  const [servicoSelecionadoId, setServicoSelecionadoId] = useState('')
  const [servicosSelecionados, setServicosSelecionados] = useState<Servico[]>([])
  const [usarPromocao, setUsarPromocao] = useState(false)
  const [valorCobrado, setValorCobrado] = useState('')
  const [agendamentoEditandoId, setAgendamentoEditandoId] = useState<string | null>(null)

  const [filtroInicioCalendario, setFiltroInicioCalendario] = useState('')
  const [filtroFimCalendario, setFiltroFimCalendario] = useState('')
  const [filtroStatusCalendario, setFiltroStatusCalendario] = useState('todos')
  const [filtroProfissionalCalendario, setFiltroProfissionalCalendario] =
    useState('todos')
  const [dataAgendaVisual, setDataAgendaVisual] = useState(hojeISO())

  const [filtroInicioCaixa, setFiltroInicioCaixa] = useState('')
  const [filtroFimCaixa, setFiltroFimCaixa] = useState('')
  const [filtroStatusCaixa, setFiltroStatusCaixa] = useState('todos')

  const [anamneseCliente, setAnamneseCliente] = useState<AnamneseCliente | null>(null)

  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (!empresa?.id) return
    carregarDados()
  }, [empresa?.id])

  useEffect(() => {
    const total = servicosSelecionados.reduce((acc, item) => {
      const valor =
        usarPromocao && Number(item.preco_promocional || 0) > 0
          ? Number(item.preco_promocional || 0)
          : Number(item.preco || 0)

      return acc + valor
    }, 0)

    setValorCobrado(total > 0 ? String(total) : '')
  }, [servicosSelecionados, usarPromocao])

  useEffect(() => {
    if (!clienteId) {
      setAnamneseCliente(null)
      return
    }

    setAnamneseCliente(anamnesesMap[clienteId] || null)
  }, [clienteId, anamnesesMap])

  async function carregarDados() {
    if (!empresa?.id) return

    setCarregandoDados(true)
    setErro('')

    try {
      const [
        clientesRes,
        profissionaisRes,
        servicosRes,
        agendamentosRes,
        anamnesesRes,
      ] = await Promise.all([
        supabase
          .from('clientes')
          .select('*')
          .eq('empresa_id', empresa.id)
          .order('nome'),
        supabase
          .from('profissionais')
          .select('*')
          .eq('empresa_id', empresa.id)
          .order('nome'),
        supabase
          .from('servicos')
          .select('*')
          .eq('empresa_id', empresa.id)
          .order('nome'),
        supabase
          .from('agendamentos')
          .select(
            `
              *,
              agendamento_servicos (
                id,
                agendamento_id,
                servico_id,
                ordem,
                valor,
                duracao,
                servicos (*)
              )
            `
          )
          .eq('empresa_id', empresa.id)
          .order('data_agendamento', { ascending: false }),
        supabase
          .from('anamnese_clientes')
          .select('*')
          .eq('empresa_id', empresa.id),
      ])

      if (clientesRes.error) throw clientesRes.error
      if (profissionaisRes.error) throw profissionaisRes.error
      if (servicosRes.error) throw servicosRes.error
      if (agendamentosRes.error) throw agendamentosRes.error
      if (anamnesesRes.error) throw anamnesesRes.error

      const ags = ((agendamentosRes.data || []) as any[]).map((ag) => ({
        ...ag,
        agendamento_servicos: Array.isArray(ag.agendamento_servicos)
          ? ag.agendamento_servicos.map((item: any) => ({
              id: item.id,
              agendamento_id: item.agendamento_id,
              servico_id: item.servico_id,
              ordem: item.ordem,
              valor: item.valor,
              duracao: item.duracao,
              servicos: normalizarServico(item.servicos),
            }))
          : [],
      }))

      const mapaAnamneses: Record<string, AnamneseCliente> = {}
      ;(anamnesesRes.data || []).forEach((item: any) => {
        if (item.cliente_id) {
          mapaAnamneses[String(item.cliente_id)] = item as AnamneseCliente
        }
      })

      setClientes((clientesRes.data || []) as Cliente[])
      setProfissionais((profissionaisRes.data || []) as Profissional[])
      setServicos((servicosRes.data || []) as Servico[])
      setAgendamentos(ags as Agendamento[])
      setAnamnesesMap(mapaAnamneses)
    } catch (error: any) {
      console.error(error)
      setErro(error?.message || 'Erro ao carregar dados.')
    } finally {
      setCarregandoDados(false)
    }
  }

  function limparFormulario() {
    setClienteId('')
    setProfissionalId('')
    setDataAgendamento(hojeISO())
    setHora('')
    setServicoSelecionadoId('')
    setServicosSelecionados([])
    setUsarPromocao(false)
    setValorCobrado('')
    setAgendamentoEditandoId(null)
    setAnamneseCliente(null)
  }

  function adicionarServico() {
    const servico = servicos.find((s) => s.id === servicoSelecionadoId)
    if (!servico) return

    setServicosSelecionados((prev) => {
      if (prev.some((item) => item.id === servico.id)) return prev
      return [...prev, servico]
    })

    setServicoSelecionadoId('')
  }

  function removerServico(id: string) {
    setServicosSelecionados((prev) => prev.filter((item) => item.id !== id))
  }

  function duracaoSelecionada() {
    const base = servicosSelecionados.reduce(
      (acc, item) => acc + Number(item.duracao_padrao_minutos || 0),
      0
    )
    return base > 0 ? base + DESCANSO_MIN : 0
  }

  function duracaoTotalAgendamento(item: Agendamento) {
    if (item.agendamento_servicos?.length) {
      return item.agendamento_servicos.reduce(
        (acc, servico) => acc + Number(servico.duracao || 0),
        0
      )
    }

    const servicoBase = servicos.find((s) => s.id === item.servico_id)
    return Number(servicoBase?.duracao_padrao_minutos || 0)
  }

  function nomeDosServicos(item: Agendamento) {
    if (item.agendamento_servicos?.length) {
      return item.agendamento_servicos
        .sort((a, b) => Number(a.ordem || 0) - Number(b.ordem || 0))
        .map((s) => s.servicos?.nome)
        .filter(Boolean)
        .join(' + ')
    }

    const servico = servicos.find((s) => s.id === item.servico_id)
    return servico?.nome || '-'
  }

  function existeConflitoHorario(
    profId: string,
    data: string,
    horaInicio: string,
    duracao: number,
    ignorarId?: string | null
  ) {
    const inicioNovo = horaParaMinutos(horaInicio)
    const fimNovo = inicioNovo + duracao

    return agendamentos.some((item) => {
      if (ignorarId && item.id === ignorarId) return false
      if (item.status === 'cancelado') return false
      if (item.profissional_id !== profId) return false
      if (item.data_agendamento !== data) return false

      const inicioExistente = horaParaMinutos(item.hora)
      const fimExistente =
        inicioExistente + duracaoTotalAgendamento(item) + DESCANSO_MIN

      return inicioNovo < fimExistente && fimNovo > inicioExistente
    })
  }

  async function salvarItensAgendamento(agendamentoId: string) {
    const itens = servicosSelecionados.map((servico, index) => {
      const valorUnitario =
        usarPromocao && Number(servico.preco_promocional || 0) > 0
          ? Number(servico.preco_promocional || 0)
          : Number(servico.preco || 0)

      return {
        agendamento_id: agendamentoId,
        servico_id: servico.id,
        ordem: index + 1,
        valor: valorUnitario,
        duracao: Number(servico.duracao_padrao_minutos || 0),
      }
    })

    if (!itens.length) return

    const { error } = await supabase.from('agendamento_servicos').insert(itens)
    if (error) throw error
  }

  async function salvarAgendamento() {
    if (!empresa?.id) return

    setErro('')
    setSucesso('')

    if (!clienteId || !profissionalId || !dataAgendamento || !hora) {
      setErro('Preencha cliente, profissional, data e hora.')
      return
    }

    if (!servicosSelecionados.length) {
      setErro('Selecione pelo menos um serviço.')
      return
    }

    const duracao = duracaoSelecionada()

    if (
      existeConflitoHorario(
        profissionalId,
        dataAgendamento,
        hora,
        duracao,
        agendamentoEditandoId
      )
    ) {
      setErro('Já existe agendamento nesse horário.')
      return
    }

    setSaving(true)

    try {
      const primeiroServico = servicosSelecionados[0]

      const payload = {
        empresa_id: empresa.id,
        cliente_id: clienteId,
        profissional_id: profissionalId,
        servico_id: primeiroServico.id,
        data_agendamento: dataAgendamento,
        hora,
        status: 'pendente',
        valor_cobrado: Number(valorCobrado || 0),
        valor_pago: 0,
        status_pagamento: 'nao_pago',
      }

      if (agendamentoEditandoId) {
        const { error: updateError } = await supabase
          .from('agendamentos')
          .update(payload)
          .eq('id', agendamentoEditandoId)
          .eq('empresa_id', empresa.id)

        if (updateError) throw updateError

        const { error: deleteItensError } = await supabase
          .from('agendamento_servicos')
          .delete()
          .eq('agendamento_id', agendamentoEditandoId)

        if (deleteItensError) throw deleteItensError

        await salvarItensAgendamento(agendamentoEditandoId)
        setSucesso('Agendamento reagendado com sucesso.')
      } else {
        const { data, error } = await supabase
          .from('agendamentos')
          .insert([payload])
          .select()
          .single()

        if (error) throw error

        await salvarItensAgendamento(data.id)
        setSucesso('Agendamento salvo com sucesso.')
      }

      limparFormulario()
      setAbaAtiva('calendario')
      setDataAgendaVisual(dataAgendamento)
      await carregarDados()
    } catch (error: any) {
      console.error(error)
      setErro(error?.message || 'Erro ao salvar agendamento.')
    } finally {
      setSaving(false)
    }
  }

  async function atualizarStatusAgendamento(id: string, status: string) {
    if (!empresa?.id) return

    setErro('')
    setSucesso('')

    const { error } = await supabase
      .from('agendamentos')
      .update({ status })
      .eq('id', id)
      .eq('empresa_id', empresa.id)

    if (error) {
      setErro('Não foi possível atualizar o status.')
      return
    }

    setSucesso('Status atualizado com sucesso.')
    await carregarDados()
  }

  function enviarWhatsapp(item: Agendamento) {
    const cliente = clientes.find((c) => c.id === item.cliente_id)
    const profissional = profissionais.find((p) => p.id === item.profissional_id)
    const telefone = limparTelefoneWhatsapp(cliente?.telefone)

    if (!telefone) {
      setErro('Cliente sem telefone cadastrado.')
      return
    }

    const texto = `Olá, ${cliente?.nome || 'cliente'}!

Seu agendamento está registrado em ${empresa?.nome || 'nossa agenda'}.

Data: ${item.data_agendamento}
Horário: ${item.hora}
Serviço(s): ${nomeDosServicos(item)}
Profissional: ${profissional?.nome || '-'}

Confirmar:
${gerarLinkConfirmacao(item.id, (empresa as any)?.slug)}

Reagendar:
${gerarLinkReagendamento(item.id, (empresa as any)?.slug)}

Cancelar:
${gerarLinkCancelamento(item.id, (empresa as any)?.slug)}`

    window.open(
      `https://wa.me/55${telefone}?text=${encodeURIComponent(texto)}`,
      '_blank'
    )
  }

  const alertasAnamnese = gerarAlertasAnamnese(anamneseCliente)

  const horariosDisponiveis = useMemo(() => {
    if (!dataAgendamento || !profissionalId || !servicosSelecionados.length) {
      return HORARIOS_BASE.map((h) => ({ hora: h, livre: false }))
    }

    const duracao = duracaoSelecionada()

    return HORARIOS_BASE.map((h) => ({
      hora: h,
      livre: !existeConflitoHorario(
        profissionalId,
        dataAgendamento,
        h,
        duracao,
        agendamentoEditandoId
      ),
    }))
  }, [
    dataAgendamento,
    profissionalId,
    servicosSelecionados,
    agendamentos,
    agendamentoEditandoId,
  ])

  const agendamentosCalendario = useMemo(() => {
    return agendamentos
      .filter((item) => {
        if (
          filtroInicioCalendario &&
          item.data_agendamento < filtroInicioCalendario
        ) return false
        if (filtroFimCalendario && item.data_agendamento > filtroFimCalendario)
          return false
        if (
          filtroStatusCalendario !== 'todos' &&
          item.status !== filtroStatusCalendario
        ) return false
        if (
          filtroProfissionalCalendario !== 'todos' &&
          item.profissional_id !== filtroProfissionalCalendario
        ) return false
        return true
      })
      .sort((a, b) =>
        `${a.data_agendamento} ${a.hora}`.localeCompare(
          `${b.data_agendamento} ${b.hora}`
        )
      )
  }, [
    agendamentos,
    filtroInicioCalendario,
    filtroFimCalendario,
    filtroStatusCalendario,
    filtroProfissionalCalendario,
  ])

  const agendaVisual = useMemo(() => {
    return agendamentos
      .filter((item) => item.data_agendamento === dataAgendaVisual)
      .sort((a, b) => a.hora.localeCompare(b.hora))
  }, [agendamentos, dataAgendaVisual])

  const agendamentosCaixa = useMemo(() => {
    return agendamentos.filter((item) => {
      if (filtroInicioCaixa && item.data_agendamento < filtroInicioCaixa)
        return false
      if (filtroFimCaixa && item.data_agendamento > filtroFimCaixa) return false
      if (filtroStatusCaixa !== 'todos' && item.status !== filtroStatusCaixa)
        return false
      return true
    })
  }, [agendamentos, filtroInicioCaixa, filtroFimCaixa, filtroStatusCaixa])

  const resumoCaixa = useMemo(() => {
    const total = agendamentosCaixa.reduce(
      (acc, item) => acc + Number(item.valor_cobrado || 0),
      0
    )
    const recebido = agendamentosCaixa.reduce(
      (acc, item) => acc + Number(item.valor_pago || 0),
      0
    )
    const pendente = Math.max(total - recebido, 0)

    return { total, recebido, pendente }
  }, [agendamentosCaixa])

  if (loading || carregandoDados) {
    return <div style={{ padding: 24 }}>Carregando agenda...</div>
  }

  if (!empresa?.id) {
    return <div style={{ padding: 24 }}>Empresa não encontrada.</div>
  }

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
        <button
          type="button"
          onClick={() => setAbaAtiva('novo')}
          style={abaAtiva === 'novo' ? botaoPrimarioTema(tema) : botaoSecundarioTema(tema)}
        >
          Novo agendamento
        </button>

        <button
          type="button"
          onClick={() => setAbaAtiva('calendario')}
          style={abaAtiva === 'calendario' ? botaoPrimarioTema(tema) : botaoSecundarioTema(tema)}
        >
          Calendário
        </button>

        <button
          type="button"
          onClick={() => setAbaAtiva('caixa')}
          style={abaAtiva === 'caixa' ? botaoPrimarioTema(tema) : botaoSecundarioTema(tema)}
        >
          Caixa
        </button>
      </div>

      {erro ? <div style={{ ...alertaErro, marginBottom: 16 }}>{erro}</div> : null}
      {sucesso ? <div style={{ ...alertaSucesso, marginBottom: 16 }}>{sucesso}</div> : null}

      {abaAtiva === 'novo' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 0.8fr', gap: 20 }}>
          <div style={cardTema(tema)}>
            <h2 style={{ marginTop: 0 }}>Novo agendamento</h2>

            <div style={grid2}>
              <div>
                <label style={label}>Cliente</label>
                <select
                  style={input}
                  value={clienteId}
                  onChange={(e) => setClienteId(e.target.value)}
                >
                  <option value="">Selecione</option>
                  {clientes.map((cliente) => (
                    <option key={cliente.id} value={cliente.id}>
                      {cliente.nome}
                    </option>
                  ))}
                </select>

                {alertasAnamnese.length > 0 && (
                  <div style={{ background: '#fff7ed', border: '1px solid #fdba74', color: '#9a3412', padding: 12, borderRadius: 12, marginTop: 12 }}>
                    <strong>⚠️ Atenção na anamnese</strong>
                    <ul style={{ margin: '8px 0 0 18px' }}>
                      {alertasAnamnese.map((alerta, index) => (
                        <li key={index}>{alerta}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>

              <div>
                <label style={label}>Profissional</label>
                <select
                  style={input}
                  value={profissionalId}
                  onChange={(e) => setProfissionalId(e.target.value)}
                >
                  <option value="">Selecione</option>
                  {profissionais.map((profissional) => (
                    <option key={profissional.id} value={profissional.id}>
                      {profissional.nome}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label style={label}>Data</label>
                <input
                  type="date"
                  style={input}
                  value={dataAgendamento}
                  onChange={(e) => setDataAgendamento(e.target.value)}
                />
              </div>

              <div>
                <label style={label}>Horário selecionado</label>
                <input type="text" style={{ ...input, background: '#f9fafb' }} value={hora} readOnly />
              </div>
            </div>

            <div style={{ marginTop: 16 }}>
              <label style={label}>Adicionar serviço</label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 12 }}>
                <select
                  style={input}
                  value={servicoSelecionadoId}
                  onChange={(e) => setServicoSelecionadoId(e.target.value)}
                >
                  <option value="">Selecione um serviço</option>
                  {servicos.map((servico) => (
                    <option key={servico.id} value={servico.id}>
                      {servico.nome}
                    </option>
                  ))}
                </select>

                <button type="button" style={botaoSecundarioTema(tema)} onClick={adicionarServico}>
                  Adicionar
                </button>
              </div>
            </div>

            <div style={{ marginTop: 16, display: 'grid', gap: 10 }}>
              {servicosSelecionados.length === 0 ? (
                <p style={{ color: '#6b7280', margin: 0 }}>Nenhum serviço selecionado.</p>
              ) : (
                servicosSelecionados.map((servico) => (
                  <div
                    key={servico.id}
                    style={{
                      border: '1px solid #e5e7eb',
                      borderRadius: 14,
                      padding: 12,
                      display: 'flex',
                      justifyContent: 'space-between',
                      gap: 12,
                      background: '#fafafa',
                    }}
                  >
                    <div>
                      <strong>{servico.nome}</strong>
                      <div style={{ color: '#6b7280', marginTop: 4 }}>
                        {moeda(
                          usarPromocao && Number(servico.preco_promocional || 0) > 0
                            ? Number(servico.preco_promocional)
                            : Number(servico.preco || 0)
                        )}{' '}
                        • {Number(servico.duracao_padrao_minutos || 0)} min
                      </div>
                    </div>

                    <button
                      type="button"
                      style={botaoSecundarioTema(tema)}
                      onClick={() => removerServico(servico.id)}
                    >
                      Remover
                    </button>
                  </div>
                ))
              )}
            </div>

            <div style={{ marginTop: 18, display: 'grid', gap: 12 }}>
              <label style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <input
                  type="checkbox"
                  checked={usarPromocao}
                  onChange={(e) => setUsarPromocao(e.target.checked)}
                />
                Usar valor promocional
              </label>

              <div>
                <label style={label}>Valor cobrado</label>
                <input
                  style={input}
                  value={valorCobrado}
                  onChange={(e) => setValorCobrado(e.target.value)}
                />
              </div>
            </div>

            <div style={{ display: 'flex', gap: 12, marginTop: 18, flexWrap: 'wrap' }}>
              <button type="button" style={botaoPrimarioTema(tema)} disabled={saving} onClick={salvarAgendamento}>
                {saving ? 'Salvando...' : agendamentoEditandoId ? 'Salvar reagendamento' : 'Salvar agendamento'}
              </button>

              <button type="button" style={botaoSecundarioTema(tema)} onClick={limparFormulario}>
                Limpar
              </button>
            </div>
          </div>

          <div style={cardTema(tema)}>
            <h2 style={{ marginTop: 0 }}>Horários disponíveis</h2>
            <p style={{ color: '#6b7280' }}>
              Os horários consideram duração total + 10 minutos de descanso.
            </p>

            <div style={horariosGrid}>
              {horariosDisponiveis.map((item) => (
                <button
                  key={item.hora}
                  type="button"
                  disabled={!item.livre}
                  onClick={() => setHora(item.hora)}
                  style={{
                    ...horarioBase,
                    background: hora === item.hora ? tema.corSecundaria : item.livre ? '#ecfdf3' : '#f3f4f6',
                    color: hora === item.hora ? '#fff' : '#111827',
                    cursor: item.livre ? 'pointer' : 'not-allowed',
                  }}
                >
                  {item.hora}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {abaAtiva === 'calendario' && (
        <div style={{ display: 'grid', gap: 20 }}>
          <div style={cardTema(tema)}>
            <h2 style={{ marginTop: 0 }}>Filtros do calendário</h2>

            <div style={grid4}>
              <div>
                <label style={label}>Data início</label>
                <input type="date" style={input} value={filtroInicioCalendario} onChange={(e) => setFiltroInicioCalendario(e.target.value)} />
              </div>

              <div>
                <label style={label}>Data fim</label>
                <input type="date" style={input} value={filtroFimCalendario} onChange={(e) => setFiltroFimCalendario(e.target.value)} />
              </div>

              <div>
                <label style={label}>Status</label>
                <select style={input} value={filtroStatusCalendario} onChange={(e) => setFiltroStatusCalendario(e.target.value)}>
                  <option value="todos">Todos</option>
                  <option value="pendente">Pendente</option>
                  <option value="confirmado">Confirmado</option>
                  <option value="finalizado">Finalizado</option>
                  <option value="cancelado">Cancelado</option>
                </select>
              </div>

              <div>
                <label style={label}>Profissional</label>
                <select style={input} value={filtroProfissionalCalendario} onChange={(e) => setFiltroProfissionalCalendario(e.target.value)}>
                  <option value="todos">Todos</option>
                  {profissionais.map((profissional) => (
                    <option key={profissional.id} value={profissional.id}>
                      {profissional.nome}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div style={cardTema(tema)}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
              <div>
                <h2 style={{ marginTop: 0 }}>Agenda visual do dia</h2>
                <p style={{ color: '#6b7280' }}>{dataAgendaVisual}</p>
              </div>

              <div>
                <label style={label}>Data visual</label>
                <input type="date" style={input} value={dataAgendaVisual} onChange={(e) => setDataAgendaVisual(e.target.value)} />
              </div>
            </div>

            <div style={{ marginTop: 16, display: 'grid', gap: 12 }}>
              {agendaVisual.length === 0 ? (
                <p style={{ color: '#6b7280' }}>Nenhum agendamento no dia selecionado.</p>
              ) : (
                agendaVisual.map((item) => {
                  const cliente = clientes.find((c) => c.id === item.cliente_id)
                  const profissional = profissionais.find((p) => p.id === item.profissional_id)
                  const anamneseDoCliente = anamnesesMap[item.cliente_id] || null
                  const alertasDoCard = gerarAlertasAnamnese(anamneseDoCliente)

                  return (
                    <div
                      key={item.id}
                      style={{
                        border: '1px solid #e5e7eb',
                        borderRadius: 16,
                        padding: 16,
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
                        <div>
                          <strong>{cliente?.nome || '-'}</strong>
                          <div style={{ color: '#6b7280', marginTop: 4 }}>
                            {item.data_agendamento} • {item.hora}
                          </div>
                        </div>

                        <span
                          style={{
                            padding: '8px 12px',
                            borderRadius: 999,
                            background: statusPagamentoCor(item.status_pagamento),
                            fontWeight: 700,
                          }}
                        >
                          {labelStatusPagamento(item.status_pagamento)}
                        </span>
                      </div>

                      <div style={{ marginTop: 10, color: '#374151' }}>
                        Profissional: {profissional?.nome || '-'}
                      </div>
                      <div style={{ marginTop: 4, color: '#374151' }}>
                        Serviço(s): {nomeDosServicos(item)}
                      </div>
                      <div style={{ marginTop: 4, color: '#374151' }}>
                        Status: {labelStatusAgendamento(item.status)}
                      </div>
                      <div style={{ marginTop: 4, color: '#374151' }}>
                        Valor: {moeda(Number(item.valor_cobrado || 0))}
                      </div>

                      {alertasDoCard.length > 0 && (
                        <div style={{ background: '#fff7ed', border: '1px solid #fdba74', color: '#9a3412', padding: 12, borderRadius: 12, marginTop: 12 }}>
                          <strong>⚠️ Atenção na anamnese</strong>
                          <ul style={{ margin: '8px 0 0 18px' }}>
                            {alertasDoCard.map((alerta, index) => (
                              <li key={index}>{alerta}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div style={{ marginTop: 12, display: 'grid', gap: 6 }}>
                        <a
                          href={gerarLinkConfirmacao(item.id, (empresa as any)?.slug)}
                          target="_blank"
                          rel="noreferrer"
                          style={{
                            color: tema.corSecundaria,
                            fontWeight: 600,
                            textDecoration: 'none',
                          }}
                        >
                          Link de confirmação
                        </a>

                        <a
                          href={gerarLinkReagendamento(item.id, (empresa as any)?.slug)}
                          target="_blank"
                          rel="noreferrer"
                          style={{
                            color: tema.corSecundaria,
                            fontWeight: 600,
                            textDecoration: 'none',
                          }}
                        >
                          Link de reagendamento
                        </a>

                        <a
                          href={gerarLinkCancelamento(item.id, (empresa as any)?.slug)}
                          target="_blank"
                          rel="noreferrer"
                          style={{
                            color: tema.corSecundaria,
                            fontWeight: 600,
                            textDecoration: 'none',
                          }}
                        >
                          Link de cancelamento
                        </a>
                      </div>

                      <div style={{ display: 'flex', gap: 8, marginTop: 14, flexWrap: 'wrap' }}>
                        <button type="button" style={botaoSecundarioTema(tema)} onClick={() => atualizarStatusAgendamento(item.id, 'confirmado')}>
                          Confirmar
                        </button>

                        <button type="button" style={botaoSecundarioTema(tema)} onClick={() => atualizarStatusAgendamento(item.id, 'cancelado')}>
                          Cancelar
                        </button>

                        <button
                          type="button"
                          style={botaoSecundarioTema(tema)}
                          onClick={() => {
                            const servicosDoAgendamento =
                              item.agendamento_servicos?.length
                                ? (item.agendamento_servicos
                                    .map((s) => s.servicos)
                                    .filter(Boolean) as Servico[])
                                : servicos.filter((s) => s.id === item.servico_id)

                            setAgendamentoEditandoId(item.id)
                            setClienteId(item.cliente_id)
                            setProfissionalId(item.profissional_id)
                            setDataAgendamento(item.data_agendamento)
                            setHora(item.hora)
                            setServicosSelecionados(servicosDoAgendamento)
                            setValorCobrado(String(Number(item.valor_cobrado || 0)))
                            setAbaAtiva('novo')
                            window.scrollTo({ top: 0, behavior: 'smooth' })
                          }}
                        >
                          Reagendar
                        </button>

                        <button type="button" style={botaoPrimarioTema(tema)} onClick={() => enviarWhatsapp(item)}>
                          WhatsApp
                        </button>
                      </div>
                    </div>
                  )
                })
              )}
            </div>
          </div>

          <div style={cardTema(tema)}>
            <h2 style={{ marginTop: 0 }}>Lista de agendamentos</h2>

            <div style={{ overflowX: 'auto' }}>
              <table style={table}>
                <thead>
                  <tr>
                    <th style={th}>Data</th>
                    <th style={th}>Hora</th>
                    <th style={th}>Cliente</th>
                    <th style={th}>Profissional</th>
                    <th style={th}>Serviços</th>
                    <th style={th}>Status</th>
                    <th style={th}>Pagamento</th>
                    <th style={th}>Valor</th>
                  </tr>
                </thead>
                <tbody>
                  {agendamentosCalendario.map((item) => {
                    const cliente = clientes.find((c) => c.id === item.cliente_id)
                    const profissional = profissionais.find((p) => p.id === item.profissional_id)

                    return (
                      <tr key={item.id}>
                        <td style={td}>{item.data_agendamento}</td>
                        <td style={td}>{item.hora}</td>
                        <td style={td}>{cliente?.nome || '-'}</td>
                        <td style={td}>{profissional?.nome || '-'}</td>
                        <td style={td}>{nomeDosServicos(item)}</td>
                        <td style={td}>{labelStatusAgendamento(item.status)}</td>
                        <td style={td}>{labelStatusPagamento(item.status_pagamento)}</td>
                        <td style={td}>{moeda(Number(item.valor_cobrado || 0))}</td>
                      </tr>
                    )
                  })}

                  {agendamentosCalendario.length === 0 ? (
                    <tr>
                      <td style={td} colSpan={8}>
                        Nenhum agendamento encontrado.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {abaAtiva === 'caixa' && (
        <div style={{ display: 'grid', gap: 20 }}>
          <div style={cardTema(tema)}>
            <h2 style={{ marginTop: 0 }}>Filtros do caixa</h2>

            <div style={grid3}>
              <div>
                <label style={label}>Data início</label>
                <input type="date" style={input} value={filtroInicioCaixa} onChange={(e) => setFiltroInicioCaixa(e.target.value)} />
              </div>

              <div>
                <label style={label}>Data fim</label>
                <input type="date" style={input} value={filtroFimCaixa} onChange={(e) => setFiltroFimCaixa(e.target.value)} />
              </div>

              <div>
                <label style={label}>Status</label>
                <select style={input} value={filtroStatusCaixa} onChange={(e) => setFiltroStatusCaixa(e.target.value)}>
                  <option value="todos">Todos</option>
                  <option value="pendente">Pendente</option>
                  <option value="confirmado">Confirmado</option>
                  <option value="finalizado">Finalizado</option>
                  <option value="cancelado">Cancelado</option>
                </select>
              </div>
            </div>
          </div>

          <div style={grid3}>
            <div style={cardTema(tema)}>
              <div style={{ color: '#6b7280', marginBottom: 8 }}>Faturamento total</div>
              <div style={{ fontSize: 28, fontWeight: 800, color: tema.corSecundaria }}>
                {moeda(resumoCaixa.total)}
              </div>
            </div>

            <div style={cardTema(tema)}>
              <div style={{ color: '#6b7280', marginBottom: 8 }}>Recebido</div>
              <div style={{ fontSize: 28, fontWeight: 800, color: tema.corSecundaria }}>
                {moeda(resumoCaixa.recebido)}
              </div>
            </div>

            <div style={cardTema(tema)}>
              <div style={{ color: '#6b7280', marginBottom: 8 }}>Pendente</div>
              <div style={{ fontSize: 28, fontWeight: 800, color: tema.corSecundaria }}>
                {moeda(resumoCaixa.pendente)}
              </div>
            </div>
          </div>

          <div style={cardTema(tema)}>
            <h2 style={{ marginTop: 0 }}>Lançamentos</h2>

            <div style={{ overflowX: 'auto' }}>
              <table style={table}>
                <thead>
                  <tr>
                    <th style={th}>Data</th>
                    <th style={th}>Cliente</th>
                    <th style={th}>Status</th>
                    <th style={th}>Pagamento</th>
                    <th style={th}>Valor</th>
                    <th style={th}>Pago</th>
                  </tr>
                </thead>
                <tbody>
                  {agendamentosCaixa.map((item) => {
                    const cliente = clientes.find((c) => c.id === item.cliente_id)

                    return (
                      <tr key={item.id}>
                        <td style={td}>{item.data_agendamento}</td>
                        <td style={td}>{cliente?.nome || '-'}</td>
                        <td style={td}>{labelStatusAgendamento(item.status)}</td>
                        <td style={td}>{labelStatusPagamento(item.status_pagamento)}</td>
                        <td style={td}>{moeda(Number(item.valor_cobrado || 0))}</td>
                        <td style={td}>{moeda(Number(item.valor_pago || 0))}</td>
                      </tr>
                    )
                  })}

                  {agendamentosCaixa.length === 0 ? (
                    <tr>
                      <td style={td} colSpan={6}>
                        Nenhum lançamento encontrado.
                      </td>
                    </tr>
                  ) : null}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

const grid2: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: 16,
}

const grid3: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(3, 1fr)',
  gap: 16,
}

const grid4: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(4, 1fr)',
  gap: 16,
}

const label: React.CSSProperties = {
  display: 'block',
  marginBottom: 6,
  fontWeight: 700,
}

const input: React.CSSProperties = {
  width: '100%',
  border: '1px solid #d1d5db',
  borderRadius: 12,
  padding: '12px 14px',
  fontSize: 14,
  background: '#fff',
}

const horariosGrid: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(4, 1fr)',
  gap: 10,
}

const horarioBase: React.CSSProperties = {
  border: '1px solid #e5e7eb',
  borderRadius: 14,
  padding: '12px 10px',
  fontWeight: 700,
}

const table: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
}

const th: React.CSSProperties = {
  textAlign: 'left',
  padding: '12px 14px',
  borderBottom: '1px solid #e5e7eb',
  fontSize: 12,
  textTransform: 'uppercase',
  color: '#6b7280',
}

const td: React.CSSProperties = {
  padding: '12px 14px',
  borderBottom: '1px solid #f3f4f6',
}

const alertaErro: React.CSSProperties = {
  background: '#fff1f2',
  border: '1px solid #fecdd3',
  color: '#9f1239',
  padding: 12,
  borderRadius: 12,
}

const alertaSucesso: React.CSSProperties = {
  background: '#ecfdf3',
  border: '1px solid #bbf7d0',
  color: '#166534',
  padding: 12,
  borderRadius: 12,
}
