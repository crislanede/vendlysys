'use client'

import { useEffect, useMemo, useState } from 'react'
import Link from 'next/link'
import { supabase } from '@/lib/supabase'
import { getEmpresaBySlug, Empresa } from '@/lib/getEmpresa'

type Agendamento = {
  id: string
  empresa_id: string
  cliente_id: string
  servico_id: string
  profissional_id?: string | null
  data_agendamento: string
  hora: string
  valor_cobrado?: number | null
  forma_pagamento?: string | null
  clientes?: { nome: string } | null
  servicos?: { nome: string } | null
}

export default function AgendaPage() {
  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([])
  const [dataInicial, setDataInicial] = useState('')
  const [dataFinal, setDataFinal] = useState('')
  const [loading, setLoading] = useState(true)

  async function carregar() {
    const emp = await getEmpresaBySlug()
    setEmpresa(emp)

    if (!emp) {
      setLoading(false)
      return
    }

    const hoje = new Date().toISOString().slice(0, 10)
    const inicial = dataInicial || hoje
    const final = dataFinal || hoje

    const { data, error } = await supabase
      .from('agendamentos')
      .select('*, clientes(nome), servicos(nome)')
      .eq('empresa_id', emp.id)
      .gte('data_agendamento', inicial)
      .lte('data_agendamento', final)
      .order('data_agendamento', { ascending: true })
      .order('hora', { ascending: true })

    if (error) {
      console.error(error)
    }

    setAgendamentos(data || [])
    setLoading(false)
  }

  useEffect(() => {
    const hoje = new Date().toISOString().slice(0, 10)
    setDataInicial(hoje)
    setDataFinal(hoje)
  }, [])

  useEffect(() => {
    if (dataInicial && dataFinal) {
      carregar()
    }
  }, [dataInicial, dataFinal])

  const totalPeriodo = useMemo(() => {
    return agendamentos.reduce(
      (acc, item) => acc + Number(item.valor_cobrado || 0),
      0
    )
  }, [agendamentos])

  const corPrimaria = empresa?.cor_primaria || '#b8956f'
  const corSecundaria = empresa?.cor_secundaria || '#6f4b3d'

  if (loading) {
    return <div style={boxStyle}>Carregando agenda...</div>
  }

  if (!empresa) {
    return <div style={boxStyle}>Empresa não encontrada.</div>
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <section
        style={{
          ...boxStyle,
          borderTop: `5px solid ${corPrimaria}`,
          background: 'linear-gradient(180deg, #ffffff 0%, #fcfaf9 100%)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div
            style={{
              width: 54,
              height: 54,
              borderRadius: 16,
              background: `linear-gradient(135deg, ${corSecundaria}, ${corPrimaria})`,
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 800,
              fontSize: 20,
              flexShrink: 0,
              boxShadow: '0 8px 20px rgba(0,0,0,0.10)',
            }}
          >
            📅
          </div>

          <div style={{ flex: 1 }}>
            <p
              style={{
                margin: 0,
                fontSize: 12,
                fontWeight: 800,
                letterSpacing: 1,
                textTransform: 'uppercase',
                color: '#6b7280',
              }}
            >
              Agenda
            </p>

            <h1
              style={{
                margin: '6px 0 0 0',
                fontSize: 32,
                lineHeight: 1.1,
                color: '#111827',
              }}
            >
              Agenda operacional
            </h1>

            <p
              style={{
                margin: '8px 0 0 0',
                fontSize: 15,
                color: '#6b7280',
              }}
            >
              Visão operacional dos agendamentos da empresa.
            </p>
          </div>

          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
            <Link href="/agendamentos" style={botaoPrimarioStyle}>
              + Novo agendamento
            </Link>
          </div>
        </div>
      </section>

      <section style={boxStyle}>
        <div style={secaoHeaderStyle}>
          <div>
            <h2 style={secaoTituloStyle}>Filtros do período</h2>
            <p style={secaoTextoStyle}>
              Escolha o intervalo para visualizar os agendamentos.
            </p>
          </div>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: 16,
          }}
        >
          <div style={campoStyle}>
            <label style={labelStyle}>Data inicial</label>
            <input
              style={inputStyle}
              type="date"
              value={dataInicial}
              onChange={(e) => setDataInicial(e.target.value)}
            />
          </div>

          <div style={campoStyle}>
            <label style={labelStyle}>Data final</label>
            <input
              style={inputStyle}
              type="date"
              value={dataFinal}
              onChange={(e) => setDataFinal(e.target.value)}
            />
          </div>

          <div
            style={{
              background: '#f9fafb',
              borderRadius: 16,
              padding: 16,
              border: '1px solid #ececec',
              display: 'grid',
              alignContent: 'center',
            }}
          >
            <span
              style={{
                fontSize: 13,
                color: '#6b7280',
                fontWeight: 700,
              }}
            >
              Total do período
            </span>

            <strong
              style={{
                marginTop: 8,
                fontSize: 28,
                color: '#111827',
                lineHeight: 1.1,
              }}
            >
              R$ {totalPeriodo.toFixed(2)}
            </strong>
          </div>
        </div>
      </section>

      <section style={boxStyle}>
        <div style={secaoHeaderStyle}>
          <div>
            <h2 style={secaoTituloStyle}>Agendamentos encontrados</h2>
            <p style={secaoTextoStyle}>
              Lista dos atendimentos dentro do período selecionado.
            </p>
          </div>
        </div>

        {agendamentos.length === 0 ? (
          <div style={vazioStyle}>Nenhum agendamento encontrado no período.</div>
        ) : (
          <div style={{ display: 'grid', gap: 12 }}>
            {agendamentos.map((item) => (
              <div
                key={item.id}
                style={{
                  background: '#f9fafb',
                  borderRadius: 16,
                  padding: 16,
                  border: '1px solid #ececec',
                  display: 'grid',
                  gridTemplateColumns: '1.5fr 1fr 0.8fr',
                  gap: 12,
                  alignItems: 'center',
                }}
              >
                <div>
                  <div style={itemPrincipalStyle}>
                    {item.clientes?.nome || 'Cliente'}
                  </div>
                  <div style={itemSecundarioStyle}>
                    {item.servicos?.nome || 'Serviço'}
                  </div>
                </div>

                <div>
                  <div style={itemLabelStyle}>Data</div>
                  <div style={itemValorStyle}>
                    {formatarData(item.data_agendamento)}
                  </div>

                  <div style={{ height: 8 }} />

                  <div style={itemLabelStyle}>Hora</div>
                  <div style={itemValorStyle}>{item.hora}</div>
                </div>

                <div style={{ textAlign: 'right' }}>
                  <div style={itemLabelStyle}>Valor</div>
                  <div
                    style={{
                      fontSize: 20,
                      fontWeight: 800,
                      color: '#111827',
                    }}
                  >
                    R$ {Number(item.valor_cobrado || 0).toFixed(2)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  )
}

function formatarData(data: string) {
  if (!data) return '-'
  const [ano, mes, dia] = data.split('-')
  return `${dia}/${mes}/${ano}`
}

const boxStyle: React.CSSProperties = {
  background: '#ffffff',
  borderRadius: 20,
  padding: 24,
  boxShadow: '0 4px 14px rgba(0,0,0,0.06)',
}

const secaoHeaderStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  gap: 12,
  flexWrap: 'wrap',
  marginBottom: 14,
}

const secaoTituloStyle: React.CSSProperties = {
  margin: 0,
  fontSize: 22,
  color: '#111827',
}

const secaoTextoStyle: React.CSSProperties = {
  margin: '6px 0 0 0',
  color: '#6b7280',
  fontSize: 14,
}

const campoStyle: React.CSSProperties = {
  display: 'grid',
  gap: 8,
}

const labelStyle: React.CSSProperties = {
  fontSize: 14,
  fontWeight: 700,
  color: '#374151',
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  border: '1px solid #d1d5db',
  borderRadius: 12,
  padding: '12px 14px',
  fontSize: 14,
  outline: 'none',
  background: '#fff',
}

const botaoPrimarioStyle: React.CSSProperties = {
  textDecoration: 'none',
  background: '#111827',
  color: '#fff',
  padding: '12px 18px',
  borderRadius: 14,
  fontWeight: 800,
  display: 'inline-flex',
  alignItems: 'center',
}

const vazioStyle: React.CSSProperties = {
  background: '#f9fafb',
  borderRadius: 16,
  padding: 18,
  border: '1px solid #ececec',
  color: '#6b7280',
}

const itemPrincipalStyle: React.CSSProperties = {
  fontSize: 16,
  fontWeight: 700,
  color: '#111827',
}

const itemSecundarioStyle: React.CSSProperties = {
  marginTop: 6,
  color: '#6b7280',
  fontSize: 14,
}

const itemLabelStyle: React.CSSProperties = {
  fontSize: 12,
  fontWeight: 700,
  color: '#6b7280',
  textTransform: 'uppercase',
  letterSpacing: 0.5,
}

const itemValorStyle: React.CSSProperties = {
  fontSize: 14,
  color: '#111827',
  fontWeight: 600,
}