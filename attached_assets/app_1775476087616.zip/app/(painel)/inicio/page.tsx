'use client'

import Link from 'next/link'
import { useMemo } from 'react'
import { useSessaoEmpresa } from '@/lib/useSessaoEmpresa'

type Modulo = {
  titulo: string
  descricao: string
  href: string
  icone: string
  perfis: string[]
}

const MODULOS: Modulo[] = [
  {
    titulo: 'Dashboard',
    descricao: 'Indicadores, gráficos e comparativos do negócio.',
    href: '/dashboard',
    icone: '📊',
    perfis: ['admin'],
  },
  {
    titulo: 'Agenda',
    descricao: 'Visualize horários, disponibilidade e organização do dia.',
    href: '/agenda',
    icone: '🗓️',
    perfis: ['admin', 'agenda'],
  },
  {
    titulo: 'Agendamentos',
    descricao: 'Gerencie marcações, status e confirmações.',
    href: '/agendamentos',
    icone: '📅',
    perfis: ['admin', 'agenda'],
  },
  {
    titulo: 'Clientes',
    descricao: 'Cadastros, histórico e informações dos clientes.',
    href: '/clientes',
    icone: '👥',
    perfis: ['admin'],
  },
  {
    titulo: 'Serviços',
    descricao: 'Cadastre serviços, duração e valores.',
    href: '/servicos',
    icone: '💼',
    perfis: ['admin'],
  },
  {
    titulo: 'Financeiro',
    descricao: 'Acompanhe recebimentos, pendências e resultados.',
    href: '/financeiro',
    icone: '💰',
    perfis: ['admin'],
  },
  {
    titulo: 'Usuários',
    descricao: 'Crie acessos internos e defina perfis.',
    href: '/usuarios',
    icone: '🔐',
    perfis: ['admin'],
  },
  {
    titulo: 'Configurações',
    descricao: 'Ajuste preferências, tema e dados da empresa.',
    href: '/configuracoes',
    icone: '⚙️',
    perfis: ['admin'],
  },
]

export default function InicioPage() {
  const { empresa, usuario, loading, perfil } = useSessaoEmpresa() as any

  const corPrimaria = empresa?.cor_primaria || '#b8956f'
  const corSecundaria = empresa?.cor_secundaria || '#6f4b3d'
  const perfilAtual = perfil || 'agenda'
  const nomeUsuario =
    usuario?.user_metadata?.nome ||
    usuario?.email ||
    'usuário'

  const modulosVisiveis = useMemo(() => {
    return MODULOS.filter((modulo) => modulo.perfis.includes(perfilAtual))
  }, [perfilAtual])

  if (loading) {
    return <div style={boxStyle}>Carregando início...</div>
  }

  if (!empresa) {
    return (
      <div
        style={{
          ...boxStyle,
          background: '#fff1f2',
          border: '1px solid #fecdd3',
          color: '#b91c1c',
        }}
      >
        <strong>Erro ao carregar início:</strong>
        <div style={{ marginTop: 8 }}>Empresa não encontrada ou usuário sem vínculo.</div>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <section
        style={{
          ...boxStyle,
          borderTop: `5px solid ${corPrimaria}`,
          background: `linear-gradient(180deg, #ffffff 0%, #fcfaf9 100%)`,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div
            style={{
              width: 58,
              height: 58,
              borderRadius: 18,
              background: `linear-gradient(135deg, ${corSecundaria}, ${corPrimaria})`,
              color: '#fff',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 800,
              fontSize: 22,
              flexShrink: 0,
              boxShadow: '0 8px 20px rgba(0,0,0,0.10)',
              overflow: 'hidden',
            }}
          >
            {empresa?.logo_url ? (
              <img
                src={empresa.logo_url}
                alt={empresa.nome}
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              />
            ) : (
              empresa?.nome?.charAt(0).toUpperCase() || 'E'
            )}
          </div>

          <div>
            <p
              style={{
                margin: 0,
                fontSize: 12,
                fontWeight: 800,
                letterSpacing: 1,
                textTransform: 'uppercase',
                color: '#6b7280',
              }}
            >
              Central do sistema
            </p>

            <h1
              style={{
                margin: '6px 0 0 0',
                fontSize: 34,
                lineHeight: 1.1,
                color: '#111827',
              }}
            >
              Olá, {nomeUsuario} 👋
            </h1>

            <p
              style={{
                margin: '8px 0 0 0',
                fontSize: 15,
                color: '#6b7280',
              }}
            >
              Bem-vinda à central de módulos da empresa {empresa?.nome}.
            </p>
          </div>
        </div>

        <div
          style={{
            marginTop: 18,
            display: 'flex',
            gap: 12,
            flexWrap: 'wrap',
          }}
        >
          <Badge texto={`Perfil: ${perfilAtual}`} />
          <Badge texto={`Empresa: ${empresa?.nome || '-'}`} />
          <Badge texto={`${modulosVisiveis.length} módulo(s) disponível(is)`} />
        </div>
      </section>

      <section style={boxStyle}>
        <div style={secaoHeaderStyle}>
          <div>
            <h2 style={secaoTituloStyle}>Sistemas disponíveis</h2>
            <p style={secaoTextoStyle}>
              Escolha um módulo para acessar.
            </p>
          </div>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: 16,
          }}
        >
          {modulosVisiveis.map((modulo) => (
            <Link
              key={modulo.href}
              href={modulo.href}
              style={{
                textDecoration: 'none',
                color: 'inherit',
              }}
            >
              <div
                style={{
                  background: '#ffffff',
                  borderRadius: 18,
                  padding: 20,
                  boxShadow: '0 6px 18px rgba(0,0,0,0.06)',
                  border: '1px solid #f1f1f1',
                  borderTop: `4px solid ${corPrimaria}`,
                  minHeight: 170,
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'space-between',
                }}
              >
                <div>
                  <div
                    style={{
                      fontSize: 30,
                      marginBottom: 10,
                    }}
                  >
                    {modulo.icone}
                  </div>

                  <h3
                    style={{
                      margin: 0,
                      fontSize: 20,
                      color: '#111827',
                    }}
                  >
                    {modulo.titulo}
                  </h3>

                  <p
                    style={{
                      margin: '10px 0 0 0',
                      fontSize: 14,
                      color: '#6b7280',
                      lineHeight: 1.5,
                    }}
                  >
                    {modulo.descricao}
                  </p>
                </div>

                <div
                  style={{
                    marginTop: 16,
                    fontSize: 14,
                    fontWeight: 800,
                    color: corSecundaria,
                  }}
                >
                  Acessar módulo →
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  )
}

function Badge({ texto }: { texto: string }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        padding: '8px 12px',
        borderRadius: 999,
        background: '#f8fafc',
        border: '1px solid #e5e7eb',
        color: '#374151',
        fontSize: 13,
        fontWeight: 700,
      }}
    >
      {texto}
    </span>
  )
}

const boxStyle: React.CSSProperties = {
  background: '#ffffff',
  borderRadius: 20,
  padding: 24,
  boxShadow: '0 4px 14px rgba(0,0,0,0.06)',
}

const secaoHeaderStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  gap: 12,
  flexWrap: 'wrap',
  marginBottom: 14,
}

const secaoTituloStyle: React.CSSProperties = {
  margin: 0,
  fontSize: 22,
  color: '#111827',
}

const secaoTextoStyle: React.CSSProperties = {
  margin: '6px 0 0 0',
  color: '#6b7280',
  fontSize: 14,
}