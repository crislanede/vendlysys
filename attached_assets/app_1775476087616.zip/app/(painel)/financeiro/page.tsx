'use client'

import { useEffect, useMemo, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { useSessaoEmpresa } from '@/lib/useSessaoEmpresa'
import ProtegePagina from '@/components/ProtegePagina'
import ProtegeOnboarding from '@/components/ProtegeOnboarding'
import AppShell from '@/components/ui/AppShell'
import HeroHeader from '@/components/ui/HeroHeader'
import { getTemaEmpresa } from '@/lib/temaEmpresa'
import {
  badgeTema,
  botaoPrimarioTema,
  botaoSecundarioTema,
  cardTema,
} from '@/lib/temaStyles'
import { ui } from '@/styles/tema'

type AgendamentoFinanceiro = {
  id: string
  empresa_id: string
  cliente_id: string | null
  profissional_id: string | null
  servico_id?: string | null
  data_agendamento: string
  hora?: string | null
  status?: string | null
  valor_cobrado?: number | null
  valor_pago?: number | null
  status_pagamento?: string | null
  forma_pagamento?: string | null
  clientes?: { nome: string } | null
  profissionais?: { nome: string } | null
  servicos?: { nome: string } | null
}

type Profissional = {
  id: string
  nome: string
}

type ResumoForma = {
  forma: string
  total: number
  quantidade: number
}

export default function FinanceiroPage() {
  return (
    <ProtegePagina>
      <ProtegeOnboarding>
        <FinanceiroConteudo />
      </ProtegeOnboarding>
    </ProtegePagina>
  )
}

function FinanceiroConteudo() {
  const { empresa, loading } = useSessaoEmpresa()
  const tema = getTemaEmpresa(empresa)

  const empresaId = empresa?.id || ''
  const empresaNome = empresa?.nome || 'Empresa'

  const hoje = new Date()
  const primeiroDiaMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1)

  const [dataInicio, setDataInicio] = useState(formatDateInput(primeiroDiaMes))
  const [dataFim, setDataFim] = useState(formatDateInput(hoje))
  const [filtroRapido, setFiltroRapido] = useState('mes-atual')

  const [statusPagamento, setStatusPagamento] = useState('')
  const [formaPagamento, setFormaPagamento] = useState('')
  const [profissionalSelecionado, setProfissionalSelecionado] = useState('')

  const [agendamentos, setAgendamentos] = useState<AgendamentoFinanceiro[]>([])
  const [profissionais, setProfissionais] = useState<Profissional[]>([])

  const [carregando, setCarregando] = useState(true)
  const [erro, setErro] = useState('')

  useEffect(() => {
    if (!empresaId) return
    carregarDados()
  }, [empresaId])

  async function carregarDados() {
    if (!empresaId) return

    try {
      setCarregando(true)
      setErro('')

      const [agendamentosRes, profissionaisRes] = await Promise.all([
        supabase
          .from('agendamentos')
          .select(
            `
            id,
            empresa_id,
            cliente_id,
            profissional_id,
            servico_id,
            data_agendamento,
            hora,
            status,
            valor_cobrado,
            valor_pago,
            status_pagamento,
            forma_pagamento,
            clientes(nome),
            profissionais(nome),
            servicos(nome)
          `
          )
          .eq('empresa_id', empresaId)
          .order('data_agendamento', { ascending: false })
          .order('hora', { ascending: false }),

        supabase
          .from('profissionais')
          .select('id, nome')
          .eq('empresa_id', empresaId)
          .order('nome', { ascending: true }),
      ])

      if (agendamentosRes.error) throw agendamentosRes.error
      if (profissionaisRes.error) throw profissionaisRes.error

      setAgendamentos((agendamentosRes.data as AgendamentoFinanceiro[]) || [])
      setProfissionais((profissionaisRes.data as Profissional[]) || [])
    } catch (error: any) {
      console.error('Erro ao carregar financeiro:', error)
      setErro(error?.message || 'Erro ao carregar financeiro.')
    } finally {
      setCarregando(false)
    }
  }

  function aplicarFiltroRapido(tipo: string) {
    const agora = new Date()
    let inicio = new Date()
    let fim = new Date()

    if (tipo === 'hoje') {
      inicio = new Date(agora)
      fim = new Date(agora)
    }

    if (tipo === '7-dias') {
      inicio = new Date(agora)
      inicio.setDate(agora.getDate() - 6)
      fim = new Date(agora)
    }

    if (tipo === '30-dias') {
      inicio = new Date(agora)
      inicio.setDate(agora.getDate() - 29)
      fim = new Date(agora)
    }

    if (tipo === 'mes-atual') {
      inicio = new Date(agora.getFullYear(), agora.getMonth(), 1)
      fim = new Date(agora)
    }

    if (tipo === 'ano-atual') {
      inicio = new Date(agora.getFullYear(), 0, 1)
      fim = new Date(agora)
    }

    setFiltroRapido(tipo)
    setDataInicio(formatDateInput(inicio))
    setDataFim(formatDateInput(fim))
  }

  function limparFiltros() {
    const agora = new Date()
    const inicio = new Date(agora.getFullYear(), agora.getMonth(), 1)

    setFiltroRapido('mes-atual')
    setDataInicio(formatDateInput(inicio))
    setDataFim(formatDateInput(agora))
    setStatusPagamento('')
    setFormaPagamento('')
    setProfissionalSelecionado('')
  }

  const listaFiltrada = useMemo(() => {
    return agendamentos.filter((item) => {
      const data = item.data_agendamento || ''
      const dentroPeriodo = data >= dataInicio && data <= dataFim

      const filtroStatus =
        !statusPagamento || (item.status_pagamento || '') === statusPagamento

      const filtroForma =
        !formaPagamento || (item.forma_pagamento || '') === formaPagamento

      const filtroProfissional =
        !profissionalSelecionado ||
        (item.profissional_id || '') === profissionalSelecionado

      return dentroPeriodo && filtroStatus && filtroForma && filtroProfissional
    })
  }, [
    agendamentos,
    dataInicio,
    dataFim,
    statusPagamento,
    formaPagamento,
    profissionalSelecionado,
  ])

  const resumo = useMemo(() => {
    const totalCobrado = listaFiltrada.reduce(
      (acc, item) => acc + Number(item.valor_cobrado || 0),
      0
    )

    const totalRecebido = listaFiltrada.reduce(
      (acc, item) => acc + Number(item.valor_pago || 0),
      0
    )

    const totalPendente = Math.max(totalCobrado - totalRecebido, 0)

    const pagos = listaFiltrada.filter(
      (item) => (item.status_pagamento || '').toLowerCase() === 'pago'
    ).length

    const pendentes = listaFiltrada.filter(
      (item) =>
        (item.status_pagamento || '').toLowerCase() === 'pendente' ||
        Number(item.valor_pago || 0) < Number(item.valor_cobrado || 0)
    ).length

    const porFormaMap = new Map<string, ResumoForma>()

    listaFiltrada.forEach((item) => {
      const forma = item.forma_pagamento || 'Não informado'
      const atual = porFormaMap.get(forma) || {
        forma,
        total: 0,
        quantidade: 0,
      }

      atual.total += Number(item.valor_pago || 0)
      atual.quantidade += 1

      porFormaMap.set(forma, atual)
    })

    const porForma = Array.from(porFormaMap.values()).sort(
      (a, b) => b.total - a.total
    )

    return {
      totalCobrado,
      totalRecebido,
      totalPendente,
      pagos,
      pendentes,
      quantidade: listaFiltrada.length,
      porForma,
    }
  }, [listaFiltrada])

  const formasPagamentoDisponiveis = useMemo(() => {
    const formas = new Set<string>()

    agendamentos.forEach((item) => {
      if (item.forma_pagamento) formas.add(item.forma_pagamento)
    })

    return Array.from(formas).sort((a, b) => a.localeCompare(b))
  }, [agendamentos])

  if (loading || carregando) {
    return (
      <AppShell>
        <div style={cardTema(tema)}>
          <h2 style={ui.sectionTitle}>Carregando financeiro...</h2>
        </div>
      </AppShell>
    )
  }

  if (!empresaId) {
    return (
      <AppShell>
        <div style={cardTema(tema)}>
          <h2 style={ui.sectionTitle}>Empresa não identificada.</h2>
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell>
      <HeroHeader
        titulo="Financeiro"
        subtitulo={`Caixa diário, recebimentos e pendências • ${empresaNome}`}
        eyebrow="Operação financeira"
      />

      {erro ? <div style={s.erro}>{erro}</div> : null}

      <div style={{ ...cardTema(tema), marginTop: 10 }}>
        <div style={s.sectionHeader}>
          <div>
            <h2 style={ui.sectionTitle}>Filtros</h2>
            <p style={ui.sectionSub}>
              Refine a visão financeira por período, status, forma de pagamento
              e profissional.
            </p>
          </div>
        </div>

        <div style={s.filtrosRapidos}>
          <button
            type="button"
            onClick={() => aplicarFiltroRapido('hoje')}
            style={
              filtroRapido === 'hoje'
                ? botaoPrimarioTema(tema)
                : botaoSecundarioTema(tema)
            }
          >
            Hoje
          </button>

          <button
            type="button"
            onClick={() => aplicarFiltroRapido('7-dias')}
            style={
              filtroRapido === '7-dias'
                ? botaoPrimarioTema(tema)
                : botaoSecundarioTema(tema)
            }
          >
            7 dias
          </button>

          <button
            type="button"
            onClick={() => aplicarFiltroRapido('30-dias')}
            style={
              filtroRapido === '30-dias'
                ? botaoPrimarioTema(tema)
                : botaoSecundarioTema(tema)
            }
          >
            30 dias
          </button>

          <button
            type="button"
            onClick={() => aplicarFiltroRapido('mes-atual')}
            style={
              filtroRapido === 'mes-atual'
                ? botaoPrimarioTema(tema)
                : botaoSecundarioTema(tema)
            }
          >
            Mês atual
          </button>

          <button
            type="button"
            onClick={() => aplicarFiltroRapido('ano-atual')}
            style={
              filtroRapido === 'ano-atual'
                ? botaoPrimarioTema(tema)
                : botaoSecundarioTema(tema)
            }
          >
            Ano atual
          </button>
        </div>

        <div style={s.gridFiltros}>
          <div style={s.field}>
            <label style={ui.label}>Data inicial</label>
            <input
              type="date"
              value={dataInicio}
              onChange={(e) => setDataInicio(e.target.value)}
              style={ui.input}
            />
          </div>

          <div style={s.field}>
            <label style={ui.label}>Data final</label>
            <input
              type="date"
              value={dataFim}
              onChange={(e) => setDataFim(e.target.value)}
              style={ui.input}
            />
          </div>

          <div style={s.field}>
            <label style={ui.label}>Status do pagamento</label>
            <select
              value={statusPagamento}
              onChange={(e) => setStatusPagamento(e.target.value)}
              style={ui.input}
            >
              <option value="">Todos</option>
              <option value="pago">Pago</option>
              <option value="pendente">Pendente</option>
              <option value="parcial">Parcial</option>
            </select>
          </div>

          <div style={s.field}>
            <label style={ui.label}>Forma de pagamento</label>
            <select
              value={formaPagamento}
              onChange={(e) => setFormaPagamento(e.target.value)}
              style={ui.input}
            >
              <option value="">Todas</option>
              {formasPagamentoDisponiveis.map((forma) => (
                <option key={forma} value={forma}>
                  {forma}
                </option>
              ))}
            </select>
          </div>

          <div style={s.field}>
            <label style={ui.label}>Profissional</label>
            <select
              value={profissionalSelecionado}
              onChange={(e) => setProfissionalSelecionado(e.target.value)}
              style={ui.input}
            >
              <option value="">Todos</option>
              {profissionais.map((profissional) => (
                <option key={profissional.id} value={profissional.id}>
                  {profissional.nome}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div style={s.actionsRow}>
          <button
            type="button"
            onClick={limparFiltros}
            style={botaoSecundarioTema(tema)}
          >
            Limpar filtros
          </button>
        </div>
      </div>

      <div style={s.gridResumo}>
        <CardFinanceiro
          titulo="Atendimentos no período"
          valor={String(resumo.quantidade)}
          tema={tema}
        />
        <CardFinanceiro
          titulo="Total cobrado"
          valor={moeda(resumo.totalCobrado)}
          tema={tema}
        />
        <CardFinanceiro
          titulo="Total recebido"
          valor={moeda(resumo.totalRecebido)}
          tema={tema}
        />
        <CardFinanceiro
          titulo="Total pendente"
          valor={moeda(resumo.totalPendente)}
          tema={tema}
        />
        <CardFinanceiro
          titulo="Pagos"
          valor={String(resumo.pagos)}
          tema={tema}
        />
        <CardFinanceiro
          titulo="Pendentes"
          valor={String(resumo.pendentes)}
          tema={tema}
        />
      </div>

      <div style={s.gridDuasColunas}>
        <div style={cardTema(tema)}>
          <div style={s.sectionHeader}>
            <div>
              <h2 style={ui.sectionTitle}>Resumo por forma de pagamento</h2>
              <p style={ui.sectionSub}>
                Total recebido agrupado por método de pagamento.
              </p>
            </div>
          </div>

          {resumo.porForma.length === 0 ? (
            <p style={s.textMuted}>Nenhum recebimento encontrado no período.</p>
          ) : (
            <div style={s.listaFormas}>
              {resumo.porForma.map((item) => (
                <div key={item.forma} style={s.formaRow}>
                  <div>
                    <div style={s.itemTitulo}>{item.forma}</div>
                    <div style={s.itemSub}>
                      {item.quantidade} lançamento(s)
                    </div>
                  </div>

                  <strong style={{ color: tema.corSecundaria }}>
                    {moeda(item.total)}
                  </strong>
                </div>
              ))}
            </div>
          )}
        </div>

        <div style={cardTema(tema)}>
          <div style={s.sectionHeader}>
            <div>
              <h2 style={ui.sectionTitle}>Caixa do período</h2>
              <p style={ui.sectionSub}>
                Visão rápida dos valores filtrados.
              </p>
            </div>
          </div>

          <div style={s.caixaResumo}>
            <div style={s.caixaLinha}>
              <span style={s.itemSub}>Período</span>
              <strong>
                {formatarDataBR(dataInicio)} até {formatarDataBR(dataFim)}
              </strong>
            </div>

            <div style={s.caixaLinha}>
              <span style={s.itemSub}>Cobrado</span>
              <strong>{moeda(resumo.totalCobrado)}</strong>
            </div>

            <div style={s.caixaLinha}>
              <span style={s.itemSub}>Recebido</span>
              <strong style={{ color: '#166534' }}>
                {moeda(resumo.totalRecebido)}
              </strong>
            </div>

            <div style={s.caixaLinha}>
              <span style={s.itemSub}>Pendente</span>
              <strong style={{ color: '#b45309' }}>
                {moeda(resumo.totalPendente)}
              </strong>
            </div>
          </div>
        </div>
      </div>

      <div style={cardTema(tema)}>
        <div style={s.sectionHeader}>
          <div>
            <h2 style={ui.sectionTitle}>Lançamentos financeiros</h2>
            <p style={ui.sectionSub}>
              Lista operacional dos agendamentos filtrados.
            </p>
          </div>
        </div>

        {listaFiltrada.length === 0 ? (
          <p style={s.textMuted}>Nenhum lançamento encontrado.</p>
        ) : (
          <div style={s.listaLancamentos}>
            {listaFiltrada.map((item) => (
              <div
                key={item.id}
                style={{
                  ...s.linhaLancamento,
                  borderLeft: `4px solid ${tema.corPrimaria}`,
                }}
              >
                <div style={s.linhaTopo}>
                  <div>
                    <div style={s.itemTitulo}>
                      {item.clientes?.nome || 'Cliente'}
                    </div>
                    <div style={s.itemSub}>
                      {item.servicos?.nome || 'Serviço'}
                      {item.profissionais?.nome
                        ? ` • ${item.profissionais.nome}`
                        : ''}
                    </div>
                  </div>

                  <div style={s.badgesWrap}>
                    {item.status_pagamento ? (
                      <span style={badgeTema(tema)}>
                        {item.status_pagamento}
                      </span>
                    ) : null}

                    {item.forma_pagamento ? (
                      <span style={badgeTema(tema)}>
                        {item.forma_pagamento}
                      </span>
                    ) : null}
                  </div>
                </div>

                <div style={s.gridLancamento}>
                  <div>
                    <div style={s.itemLabel}>Data</div>
                    <div style={s.itemValor}>
                      {formatarDataBR(item.data_agendamento)}
                    </div>
                  </div>

                  <div>
                    <div style={s.itemLabel}>Hora</div>
                    <div style={s.itemValor}>{(item.hora || '').slice(0, 5) || '-'}</div>
                  </div>

                  <div>
                    <div style={s.itemLabel}>Cobrado</div>
                    <div style={s.itemValor}>
                      {moeda(Number(item.valor_cobrado || 0))}
                    </div>
                  </div>

                  <div>
                    <div style={s.itemLabel}>Pago</div>
                    <div style={s.itemValor}>
                      {moeda(Number(item.valor_pago || 0))}
                    </div>
                  </div>

                  <div>
                    <div style={s.itemLabel}>Saldo</div>
                    <div style={s.itemValor}>
                      {moeda(
                        Number(item.valor_cobrado || 0) -
                          Number(item.valor_pago || 0)
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  )
}

function CardFinanceiro({
  titulo,
  valor,
  tema,
}: {
  titulo: string
  valor: string
  tema: ReturnType<typeof getTemaEmpresa>
}) {
  return (
    <div style={cardTema(tema)}>
      <div style={s.cardLabel}>{titulo}</div>
      <div style={{ ...s.cardValor, color: tema.corSecundaria }}>{valor}</div>
    </div>
  )
}

function moeda(valor: number) {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(Number(valor || 0))
}

function formatDateInput(data: Date) {
  return data.toISOString().split('T')[0]
}

function formatarDataBR(data: string) {
  if (!data) return '-'
  const [ano, mes, dia] = data.split('-')
  return `${dia}/${mes}/${ano}`
}

const s: Record<string, React.CSSProperties> = {
  erro: {
    background: '#fff2f1',
    border: '1px solid #ffd1cd',
    color: '#a33227',
    padding: '14px 16px',
    borderRadius: 16,
    fontWeight: 600,
    marginTop: 10,
  },
  sectionHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 14,
    flexWrap: 'wrap',
    marginBottom: 18,
  },
  filtrosRapidos: {
    display: 'flex',
    gap: 10,
    flexWrap: 'wrap',
    marginBottom: 18,
  },
  gridFiltros: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
    gap: 16,
  },
  field: {
    display: 'grid',
    gap: 8,
  },
  actionsRow: {
    display: 'flex',
    gap: 12,
    flexWrap: 'wrap',
    marginTop: 18,
  },
  gridResumo: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
    gap: 16,
    marginTop: 20,
  },
  gridDuasColunas: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 20,
  },
  cardLabel: {
    fontSize: 13,
    color: '#6b7280',
    marginBottom: 8,
    fontWeight: 700,
  },
  cardValor: {
    fontSize: 28,
    fontWeight: 800,
    lineHeight: 1.1,
  },
  textMuted: {
    margin: 0,
    color: '#6b7280',
  },
  listaFormas: {
    display: 'grid',
    gap: 12,
  },
  formaRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    border: '1px solid #ececec',
    borderRadius: 14,
    background: '#faf9f7',
  },
  caixaResumo: {
    display: 'grid',
    gap: 12,
  },
  caixaLinha: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: 12,
    padding: '10px 0',
    borderBottom: '1px solid #f1e7de',
  },
  listaLancamentos: {
    display: 'grid',
    gap: 14,
  },
  linhaLancamento: {
    border: '1px solid #ececec',
    borderRadius: 16,
    padding: 16,
    background: '#faf9f7',
  },
  linhaTopo: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: 12,
    alignItems: 'flex-start',
    flexWrap: 'wrap',
    marginBottom: 14,
  },
  badgesWrap: {
    display: 'flex',
    gap: 8,
    flexWrap: 'wrap',
  },
  gridLancamento: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
    gap: 12,
  },
  itemTitulo: {
    fontSize: 16,
    fontWeight: 700,
    color: '#3a2f28',
  },
  itemSub: {
    fontSize: 13,
    color: '#7b6858',
    marginTop: 4,
  },
  itemLabel: {
    fontSize: 11,
    color: '#8b735d',
    fontWeight: 700,
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  itemValor: {
    fontSize: 14,
    color: '#3a2f28',
    fontWeight: 600,
  },
}