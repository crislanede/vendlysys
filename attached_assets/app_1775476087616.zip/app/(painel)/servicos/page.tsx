'use client'

import React, { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import ProtegePagina from '@/components/ProtegePagina'
import { useSessaoEmpresa } from '@/lib/useSessaoEmpresa'
import AppShell from '@/components/ui/AppShell'
import HeroHeader from '@/components/ui/HeroHeader'
import { ui } from '@/styles/tema'
import { getTemaEmpresa } from '@/lib/temaEmpresa'
import {
  botaoPrimarioTema,
  botaoSecundarioTema,
  cardTema,
  badgeTema,
} from '@/lib/temaStyles'

type Servico = {
  id: string
  empresa_id?: string
  nome: string
  categoria: string
  preco: number
  preco_promocional: number | null
  preco_descricao: string | null
  ativo: boolean
}

type Aba = 'lista' | 'cadastrar'

function formatarNomePadrao(nome: string) {
  if (!nome) return ''

  const palavrasMinusculas = ['da', 'de', 'do', 'das', 'dos', 'e']

  return nome
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .map((palavra, index) => {
      if (index > 0 && palavrasMinusculas.includes(palavra)) {
        return palavra
      }

      return palavra.charAt(0).toUpperCase() + palavra.slice(1)
    })
    .join(' ')
}

export default function ServicosPage() {
  return (
    <ProtegePagina>
      <ServicosConteudo />
    </ProtegePagina>
  )
}

function ServicosConteudo() {
  const { empresa, loading } = useSessaoEmpresa()

  const tema = getTemaEmpresa(empresa)
  const empresaId = empresa?.id || ''
  const empresaNome = empresa?.nome || 'Empresa'

  const [servicos, setServicos] = useState<Servico[]>([])
  const [abaAtiva, setAbaAtiva] = useState<Aba>('lista')
  const [loadingSalvar, setLoadingSalvar] = useState(false)

  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')

  const [idEditando, setIdEditando] = useState<string | null>(null)
  const [nome, setNome] = useState('')
  const [categoria, setCategoria] = useState('Manicure e Pedicure')
  const [preco, setPreco] = useState('')
  const [precoPromo, setPrecoPromo] = useState('')
  const [descricao, setDescricao] = useState('')
  const [ativo, setAtivo] = useState(true)

  useEffect(() => {
    if (!empresaId) return
    buscarServicos()
  }, [empresaId])

  async function buscarServicos() {
    if (!empresaId) return

    const { data, error } = await supabase
      .from('servicos')
      .select('*')
      .eq('empresa_id', empresaId)
      .order('categoria', { ascending: true })
      .order('nome', { ascending: true })

    if (error) {
      setErro('Não foi possível carregar os serviços.')
      return
    }

    setServicos(data || [])
  }

  function limparMensagens() {
    setErro('')
    setSucesso('')
  }

  function limparForm() {
    setIdEditando(null)
    setNome('')
    setCategoria('Manicure e Pedicure')
    setPreco('')
    setPrecoPromo('')
    setDescricao('')
    setAtivo(true)
  }

  async function salvarServico(e: React.FormEvent) {
    e.preventDefault()
    limparMensagens()

    if (!empresaId) {
      setErro('Empresa não identificada.')
      return
    }

    setLoadingSalvar(true)

    const payload = {
      empresa_id: empresaId,
      nome: formatarNomePadrao(nome),
      categoria,
      preco: Number(preco),
      preco_promocional: precoPromo ? Number(precoPromo) : null,
      preco_descricao: descricao || null,
      ativo,
    }

    if (idEditando) {
      const { error } = await supabase
        .from('servicos')
        .update(payload)
        .eq('id', idEditando)
        .eq('empresa_id', empresaId)

      if (error) {
        setErro('Não foi possível atualizar o serviço.')
        setLoadingSalvar(false)
        return
      }

      setSucesso('Serviço atualizado com sucesso.')
    } else {
      const { error } = await supabase.from('servicos').insert([payload])

      if (error) {
        setErro('Não foi possível cadastrar o serviço.')
        setLoadingSalvar(false)
        return
      }

      setSucesso('Serviço cadastrado com sucesso.')
    }

    limparForm()
    await buscarServicos()
    setAbaAtiva('lista')
    setLoadingSalvar(false)
  }

  async function alternarAtivo(servico: Servico) {
    if (!empresaId) return
    limparMensagens()

    const { error } = await supabase
      .from('servicos')
      .update({ ativo: !servico.ativo })
      .eq('id', servico.id)
      .eq('empresa_id', empresaId)

    if (error) {
      setErro('Não foi possível atualizar o status do serviço.')
      return
    }

    setSucesso(servico.ativo ? 'Serviço desativado.' : 'Serviço ativado.')
    await buscarServicos()
  }

  function editar(servico: Servico) {
    setIdEditando(servico.id)
    setNome(servico.nome)
    setCategoria(servico.categoria)
    setPreco(String(servico.preco))
    setPrecoPromo(
      servico.preco_promocional != null ? String(servico.preco_promocional) : ''
    )
    setDescricao(servico.preco_descricao || '')
    setAtivo(servico.ativo)
    setAbaAtiva('cadastrar')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  if (loading) {
    return (
      <AppShell>
        <div style={cardTema(tema)}>
          <h2 style={ui.sectionTitle}>Carregando empresa...</h2>
        </div>
      </AppShell>
    )
  }

  if (!empresaId) {
    return (
      <AppShell>
        <div style={cardTema(tema)}>
          <h2 style={ui.sectionTitle}>Empresa não identificada.</h2>
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell>
      <HeroHeader
        titulo="Serviços"
        subtitulo={`Menu de serviços • ${empresaNome}`}
        eyebrow="Catálogo do salão"
      />

      {(erro || sucesso) && (
        <div style={s.noticeWrap}>
          {erro ? <div style={s.erro}>{erro}</div> : null}
          {sucesso ? <div style={s.sucesso}>{sucesso}</div> : null}
        </div>
      )}

      <div style={{ ...ui.tabsWrap, marginTop: 10 }}>
        <button
          type="button"
          onClick={() => {
            setAbaAtiva('lista')
            limparMensagens()
          }}
          style={abaAtiva === 'lista' ? botaoPrimarioTema(tema) : botaoSecundarioTema(tema)}
        >
          📋 Meus serviços
        </button>

        <button
          type="button"
          onClick={() => {
            setAbaAtiva('cadastrar')
            limparForm()
            limparMensagens()
          }}
          style={abaAtiva === 'cadastrar' ? botaoPrimarioTema(tema) : botaoSecundarioTema(tema)}
        >
          {idEditando ? '✏️ Editar serviço' : '➕ Novo serviço'}
        </button>
      </div>

      {abaAtiva === 'cadastrar' && (
        <div style={cardTema(tema)}>
          <div style={s.sectionHeader}>
            <div style={s.sectionTitleWrap}>
              <h2 style={ui.sectionTitle}>
                {idEditando ? 'Editar serviço' : 'Novo serviço'}
              </h2>
              <p style={ui.sectionSub}>
                Configure o catálogo de serviços do salão.
              </p>
            </div>
          </div>

          <form onSubmit={salvarServico} style={s.form}>
            <div style={s.fieldFull}>
              <label style={ui.label}>Nome do serviço *</label>
              <input
                value={nome}
                onChange={e => setNome(e.target.value)}
                style={ui.input}
                required
                placeholder="Ex: Manicure e Pedicure"
              />
            </div>

            <div style={s.fieldFull}>
              <label style={ui.label}>Categoria</label>
              <select
                value={categoria}
                onChange={e => setCategoria(e.target.value)}
                style={ui.input}
              >
                <option value="Manicure e Pedicure">Manicure e Pedicure</option>
                <option value="Nail Design">Nail Design</option>
                <option value="Alongamento">Alongamento</option>
                <option value="Spa">Spa</option>
                <option value="Cílios">Cílios</option>
                <option value="Sobrancelhas">Sobrancelhas</option>
                <option value="Cabeleireiro">Cabeleireiro</option>
              </select>
            </div>

            <div style={s.gridDois}>
              <div style={s.field}>
                <label style={ui.label}>Preço normal (R$)</label>
                <input
                  type="number"
                  step="0.01"
                  value={preco}
                  onChange={e => setPreco(e.target.value)}
                  style={ui.input}
                  required
                />
              </div>

              <div style={s.field}>
                <label style={ui.label}>Preço promocional (R$)</label>
                <input
                  type="number"
                  step="0.01"
                  value={precoPromo}
                  onChange={e => setPrecoPromo(e.target.value)}
                  style={ui.input}
                />
              </div>
            </div>

            <div style={s.fieldFull}>
              <label style={ui.label}>Descrição adicional</label>
              <input
                value={descricao}
                onChange={e => setDescricao(e.target.value)}
                style={ui.input}
                placeholder='Opcional (Ex: "A partir de...")'
              />
            </div>

            <div style={s.checkRow}>
              <label style={s.checkLabel}>
                <input
                  type="checkbox"
                  checked={ativo}
                  onChange={e => setAtivo(e.target.checked)}
                />
                Serviço ativo para agendamento
              </label>
            </div>

            <div style={s.actionsRow}>
              <button
                type="submit"
                disabled={loadingSalvar}
                style={botaoPrimarioTema(tema)}
              >
                {loadingSalvar
                  ? 'Salvando...'
                  : idEditando
                    ? 'Atualizar serviço'
                    : 'Salvar no menu'}
              </button>

              <button
                type="button"
                style={botaoSecundarioTema(tema)}
                onClick={limparForm}
              >
                Limpar campos
              </button>
            </div>
          </form>
        </div>
      )}

      {abaAtiva === 'lista' && (
        <div style={s.gridServicos}>
          {servicos.map(servico => (
            <div
              key={servico.id}
              style={{
                ...cardTema(tema),
                ...s.cardServico,
                opacity: servico.ativo ? 1 : 0.65,
                borderLeft: `4px solid ${tema.corPrimaria}`,
              }}
              onMouseEnter={e => {
                e.currentTarget.style.transform = 'translateY(-4px)'
                e.currentTarget.style.boxShadow =
                  '0 10px 25px rgba(0,0,0,0.08)'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.transform = 'translateY(0)'
                e.currentTarget.style.boxShadow = '0 6px 18px rgba(0,0,0,0.06)'
              }}
            >
              <div style={s.cardServicoTop}>
                <div>
                  <span style={{ ...badgeTema(tema), marginBottom: 8 }}>
                    {servico.categoria}
                  </span>
                  <strong style={s.nomeServico}>{servico.nome}</strong>
                </div>

                <div style={s.btnMiniWrap}>
                  <button
                    onClick={() => editar(servico)}
                    style={s.btnMini}
                    type="button"
                    title="Editar"
                  >
                    ✏️
                  </button>

                  <button
                    onClick={() => alternarAtivo(servico)}
                    style={s.btnMini}
                    type="button"
                    title={servico.ativo ? 'Desativar' : 'Ativar'}
                  >
                    {servico.ativo ? '🟢' : '⚪'}
                  </button>
                </div>
              </div>

              <div style={s.infoPreco}>
                <div style={s.precoBox}>
                  <span style={s.precoLabel}>Normal</span>
                  <strong style={{ ...s.precoValor, color: tema.corSecundaria }}>
                    R$ {Number(servico.preco).toFixed(2)}
                  </strong>
                </div>

                {servico.preco_promocional != null && (
                  <div style={{ ...s.precoBox, textAlign: 'right' }}>
                    <span style={{ ...s.precoLabel, color: tema.corPrimaria }}>
                      Promo
                    </span>
                    <strong style={{ ...s.precoValor, color: tema.corPrimaria }}>
                      R$ {Number(servico.preco_promocional).toFixed(2)}
                    </strong>
                  </div>
                )}
              </div>

              {servico.preco_descricao ? (
                <p style={s.txtDesc}>{servico.preco_descricao}</p>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </AppShell>
  )
}

const s: Record<string, React.CSSProperties> = {
  noticeWrap: {
    display: 'grid',
    gap: 12,
    marginTop: 10,
  },
  erro: {
    background: '#fff2f1',
    border: '1px solid #ffd1cd',
    color: '#a33227',
    padding: '14px 16px',
    borderRadius: 16,
    fontWeight: 600,
  },
  sucesso: {
    background: '#eefbf2',
    border: '1px solid #c7eed3',
    color: '#16643b',
    padding: '14px 16px',
    borderRadius: 16,
    fontWeight: 600,
  },
  sectionHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 14,
    flexWrap: 'wrap',
    marginBottom: 18,
  },
  sectionTitleWrap: {
    display: 'grid',
    gap: 4,
  },
  form: {
    display: 'grid',
    gap: 16,
  },
  field: {
    display: 'grid',
    gap: 8,
  },
  fieldFull: {
    display: 'grid',
    gap: 8,
  },
  gridDois: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 16,
  },
  checkRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
  },
  checkLabel: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    fontSize: 14,
    color: '#57493f',
    fontWeight: 600,
  },
  actionsRow: {
    display: 'flex',
    gap: 12,
    flexWrap: 'wrap',
    marginTop: 8,
  },
  gridServicos: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
    gap: 20,
  },
  cardServico: {
    borderRadius: 16,
    padding: 18,
    transition: 'all 0.2s ease',
  },
  cardServicoTop: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 12,
  },
  nomeServico: {
    display: 'block',
    fontSize: 18,
    color: '#3a2f28',
    fontWeight: 600,
    lineHeight: 1.2,
  },
  infoPreco: {
    display: 'flex',
    justifyContent: 'space-between',
    gap: 12,
    marginTop: 15,
    paddingTop: 12,
    borderTop: '1px solid #f1e7de',
  },
  precoBox: {
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
  },
  precoLabel: {
    fontSize: 11,
    color: '#8b735d',
    fontWeight: 700,
    textTransform: 'uppercase',
  },
  precoValor: {
    fontSize: 18,
    fontWeight: 700,
  },
  txtDesc: {
    fontSize: 13,
    color: '#7b6858',
    fontStyle: 'italic',
    marginTop: 10,
    marginBottom: 0,
  },
  btnMiniWrap: {
    display: 'flex',
    gap: 8,
  },
  btnMini: {
    background: '#f9f6f2',
    border: '1px solid #eee',
    borderRadius: 10,
    padding: '6px 9px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
  },
}