"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { loginComEmailSenha } from "@/lib/auth"

export default function LoginPage() {
  const router = useRouter()

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [erro, setErro] = useState("")

  async function entrar() {
    setErro("")
    setLoading(true)

    try {
      await loginComEmailSenha(email, password)
      router.push("/dashboard")
    } catch (error: any) {
      console.error(error)
      setErro(error?.message || "Erro ao entrar.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#f6f1ee",
        padding: 24,
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 420,
          background: "#fff",
          borderRadius: 24,
          padding: 24,
          boxShadow: "0 14px 32px rgba(17,24,39,0.08)",
        }}
      >
        <h1 style={{ marginTop: 0 }}>Entrar</h1>

        {erro ? (
          <div
            style={{
              background: "#fff1f2",
              border: "1px solid #fecdd3",
              color: "#9f1239",
              padding: 12,
              borderRadius: 12,
              marginBottom: 16,
            }}
          >
            {erro}
          </div>
        ) : null}

        <div style={{ display: "grid", gap: 14 }}>
          <div>
            <label style={{ display: "block", marginBottom: 6, fontWeight: 700 }}>
              E-mail
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={inputStyle}
            />
          </div>

          <div>
            <label style={{ display: "block", marginBottom: 6, fontWeight: 700 }}>
              Senha
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={inputStyle}
            />
          </div>

          <button
            type="button"
            onClick={entrar}
            disabled={loading}
            style={buttonStyle}
          >
            {loading ? "Entrando..." : "Entrar"}
          </button>
        </div>
      </div>
    </div>
  )
}

const inputStyle: React.CSSProperties = {
  width: "100%",
  border: "1px solid #d1d5db",
  borderRadius: 12,
  padding: "12px 14px",
  fontSize: 14,
}

const buttonStyle: React.CSSProperties = {
  border: "none",
  borderRadius: 12,
  padding: "12px 18px",
  background: "#6f4b3d",
  color: "#fff",
  fontWeight: 700,
  cursor: "pointer",
}