import type { Metadata } from "next"
import "./globals.css"
import HeaderEmpresa from "@/components/HeaderEmpresa"

export const metadata: Metadata = {
  title: "Espaço Áurea",
  description: "Agende seu horário e acompanhe seu histórico no Espaço Áurea.",
  icons: {
    icon: "/favicon.ico",
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-br">
      <body style={{ margin: 0, padding: 0 }}>
        <div
          style={{
            minHeight: "100vh",
            background: "#f6f1ee",
          }}
        >
          <div
            style={{
              maxWidth: 1480,
              margin: "0 auto",
              padding: 24,
            }}
          >
            <HeaderEmpresa />
            {children}
          </div>
        </div>
      </body>
    </html>
  )
}