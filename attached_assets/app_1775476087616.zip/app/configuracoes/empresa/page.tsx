'use client'

import { useEffect, useState } from 'react'
import { supabase } from '../../../lib/supabase'
import { useEmpresa } from '../../../lib/useEmpresa'

export default function ConfiguracaoEmpresaPage() {
  const { empresa, loadingEmpresa } = useEmpresa()

  const [nome, setNome] = useState('')
  const [logoUrl, setLogoUrl] = useState('')
  const [previewLogo, setPreviewLogo] = useState('')
  const [saving, setSaving] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')

  useEffect(() => {
    if (empresa) {
      setNome(empresa.nome || '')
      setLogoUrl((empresa as any).logo_url || '')
      setPreviewLogo((empresa as any).logo_url || '')
    }
  }, [empresa])

  async function salvarDadosEmpresa() {
    if (!empresa?.id) return

    setSaving(true)
    setErro('')
    setSucesso('')

    try {
      const { error } = await supabase
        .from('empresas')
        .update({
          nome,
        })
        .eq('id', empresa.id)

      if (error) throw error

      setSucesso('Dados da empresa atualizados com sucesso.')
    } catch (error: any) {
      console.error(error)
      setErro(error?.message || 'Erro ao salvar dados da empresa.')
    } finally {
      setSaving(false)
    }
  }

  async function uploadLogo(file: File) {
    if (!empresa?.id) {
      setErro('Empresa não encontrada.')
      return
    }

    setUploading(true)
    setErro('')
    setSucesso('')

    try {
      const extensao = file.name.split('.').pop() || 'png'
      const nomeArquivo = `${empresa.id}/logo.${extensao}`

      const { error: uploadError } = await supabase.storage
        .from('logos')
        .upload(nomeArquivo, file, {
          upsert: true,
        })

      if (uploadError) throw uploadError

      const { data } = supabase.storage
        .from('logos')
        .getPublicUrl(nomeArquivo)

      const urlPublica = data.publicUrl

      const { error: updateError } = await supabase
        .from('empresas')
        .update({
          logo_url: urlPublica,
        })
        .eq('id', empresa.id)

      if (updateError) throw updateError

      setLogoUrl(urlPublica)
      setPreviewLogo(urlPublica)
      setSucesso('Logo atualizado com sucesso.')
    } catch (error: any) {
      console.error(error)
      setErro(error?.message || 'Erro ao enviar logo.')
    } finally {
      setUploading(false)
    }
  }

  if (loadingEmpresa) {
    return <div style={{ padding: 24 }}>Carregando empresa...</div>
  }

  if (!empresa) {
    return <div style={{ padding: 24 }}>Empresa não encontrada.</div>
  }

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: '0 auto' }}>
      <h1 style={{ marginBottom: 24 }}>Configurações da empresa</h1>

      {erro ? (
        <div
          style={{
            background: '#fff1f2',
            border: '1px solid #fecdd3',
            color: '#9f1239',
            padding: 12,
            borderRadius: 12,
            marginBottom: 16,
          }}
        >
          {erro}
        </div>
      ) : null}

      {sucesso ? (
        <div
          style={{
            background: '#ecfdf3',
            border: '1px solid #bbf7d0',
            color: '#166534',
            padding: 12,
            borderRadius: 12,
            marginBottom: 16,
          }}
        >
          {sucesso}
        </div>
      ) : null}

      <div
        style={{
          background: '#fff',
          border: '1px solid #e5e7eb',
          borderRadius: 20,
          padding: 24,
          marginBottom: 24,
        }}
      >
        <h2 style={{ marginTop: 0 }}>Dados principais</h2>

        <div style={{ display: 'grid', gap: 16 }}>
          <div>
            <label style={{ display: 'block', marginBottom: 6, fontWeight: 700 }}>
              Nome da empresa
            </label>
            <input
              type="text"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              style={{
                width: '100%',
                border: '1px solid #d1d5db',
                borderRadius: 12,
                padding: '12px 14px',
              }}
            />
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: 6, fontWeight: 700 }}>
              Slug
            </label>
            <input
              type="text"
              value={empresa.slug}
              readOnly
              style={{
                width: '100%',
                border: '1px solid #d1d5db',
                borderRadius: 12,
                padding: '12px 14px',
                background: '#f9fafb',
              }}
            />
          </div>

          <div>
            <button
              type="button"
              onClick={salvarDadosEmpresa}
              disabled={saving}
              style={{
                border: 'none',
                borderRadius: 12,
                padding: '12px 18px',
                background: '#6f4b3d',
                color: '#fff',
                fontWeight: 700,
                cursor: 'pointer',
              }}
            >
              {saving ? 'Salvando...' : 'Salvar dados'}
            </button>
          </div>
        </div>
      </div>

      <div
        style={{
          background: '#fff',
          border: '1px solid #e5e7eb',
          borderRadius: 20,
          padding: 24,
        }}
      >
        <h2 style={{ marginTop: 0 }}>Logo da empresa</h2>

        <div style={{ display: 'grid', gap: 16 }}>
          <div>
            {previewLogo ? (
              <img
                src={previewLogo}
                alt="Logo da empresa"
                style={{
                  width: 180,
                  height: 180,
                  objectFit: 'contain',
                  border: '1px solid #e5e7eb',
                  borderRadius: 16,
                  padding: 12,
                  background: '#fff',
                }}
              />
            ) : (
              <div
                style={{
                  width: 180,
                  height: 180,
                  border: '1px dashed #d1d5db',
                  borderRadius: 16,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  color: '#6b7280',
                }}
              >
                Sem logo
              </div>
            )}
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: 6, fontWeight: 700 }}>
              Enviar novo logo
            </label>
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp,image/svg+xml"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (!file) return

                const preview = URL.createObjectURL(file)
                setPreviewLogo(preview)
                uploadLogo(file)
              }}
            />
          </div>

          <div>
            <label style={{ display: 'block', marginBottom: 6, fontWeight: 700 }}>
              URL atual do logo
            </label>
            <input
              type="text"
              value={logoUrl}
              readOnly
              style={{
                width: '100%',
                border: '1px solid #d1d5db',
                borderRadius: 12,
                padding: '12px 14px',
                background: '#f9fafb',
              }}
            />
          </div>

          {uploading ? <div>Enviando logo...</div> : null}
        </div>
      </div>
    </div>
  )
}