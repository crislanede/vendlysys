import { NextRequest, NextResponse } from 'next/server'

const ENDERECO_ESTABELECIMENTO =
  process.env.ENDERECO_ESTABELECIMENTO || 'Endereço do Espaço Áurea'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const origem = body?.origem as string | undefined

    if (!origem) {
      return NextResponse.json(
        { error: 'Endereço de origem não informado.' },
        { status: 400 }
      )
    }

    const apiKey = process.env.GOOGLE_MAPS_API_KEY

    if (!apiKey) {
      return NextResponse.json(
        { error: 'GOOGLE_MAPS_API_KEY não configurada.' },
        { status: 500 }
      )
    }

    const response = await fetch(
      'https://routes.googleapis.com/directions/v2:computeRoutes',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': apiKey,
          'X-Goog-FieldMask':
            'routes.duration,routes.distanceMeters,routes.localizedValues',
        },
        body: JSON.stringify({
          origin: {
            address: origem,
          },
          destination: {
            address: ENDERECO_ESTABELECIMENTO,
          },
          travelMode: 'DRIVE',
          routingPreference: 'TRAFFIC_AWARE',
          languageCode: 'pt-BR',
          units: 'METRIC',
        }),
      }
    )

    const data = await response.json()

    if (!response.ok) {
      return NextResponse.json(
        {
          error: data?.error?.message || 'Erro ao calcular trajeto.',
          details: data,
        },
        { status: response.status }
      )
    }

    const rota = data?.routes?.[0]

    if (!rota) {
      return NextResponse.json(
        { error: 'Nenhuma rota encontrada.' },
        { status: 404 }
      )
    }

    const duracaoSegundos = Number(String(rota.duration || '0s').replace('s', ''))
    const distanciaMetros = Number(rota.distanceMeters || 0)

    return NextResponse.json({
      duracaoSegundos,
      distanciaMetros,
      duracaoTexto: formatarDuracao(duracaoSegundos),
      distanciaTexto: formatarDistancia(distanciaMetros),
    })
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || 'Erro interno ao calcular trajeto.' },
      { status: 500 }
    )
  }
}

function formatarDuracao(segundos: number) {
  const minutos = Math.round(segundos / 60)

  if (minutos < 60) {
    return `${minutos} min`
  }

  const horas = Math.floor(minutos / 60)
  const resto = minutos % 60

  if (resto === 0) {
    return `${horas}h`
  }

  return `${horas}h ${resto}min`
}

function formatarDistancia(metros: number) {
  const km = metros / 1000
  return `${km.toFixed(1).replace('.', ',')} km`
}