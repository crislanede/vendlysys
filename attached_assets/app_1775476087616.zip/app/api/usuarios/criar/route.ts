import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const { nome, email, senha, perfil, empresa_id } = body

    if (!nome || !email || !senha || !perfil || !empresa_id) {
      return NextResponse.json(
        { error: 'Dados incompletos' },
        { status: 400 }
      )
    }

    // 1. Criar usuário no Auth
    const { data: userData, error: userError } =
      await supabaseAdmin.auth.admin.createUser({
        email,
        password: senha,
        email_confirm: true,
      })

    if (userError || !userData?.user) {
      return NextResponse.json(
        { error: userError?.message || 'Erro ao criar usuário' },
        { status: 500 }
      )
    }

    const userId = userData.user.id

    // 2. Vincular na empresa
    const { error: vinculoError } = await supabaseAdmin
      .from('usuarios_empresa')
      .insert({
        auth_user_id: userId,
        empresa_id,
        nome,
        email,
        perfil,
        ativo: true,
      })

    if (vinculoError) {
      return NextResponse.json(
        { error: vinculoError.message },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      user_id: userId,
    })
  } catch (err: any) {
    return NextResponse.json(
      { error: err.message || 'Erro interno' },
      { status: 500 }
    )
  }
}