import { NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"
import { enviarLembreteWhatsapp } from "@/lib/whatsapp-envio"

type Empresa = {
  id: string
  nome: string
  slug: string
  whatsapp?: string | null
}

type Cliente = {
  id: string
  nome: string
  telefone?: string | null
}

type Profissional = {
  id: string
  nome: string
}

type Servico = {
  id: string
  nome: string
}

type Agendamento = {
  id: string
  empresa_id: string
  cliente_id: string
  profissional_id: string
  servico_id?: string | null
  data_agendamento: string
  hora: string
  status: string
  lembrete_enviado?: boolean | null
  clientes?: Cliente | Cliente[] | null
  profissionais?: Profissional | Profissional[] | null
  servicos?: Servico | Servico[] | null
  empresas?: Empresa | Empresa[] | null
}

function getHojeBrasil() {
  const agora = new Date()
  const ano = agora.getFullYear()
  const mes = String(agora.getMonth() + 1).padStart(2, "0")
  const dia = String(agora.getDate()).padStart(2, "0")
  return `${ano}-${mes}-${dia}`
}

function horaParaMinutos(hora?: string | null) {
  if (!hora) return 0
  const [h, m] = hora.slice(0, 5).split(":").map(Number)
  return (h || 0) * 60 + (m || 0)
}

function agoraMinutos() {
  const agora = new Date()
  return agora.getHours() * 60 + agora.getMinutes()
}

function pickOne<T>(valor: T | T[] | null | undefined): T | null {
  if (!valor) return null
  return Array.isArray(valor) ? valor[0] || null : valor
}

function limparTelefone(telefone?: string | null) {
  return (telefone || "").replace(/\D/g, "")
}

function obterBaseUrl(req: NextRequest) {
  const origin = req.nextUrl.origin
  return process.env.NEXT_PUBLIC_BASE_URL || origin
}

function gerarLinkConfirmacao(baseUrl: string, id: string, slug?: string | null) {
  return `${baseUrl}/confirmar?id=${id}&empresa=${slug || ""}`
}

function gerarLinkReagendamento(baseUrl: string, id: string, slug?: string | null) {
  return `${baseUrl}/meu-espaco/reagendar?id=${id}&empresa=${slug || ""}`
}

function gerarLinkCancelamento(baseUrl: string, id: string, slug?: string | null) {
  return `${baseUrl}/meu-espaco/cancelar?id=${id}&empresa=${slug || ""}`
}

function estaNaJanelaDeLembrete(horaAgendamento: string, minutosAntes = 60, tolerancia = 10) {
  const agora = agoraMinutos()
  const horario = horaParaMinutos(horaAgendamento)
  const diferenca = horario - agora

  return diferenca <= minutosAntes && diferenca >= minutosAntes - tolerancia
}

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get("authorization")
    const tokenQuery = req.nextUrl.searchParams.get("token")
    const secret = process.env.CRON_SECRET

    const autorizado =
      (secret && authHeader === `Bearer ${secret}`) ||
      (secret && tokenQuery === secret)

    if (!autorizado) {
      return NextResponse.json({ error: "Não autorizado." }, { status: 401 })
    }

    const hoje = getHojeBrasil()
    const baseUrl = obterBaseUrl(req)

    const { data, error } = await supabase
      .from("agendamentos")
      .select(`
        id,
        empresa_id,
        cliente_id,
        profissional_id,
        servico_id,
        data_agendamento,
        hora,
        status,
        lembrete_enviado,
        clientes (
          id,
          nome,
          telefone
        ),
        profissionais (
          id,
          nome
        ),
        servicos (
          id,
          nome
        ),
        empresas (
          id,
          nome,
          slug,
          whatsapp
        )
      `)
      .eq("data_agendamento", hoje)
      .in("status", ["pendente", "confirmado"])

    if (error) {
      console.error("Erro ao buscar agendamentos para lembrete:", error)
      return NextResponse.json(
        { error: "Erro ao buscar agendamentos." },
        { status: 500 }
      )
    }

    const agendamentos = (data || []) as Agendamento[]

    let enviados = 0
    let ignorados = 0
    let erros = 0

    for (const item of agendamentos) {
      try {
        if (item.lembrete_enviado) {
          ignorados++
          continue
        }

        if (!estaNaJanelaDeLembrete(item.hora, 60, 10)) {
          ignorados++
          continue
        }

        const cliente = pickOne(item.clientes)
        const profissional = pickOne(item.profissionais)
        const servico = pickOne(item.servicos)
        const empresa = pickOne(item.empresas)

        const telefone = limparTelefone(cliente?.telefone)

        if (!cliente || !telefone || !empresa) {
          ignorados++
          continue
        }

        const linkConfirmacao = gerarLinkConfirmacao(baseUrl, item.id, empresa.slug)
        const linkReagendamento = gerarLinkReagendamento(baseUrl, item.id, empresa.slug)
        const linkCancelamento = gerarLinkCancelamento(baseUrl, item.id, empresa.slug)

        const mensagem = `Olá, ${cliente.nome}!

Esse é um lembrete do seu agendamento em ${empresa.nome}.

📅 Data: ${item.data_agendamento}
⏰ Horário: ${item.hora}
💅 Serviço: ${servico?.nome || "-"}
👩 Profissional: ${profissional?.nome || "-"}

✅ Confirmar:
${linkConfirmacao}

🔄 Reagendar:
${linkReagendamento}

❌ Cancelar:
${linkCancelamento}`

        await enviarLembreteWhatsapp({
          telefone,
          mensagem,
          empresaId: item.empresa_id,
          agendamentoId: item.id,
        })

        const { error: updateError } = await supabase
          .from("agendamentos")
          .update({ lembrete_enviado: true })
          .eq("id", item.id)

        if (updateError) {
          console.error("Erro ao marcar lembrete como enviado:", updateError)
        }

        enviados++
      } catch (err) {
        console.error("Erro ao processar lembrete:", err)
        erros++
      }
    }

    return NextResponse.json({
      ok: true,
      hoje,
      total: agendamentos.length,
      enviados,
      ignorados,
      erros,
    })
  } catch (error) {
    console.error("Erro geral no job de lembretes:", error)
    return NextResponse.json(
      { error: "Erro interno no job de lembretes." },
      { status: 500 }
    )
  }
}