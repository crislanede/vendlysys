import { NextResponse } from 'next/server'
import { createClient } from '@supabase/supabase-js'

const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const { user_id, nova_senha } = body

    if (!user_id || !nova_senha) {
      return NextResponse.json(
        { error: 'user_id e nova_senha são obrigatórios.' },
        { status: 400 }
      )
    }

    if (String(nova_senha).length < 6) {
      return NextResponse.json(
        { error: 'A nova senha deve ter pelo menos 6 caracteres.' },
        { status: 400 }
      )
    }

    const { error } = await supabaseAdmin.auth.admin.updateUserById(user_id, {
      password: nova_senha,
    })

    if (error) {
      return NextResponse.json(
        { error: error.message || 'Erro ao resetar senha.' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      message: 'Senha redefinida com sucesso.',
    })
  } catch (error: any) {
    return NextResponse.json(
      { error: error?.message || 'Erro interno no servidor.' },
      { status: 500 }
    )
  }
}