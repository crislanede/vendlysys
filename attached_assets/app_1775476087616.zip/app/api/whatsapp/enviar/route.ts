import { NextResponse } from 'next/server'
import { criarLogWhatsapp } from '@/lib/whatsapp-log'

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const {
      empresaId,
      agendamentoId,
      clienteId,
      telefone,
      mensagem,
      tipo,
    } = body

    if (!empresaId || !telefone || !mensagem || !tipo) {
      return NextResponse.json(
        { error: 'Dados obrigatórios não informados.' },
        { status: 400 }
      )
    }

    const envioSimuladoComSucesso = true

    if (envioSimuladoComSucesso) {
      await criarLogWhatsapp({
        empresaId,
        agendamentoId,
        clienteId,
        telefone,
        tipo,
        conteudo: mensagem,
        statusEnvio: 'enviado',
      })

      return NextResponse.json({ ok: true })
    }

    await criarLogWhatsapp({
      empresaId,
      agendamentoId,
      clienteId,
      telefone,
      tipo,
      conteudo: mensagem,
      statusEnvio: 'erro',
      erro: 'Falha no provider',
    })

    return NextResponse.json(
      { error: 'Falha ao enviar mensagem.' },
      { status: 500 }
    )
  } catch (error) {
    console.error(error)
    return NextResponse.json(
      { error: 'Erro interno ao processar envio.' },
      { status: 500 }
    )
  }
}