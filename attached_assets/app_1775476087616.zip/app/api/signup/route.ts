import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabaseAdmin'
import { slugifyEmpresa } from '@/lib/slug'

export async function POST(req: Request) {
  try {
    const body = await req.json()

    const { nomeEmpresa, nomeResponsavel, email, senha } = body

    if (!nomeEmpresa || !nomeResponsavel || !email || !senha) {
      return NextResponse.json(
        { error: 'Preencha todos os campos obrigatórios.' },
        { status: 400 }
      )
    }

    const slugBase = slugifyEmpresa(nomeEmpresa)

    const { data: empresaExistente, error: slugError } = await supabaseAdmin
      .from('empresas')
      .select('id, slug')
      .eq('slug', slugBase)
      .maybeSingle()

    if (slugError) {
      console.error('Erro ao validar slug:', slugError)

      return NextResponse.json(
        { error: 'Erro ao validar slug da empresa.' },
        { status: 500 }
      )
    }

    const slugFinal = empresaExistente
      ? `${slugBase}-${Date.now()}`
      : slugBase

    const { data: authData, error: authError } =
      await supabaseAdmin.auth.admin.createUser({
        email,
        password: senha,
        email_confirm: true,
        user_metadata: {
          nome: nomeResponsavel,
        },
      })

    if (authError || !authData.user) {
      console.error('Erro ao criar usuário no Auth:', authError)

      return NextResponse.json(
        { error: authError?.message || 'Erro ao criar usuário.' },
        { status: 400 }
      )
    }

    const userId = authData.user.id

    const { data: empresaData, error: empresaError } = await supabaseAdmin
  .from('empresas')
  .insert([
    {
      nome: nomeEmpresa,
      slug: slugFinal,
    },
  ])
  .select()
  .single()

    if (empresaError || !empresaData) {
      console.error('Erro ao criar empresa:', empresaError)

      await supabaseAdmin.auth.admin.deleteUser(userId)

      return NextResponse.json(
        { error: empresaError?.message || 'Erro ao criar empresa.' },
        { status: 400 }
      )
    }

    const { error: vinculoError } = await supabaseAdmin
      .from('usuarios_empresa')
      .insert([
        {
          auth_user_id: userId,
          empresa_id: empresaData.id,
          nome: nomeResponsavel,
          email,
          perfil: 'admin',
          ativo: true,
        },
      ])

    if (vinculoError) {
      console.error('Erro ao vincular usuário à empresa:', vinculoError)

      await supabaseAdmin.from('empresas').delete().eq('id', empresaData.id)
      await supabaseAdmin.auth.admin.deleteUser(userId)

      return NextResponse.json(
        { error: vinculoError.message || 'Erro ao vincular usuário à empresa.' },
        { status: 400 }
      )
    }

    return NextResponse.json(
      {
        ok: true,
        message: 'Conta criada com sucesso.',
        empresa: empresaData,
        userId,
      },
      { status: 201 }
    )
  } catch (error: any) {
    console.error('Erro no signup:', error)

    return NextResponse.json(
      { error: error?.message || 'Erro interno no cadastro.' },
      { status: 500 }
    )
  }
}