'use client'

import { ChangeEvent, FormEvent, useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'
import { useSessaoEmpresa } from '@/lib/useSessaoEmpresa'

type FormData = {
  nome: string
  slug: string
  telefone: string
  whatsapp: string
  cor_primaria: string
  cor_secundaria: string
  logo_url: string
}

function normalizarSlug(valor: string) {
  return valor
    .toLowerCase()
    .trim()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, '-')
    .replace(/[^a-z0-9-]/g, '')
    .replace(/-+/g, '-')
}

export default function OnboardingPage() {
  const router = useRouter()
  const { empresa, loading } = useSessaoEmpresa()

  const [form, setForm] = useState<FormData>({
    nome: '',
    slug: '',
    telefone: '',
    whatsapp: '',
    cor_primaria: '#b8956f',
    cor_secundaria: '#6f4b3d',
    logo_url: '',
  })

  const [salvando, setSalvando] = useState(false)
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')
  const [previewLogo, setPreviewLogo] = useState('')

  useEffect(() => {
    if (!empresa) return

    setForm({
      nome: empresa.nome || '',
      slug: empresa.slug || '',
      telefone: (empresa as any).telefone || '',
      whatsapp: (empresa as any).whatsapp || '',
      cor_primaria: empresa.cor_primaria || '#b8956f',
      cor_secundaria: empresa.cor_secundaria || '#6f4b3d',
      logo_url: empresa.logo_url || '',
    })

    setPreviewLogo(empresa.logo_url || '')
  }, [empresa])

  function handleChange(
    e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) {
    const { name, value } = e.target

    if (name === 'nome') {
      setForm((prev) => ({
        ...prev,
        nome: value,
        slug: prev.slug ? prev.slug : normalizarSlug(value),
      }))
      return
    }

    if (name === 'slug') {
      setForm((prev) => ({
        ...prev,
        slug: normalizarSlug(value),
      }))
      return
    }

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  async function handleUploadLogo(e: ChangeEvent<HTMLInputElement>) {
    try {
      setErro('')
      const file = e.target.files?.[0]

      if (!file || !empresa?.id) return

      const extensao = file.name.split('.').pop()
      const nomeArquivo = `${empresa.id}-${Date.now()}.${extensao}`
      const caminho = `logos/${nomeArquivo}`

      const { error: uploadError } = await supabase.storage
        .from('Aurea')
        .upload(caminho, file, {
          upsert: true,
        })

      if (uploadError) {
        throw new Error(uploadError.message)
      }

      const { data } = supabase.storage.from('Aurea').getPublicUrl(caminho)

      const urlPublica = data.publicUrl

      setForm((prev) => ({
        ...prev,
        logo_url: urlPublica,
      }))

      setPreviewLogo(urlPublica)
    } catch (error: any) {
      setErro(error?.message || 'Erro ao enviar logo.')
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()

    try {
      setErro('')
      setSucesso('')
      setSalvando(true)

      if (!empresa?.id) {
        throw new Error('Empresa não encontrada.')
      }

      if (!form.nome || !form.slug) {
        throw new Error('Preencha nome e slug da empresa.')
      }

      const slugNormalizado = normalizarSlug(form.slug)

      const { data: slugExistente, error: slugError } = await supabase
        .from('empresas')
        .select('id, slug')
        .eq('slug', slugNormalizado)
        .neq('id', empresa.id)
        .maybeSingle()

      if (slugError) {
        throw new Error(slugError.message)
      }

      if (slugExistente) {
        throw new Error('Esse slug já está em uso por outra empresa.')
      }

      const payload = {
        nome: form.nome.trim(),
        slug: slugNormalizado,
        telefone: form.telefone.trim() || null,
        whatsapp: form.whatsapp.trim() || null,
        cor_primaria: form.cor_primaria,
        cor_secundaria: form.cor_secundaria,
        logo_url: form.logo_url.trim() || null,
      }

      const { error: updateError } = await supabase
        .from('empresas')
        .update(payload)
        .eq('id', empresa.id)

      if (updateError) {
        throw new Error(updateError.message)
      }

      setSucesso('Configurações salvas com sucesso!')

      setTimeout(() => {
        router.push('/dashboard')
      }, 1200)
    } catch (error: any) {
      setErro(error?.message || 'Erro ao salvar onboarding.')
    } finally {
      setSalvando(false)
    }
  }

  if (loading) {
    return (
      <div style={paginaStyle}>
        <div style={cardStyle}>Carregando onboarding...</div>
      </div>
    )
  }

  if (!empresa) {
    return (
      <div style={paginaStyle}>
        <div style={cardStyle}>
          <h1 style={tituloStyle}>Empresa não encontrada</h1>
          <p style={textoStyle}>
            Não foi possível carregar os dados da empresa para o onboarding.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div style={paginaStyle}>
      <div style={wrapperStyle}>
        <div style={headerStyle}>
          <div style={logoWrapStyle}>
            {previewLogo ? (
              <img
                src={previewLogo}
                alt="Logo da empresa"
                style={logoPreviewStyle}
              />
            ) : (
              <span style={logoFallbackStyle}>
                {form.nome?.charAt(0)?.toUpperCase() || 'E'}
              </span>
            )}
          </div>

          <div>
            <p style={badgeStyle}>Onboarding</p>
            <h1 style={tituloStyle}>Configure sua empresa</h1>
            <p style={subtituloStyle}>
              Ajuste identidade visual e dados básicos para começar a usar o
              VendlySys.
            </p>
          </div>
        </div>

        <form onSubmit={handleSubmit} style={cardStyle}>
          <div style={gridStyle}>
            <div style={campoStyle}>
              <label style={labelStyle}>Nome da empresa</label>
              <input
                name="nome"
                value={form.nome}
                onChange={handleChange}
                style={inputStyle}
                placeholder="Ex: Espaço Áurea"
                required
              />
            </div>

            <div style={campoStyle}>
              <label style={labelStyle}>Slug</label>
              <input
                name="slug"
                value={form.slug}
                onChange={handleChange}
                style={inputStyle}
                placeholder="ex: espaco-aurea"
                required
              />
              <span style={hintStyle}>
                URL interna da empresa. Ex: <strong>/espaco-aurea</strong>
              </span>
            </div>

            <div style={campoStyle}>
              <label style={labelStyle}>Telefone</label>
              <input
                name="telefone"
                value={form.telefone}
                onChange={handleChange}
                style={inputStyle}
                placeholder="(11) 99999-9999"
              />
            </div>

            <div style={campoStyle}>
              <label style={labelStyle}>WhatsApp</label>
              <input
                name="whatsapp"
                value={form.whatsapp}
                onChange={handleChange}
                style={inputStyle}
                placeholder="5511999999999"
              />
            </div>

            <div style={campoStyle}>
              <label style={labelStyle}>Cor primária</label>
              <div style={colorRowStyle}>
                <input
                  type="color"
                  name="cor_primaria"
                  value={form.cor_primaria}
                  onChange={handleChange}
                  style={colorInputStyle}
                />
                <input
                  name="cor_primaria"
                  value={form.cor_primaria}
                  onChange={handleChange}
                  style={inputStyle}
                />
              </div>
            </div>

            <div style={campoStyle}>
              <label style={labelStyle}>Cor secundária</label>
              <div style={colorRowStyle}>
                <input
                  type="color"
                  name="cor_secundaria"
                  value={form.cor_secundaria}
                  onChange={handleChange}
                  style={colorInputStyle}
                />
                <input
                  name="cor_secundaria"
                  value={form.cor_secundaria}
                  onChange={handleChange}
                  style={inputStyle}
                />
              </div>
            </div>

            <div style={{ ...campoStyle, gridColumn: '1 / -1' }}>
              <label style={labelStyle}>Logo da empresa</label>
              <input
                type="file"
                accept="image/*"
                onChange={handleUploadLogo}
                style={inputStyle}
              />
              {form.logo_url ? (
                <span style={hintStyle}>Logo carregada com sucesso.</span>
              ) : (
                <span style={hintStyle}>
                  Envie a logo para personalizar o painel.
                </span>
              )}
            </div>
          </div>

          <div style={previewCardStyle}>
            <p style={previewLabelStyle}>Prévia do tema</p>

            <div
              style={{
                ...previewBannerStyle,
                background: `linear-gradient(135deg, ${form.cor_secundaria}, ${form.cor_primaria})`,
              }}
            >
              <div style={previewLogoWrapStyle}>
                {previewLogo ? (
                  <img
                    src={previewLogo}
                    alt="Preview logo"
                    style={logoPreviewStyle}
                  />
                ) : (
                  <span style={logoFallbackStyle}>
                    {form.nome?.charAt(0)?.toUpperCase() || 'E'}
                  </span>
                )}
              </div>

              <div>
                <p style={previewMiniBadgeStyle}>Gestão de Agendamentos</p>
                <h2 style={previewTituloStyle}>
                  {form.nome || 'Nome da empresa'}
                </h2>
              </div>
            </div>
          </div>

          {erro ? <div style={alertaErroStyle}>{erro}</div> : null}
          {sucesso ? <div style={alertaSucessoStyle}>{sucesso}</div> : null}

          <div style={acoesStyle}>
            <button
              type="button"
              onClick={() => router.push('/dashboard')}
              style={botaoSecundarioStyle}
            >
              Pular por agora
            </button>

            <button
              type="submit"
              disabled={salvando}
              style={{
                ...botaoPrimarioStyle,
                background: `linear-gradient(135deg, ${form.cor_secundaria}, ${form.cor_primaria})`,
              }}
            >
              {salvando ? 'Salvando...' : 'Salvar e continuar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}

const paginaStyle: React.CSSProperties = {
  minHeight: '100vh',
  background: '#f5f3f2',
  padding: '32px 20px',
}

const wrapperStyle: React.CSSProperties = {
  maxWidth: 980,
  margin: '0 auto',
}

const cardStyle: React.CSSProperties = {
  background: '#ffffff',
  borderRadius: 24,
  padding: 24,
  boxShadow: '0 10px 30px rgba(0,0,0,0.06)',
}

const headerStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 20,
  marginBottom: 24,
  background: '#ffffff',
  borderRadius: 24,
  padding: 24,
  boxShadow: '0 10px 30px rgba(0,0,0,0.06)',
}

const logoWrapStyle: React.CSSProperties = {
  width: 84,
  height: 84,
  borderRadius: 24,
  background: '#f8fafc',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
  border: '1px solid #e5e7eb',
  flexShrink: 0,
}

const logoPreviewStyle: React.CSSProperties = {
  width: '100%',
  height: '100%',
  objectFit: 'cover',
}

const logoFallbackStyle: React.CSSProperties = {
  fontSize: 28,
  fontWeight: 800,
  color: '#374151',
}

const badgeStyle: React.CSSProperties = {
  margin: 0,
  fontSize: 12,
  fontWeight: 800,
  textTransform: 'uppercase',
  letterSpacing: 1,
  color: '#9ca3af',
}

const tituloStyle: React.CSSProperties = {
  margin: '8px 0 6px',
  fontSize: 34,
  lineHeight: 1.1,
  color: '#111827',
}

const subtituloStyle: React.CSSProperties = {
  margin: 0,
  color: '#6b7280',
  fontSize: 15,
}

const textoStyle: React.CSSProperties = {
  margin: 0,
  color: '#6b7280',
}

const gridStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
  gap: 16,
}

const campoStyle: React.CSSProperties = {
  display: 'flex',
  flexDirection: 'column',
  gap: 8,
}

const labelStyle: React.CSSProperties = {
  fontSize: 14,
  fontWeight: 700,
  color: '#374151',
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  border: '1px solid #d1d5db',
  borderRadius: 12,
  padding: '12px 14px',
  fontSize: 14,
  outline: 'none',
  background: '#fff',
}

const hintStyle: React.CSSProperties = {
  fontSize: 12,
  color: '#6b7280',
}

const colorRowStyle: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 10,
}

const colorInputStyle: React.CSSProperties = {
  width: 52,
  height: 44,
  border: '1px solid #d1d5db',
  borderRadius: 12,
  background: '#fff',
  padding: 4,
}

const previewCardStyle: React.CSSProperties = {
  marginTop: 24,
  paddingTop: 24,
  borderTop: '1px solid #f1f5f9',
}

const previewLabelStyle: React.CSSProperties = {
  margin: '0 0 12px 0',
  fontSize: 14,
  fontWeight: 700,
  color: '#374151',
}

const previewBannerStyle: React.CSSProperties = {
  borderRadius: 24,
  padding: 20,
  color: '#fff',
  display: 'flex',
  alignItems: 'center',
  gap: 16,
  boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
}

const previewLogoWrapStyle: React.CSSProperties = {
  width: 64,
  height: 64,
  borderRadius: 16,
  background: '#ffffff',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  overflow: 'hidden',
  flexShrink: 0,
}

const previewMiniBadgeStyle: React.CSSProperties = {
  margin: 0,
  fontSize: 12,
  letterSpacing: 1,
  textTransform: 'uppercase',
  opacity: 0.9,
}

const previewTituloStyle: React.CSSProperties = {
  margin: '6px 0 0 0',
  fontSize: 28,
  lineHeight: 1.1,
}

const alertaErroStyle: React.CSSProperties = {
  marginTop: 16,
  background: '#fef2f2',
  border: '1px solid #fecaca',
  color: '#b91c1c',
  padding: 12,
  borderRadius: 12,
}

const alertaSucessoStyle: React.CSSProperties = {
  marginTop: 16,
  background: '#ecfdf3',
  border: '1px solid #bbf7d0',
  color: '#166534',
  padding: 12,
  borderRadius: 12,
}

const acoesStyle: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'flex-end',
  gap: 12,
  marginTop: 24,
  flexWrap: 'wrap',
}

const botaoPrimarioStyle: React.CSSProperties = {
  border: 0,
  color: '#ffffff',
  padding: '12px 18px',
  borderRadius: 14,
  cursor: 'pointer',
  fontWeight: 800,
  boxShadow: '0 8px 20px rgba(45,36,31,0.16)',
}

const botaoSecundarioStyle: React.CSSProperties = {
  border: '1px solid #d1d5db',
  background: '#ffffff',
  color: '#374151',
  padding: '12px 18px',
  borderRadius: 14,
  cursor: 'pointer',
  fontWeight: 700,
}