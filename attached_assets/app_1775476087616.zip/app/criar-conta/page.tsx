'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function CriarContaPage() {
  const router = useRouter()

  const [nomeEmpresa, setNomeEmpresa] = useState('')
  const [nomeUsuario, setNomeUsuario] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setErro('')
    setSucesso('')
    setLoading(true)

    try {
      const resposta = await fetch('/api/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          nomeEmpresa,
          nomeResponsavel: nomeUsuario,
          email,
          senha: password,
        }),
      })

      const contentType = resposta.headers.get('content-type')

      if (!contentType || !contentType.includes('application/json')) {
        const texto = await resposta.text()
        console.error('Resposta não JSON:', texto)
        throw new Error('A API não retornou JSON.')
      }

      const resultado = await resposta.json()

      if (!resposta.ok) {
        throw new Error(resultado.error || 'Erro ao criar conta.')
      }

      setSucesso('Conta criada com sucesso! Redirecionando para login...')

      setTimeout(() => {
        router.push('/login')
      }, 1500)
    } catch (error: any) {
      setErro(error.message || 'Erro inesperado ao criar conta.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-100 px-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-md p-8">
        <h1 className="text-2xl font-bold text-center mb-6">Criar conta</h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Nome da empresa</label>
            <input
              type="text"
              value={nomeEmpresa}
              onChange={(e) => setNomeEmpresa(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 outline-none"
              placeholder="Ex: Studio Bella"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Seu nome</label>
            <input
              type="text"
              value={nomeUsuario}
              onChange={(e) => setNomeUsuario(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 outline-none"
              placeholder="Ex: Crislane"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">E-mail</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 outline-none"
              placeholder="voce@email.com"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Senha</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 outline-none"
              placeholder="********"
              required
            />
          </div>

          {erro && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg px-3 py-2">
              {erro}
            </div>
          )}

          {sucesso && (
            <div className="bg-green-50 border border-green-200 text-green-700 text-sm rounded-lg px-3 py-2">
              {sucesso}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-black text-white rounded-lg py-2.5 font-medium disabled:opacity-60"
          >
            {loading ? 'Criando conta...' : 'Criar conta'}
          </button>
        </form>
      </div>
    </div>
  )
}