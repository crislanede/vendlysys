'use client'

import { useEffect, useMemo, useState } from 'react'
import Image from 'next/image'
import { supabase } from '@/lib/supabase'
import { getEmpresaBySlug, Empresa } from '@/lib/getEmpresa'
import { theme } from '@/theme'

type Cliente = {
  id: string
  empresa_id: string
  nome: string
  data_nascimento: string
  telefone?: string | null
}

type Servico = {
  id: string
  empresa_id: string
  nome: string
  preco?: number | null
  duracao_minutos?: number | null
}

type Profissional = {
  id: string
  empresa_id: string
  nome: string
}

type Agendamento = {
  id: string
  empresa_id: string
  cliente_id: string
  servico_id: string
  profissional_id?: string | null
  data_agendamento: string
  hora: string
  valor_cobrado?: number | null
  status?: string | null
  clientes?: { nome: string } | null
  servicos?: { nome: string } | null
}

export default function AreaDaClientePage() {
  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [cliente, setCliente] = useState<Cliente | null>(null)

  const [nome, setNome] = useState('')
  const [dataNascimento, setDataNascimento] = useState('')

  const [servicos, setServicos] = useState<Servico[]>([])
  const [profissionais, setProfissionais] = useState<Profissional[]>([])
  const [agendamentos, setAgendamentos] = useState<Agendamento[]>([])

  const [servicoId, setServicoId] = useState('')
  const [profissionalId, setProfissionalId] = useState('')
  const [dataAgendamento, setDataAgendamento] = useState('')
  const [hora, setHora] = useState('')

  const [loading, setLoading] = useState(true)
  const [loadingLogin, setLoadingLogin] = useState(false)
  const [loadingSalvar, setLoadingSalvar] = useState(false)
  const [erro, setErro] = useState('')

  async function carregarEmpresa() {
    setLoading(true)
    const emp = await getEmpresaBySlug()
    setEmpresa(emp)
    setLoading(false)
  }

  async function carregarCatalogos(emp: Empresa) {
    const [servicosRes, profissionaisRes] = await Promise.all([
      supabase
        .from('servicos')
        .select('*')
        .eq('empresa_id', emp.id)
        .order('nome', { ascending: true }),
      supabase
        .from('profissionais')
        .select('*')
        .eq('empresa_id', emp.id)
        .order('nome', { ascending: true }),
    ])

    if (servicosRes.error) console.error(servicosRes.error)
    if (profissionaisRes.error) console.error(profissionaisRes.error)

    setServicos(servicosRes.data || [])
    setProfissionais(profissionaisRes.data || [])
  }

  async function carregarHistorico(clienteId: string, empresaId: string) {
    const { data, error } = await supabase
      .from('agendamentos')
      .select('*, servicos(nome)')
      .eq('empresa_id', empresaId)
      .eq('cliente_id', clienteId)
      .order('data_agendamento', { ascending: false })

    if (error) {
      console.error('Erro ao carregar histórico:', error)
      return
    }

    setAgendamentos(data || [])
  }

  async function entrar() {
    if (!empresa) return
    if (!nome.trim() || !dataNascimento) {
      setErro('Preencha nome e data de nascimento.')
      return
    }

    setErro('')
    setLoadingLogin(true)

    const { data: clienteExistente, error: clienteErro } = await supabase
      .from('clientes')
      .select('*')
      .eq('empresa_id', empresa.id)
      .ilike('nome', nome.trim())
      .eq('data_nascimento', dataNascimento)
      .maybeSingle()

    if (clienteErro) {
      console.error(clienteErro)
      setErro('Erro ao identificar cliente.')
      setLoadingLogin(false)
      return
    }

    let clienteFinal = clienteExistente

    if (!clienteFinal) {
      const { data: novoCliente, error: novoErro } = await supabase
        .from('clientes')
        .insert([
          {
            empresa_id: empresa.id,
            nome: nome.trim(),
            data_nascimento: dataNascimento,
          },
        ])
        .select()
        .single()

      if (novoErro) {
        console.error(novoErro)
        setErro('Erro ao criar cadastro automático.')
        setLoadingLogin(false)
        return
      }

      clienteFinal = novoCliente
    }

    setCliente(clienteFinal)
    await carregarHistorico(clienteFinal.id, empresa.id)
    setLoadingLogin(false)
  }

  async function salvarAgendamento() {
    if (!empresa || !cliente) return

    if (!servicoId || !dataAgendamento || !hora) {
      setErro('Preencha serviço, data e hora.')
      return
    }

    setErro('')
    setLoadingSalvar(true)

    const existeHorario = await supabase
      .from('agendamentos')
      .select('id')
      .eq('empresa_id', empresa.id)
      .eq('data_agendamento', dataAgendamento)
      .eq('hora', hora)
      .eq('profissional_id', profissionalId || null)

    if (existeHorario.error) {
      console.error(existeHorario.error)
    }

    if (existeHorario.data && existeHorario.data.length > 0) {
      setErro('Este horário já está ocupado.')
      setLoadingSalvar(false)
      return
    }

    const servicoSelecionado = servicos.find((s) => s.id === servicoId)

    const { error } = await supabase.from('agendamentos').insert([
      {
        empresa_id: empresa.id,
        cliente_id: cliente.id,
        servico_id: servicoId,
        profissional_id: profissionalId || null,
        data_agendamento: dataAgendamento,
        hora,
        valor_cobrado: servicoSelecionado?.preco || 0,
        status: 'agendado',
      },
    ])

    if (error) {
      console.error(error)
      setErro('Erro ao salvar agendamento.')
      setLoadingSalvar(false)
      return
    }

    await carregarHistorico(cliente.id, empresa.id)

    setServicoId('')
    setProfissionalId('')
    setDataAgendamento('')
    setHora('')
    setLoadingSalvar(false)
  }

  const tituloEmpresa = useMemo(() => {
    return empresa?.nome || 'Área da Cliente'
  }, [empresa])

  useEffect(() => {
    carregarEmpresa()
  }, [])

  useEffect(() => {
    if (empresa) carregarCatalogos(empresa)
  }, [empresa])

  if (loading) {
    return (
      <main style={styles.page}>
        <div style={styles.centerCard}>Carregando...</div>
      </main>
    )
  }

  if (!empresa) {
    return (
      <main style={styles.page}>
        <div style={styles.centerCard}>Empresa não encontrada.</div>
      </main>
    )
  }

  return (
    <main style={styles.page}>
      <div style={styles.container}>
        <header style={styles.header}>
          <Image src="/logo.png" alt="Logo" width={90} height={90} />
          <h1 style={styles.title}>{tituloEmpresa}</h1>
          <p style={styles.subtitle}>
            Portal da cliente para identificar-se, consultar histórico e realizar
            novos agendamentos.
          </p>
        </header>

        {!cliente ? (
          <div style={styles.gridLogin}>
            <section style={styles.card}>
              <h2 style={styles.cardTitle}>Identifique-se</h2>
              <p style={styles.cardText}>
                Informe seu nome e data de nascimento para acessar seu histórico
                e agendar.
              </p>

              <label style={styles.label}>Nome</label>
              <input
                style={styles.input}
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                placeholder="Seu nome completo"
              />

              <label style={styles.label}>Data de nascimento</label>
              <input
                style={styles.input}
                type="date"
                value={dataNascimento}
                onChange={(e) => setDataNascimento(e.target.value)}
              />

              {erro ? <p style={styles.error}>{erro}</p> : null}

              <button style={styles.buttonPrimary} onClick={entrar} disabled={loadingLogin}>
                {loadingLogin ? 'Entrando...' : 'Entrar'}
              </button>
            </section>

            <section style={styles.card}>
              <h2 style={styles.cardTitle}>Como funciona</h2>
              <ul style={styles.list}>
                <li>Você se identifica com nome e data de nascimento.</li>
                <li>Se ainda não existir cadastro, ele é criado automaticamente.</li>
                <li>Você vê seu histórico e pode agendar novos horários.</li>
              </ul>
            </section>
          </div>
        ) : (
          <div style={styles.gridPortal}>
            <section style={styles.card}>
              <h2 style={styles.cardTitle}>Meu histórico</h2>
              <p style={styles.cardText}>Cliente: {cliente.nome}</p>

              {agendamentos.length === 0 ? (
                <p style={styles.empty}>Nenhum agendamento encontrado.</p>
              ) : (
                <div style={styles.listWrap}>
                  {agendamentos.map((item) => (
                    <div key={item.id} style={styles.itemBox}>
                      <strong>{item.servicos?.nome || 'Serviço'}</strong>
                      <span>
                        {item.data_agendamento} às {item.hora}
                      </span>
                      <span>Status: {item.status || 'agendado'}</span>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <section style={styles.card}>
              <h2 style={styles.cardTitle}>Novo agendamento</h2>

              <label style={styles.label}>Serviço</label>
              <select
                style={styles.input}
                value={servicoId}
                onChange={(e) => setServicoId(e.target.value)}
              >
                <option value="">Selecione</option>
                {servicos.map((servico) => (
                  <option key={servico.id} value={servico.id}>
                    {servico.nome}
                  </option>
                ))}
              </select>

              <label style={styles.label}>Profissional</label>
              <select
                style={styles.input}
                value={profissionalId}
                onChange={(e) => setProfissionalId(e.target.value)}
              >
                <option value="">Sem preferência</option>
                {profissionais.map((profissional) => (
                  <option key={profissional.id} value={profissional.id}>
                    {profissional.nome}
                  </option>
                ))}
              </select>

              <label style={styles.label}>Data</label>
              <input
                style={styles.input}
                type="date"
                value={dataAgendamento}
                onChange={(e) => setDataAgendamento(e.target.value)}
              />

              <label style={styles.label}>Hora</label>
              <input
                style={styles.input}
                type="time"
                value={hora}
                onChange={(e) => setHora(e.target.value)}
              />

              {erro ? <p style={styles.error}>{erro}</p> : null}

              <button
                style={styles.buttonPrimary}
                onClick={salvarAgendamento}
                disabled={loadingSalvar}
              >
                {loadingSalvar ? 'Salvando...' : 'Agendar'}
              </button>
            </section>
          </div>
        )}
      </div>
    </main>
  )
}

const styles: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    background: theme.colors.background,
    padding: 24,
  },
  container: {
    maxWidth: 1200,
    margin: '0 auto',
  },
  header: {
    textAlign: 'center',
    marginBottom: 28,
    color: theme.colors.text,
  },
  title: {
    fontSize: 30,
    margin: '12px 0 8px',
  },
  subtitle: {
    color: theme.colors.textSoft,
    maxWidth: 700,
    margin: '0 auto',
  },
  gridLogin: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
    gap: 20,
  },
  gridPortal: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(380px, 1fr))',
    gap: 20,
  },
  card: {
    background: theme.colors.surface,
    border: `1px solid ${theme.colors.border}`,
    borderRadius: theme.radius.xl,
    padding: 24,
    boxShadow: theme.shadow.md,
  },
  centerCard: {
    maxWidth: 420,
    margin: '80px auto',
    background: theme.colors.surface,
    border: `1px solid ${theme.colors.border}`,
    borderRadius: theme.radius.lg,
    padding: 24,
    textAlign: 'center',
  },
  cardTitle: {
    margin: 0,
    marginBottom: 8,
    color: theme.colors.text,
  },
  cardText: {
    marginTop: 0,
    marginBottom: 16,
    color: theme.colors.textSoft,
  },
  label: {
    display: 'block',
    marginBottom: 6,
    marginTop: 12,
    color: theme.colors.text,
    fontWeight: 600,
  },
  input: {
    width: '100%',
    padding: 12,
    borderRadius: 12,
    border: `1px solid ${theme.colors.border}`,
    outline: 'none',
    background: '#fff',
  },
  buttonPrimary: {
    width: '100%',
    marginTop: 18,
    padding: '14px 18px',
    borderRadius: 14,
    border: 'none',
    background: theme.gradient.primary,
    color: '#fff',
    fontWeight: 700,
    cursor: 'pointer',
  },
  list: {
    paddingLeft: 20,
    color: theme.colors.textSoft,
    lineHeight: 1.7,
  },
  listWrap: {
    display: 'grid',
    gap: 12,
  },
  itemBox: {
    display: 'grid',
    gap: 4,
    padding: 14,
    borderRadius: 14,
    background: theme.colors.highlight,
    border: `1px solid ${theme.colors.border}`,
    color: theme.colors.text,
  },
  empty: {
    color: theme.colors.textMuted,
  },
  error: {
    color: theme.colors.error,
    marginTop: 12,
  },
}