'use client'

import React, { Suspense, useEffect, useMemo, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'

type Profissional = {
  id: string
  nome: string
}

type Servico = {
  id: string
  nome: string
  duracao_padrao_minutos?: number | null
}

type AgendamentoServico = {
  servico_id: string
  ordem?: number | null
  servicos?: Servico | null
}

type Agendamento = {
  id: string
  cliente_id: string
  profissional_id: string
  data_agendamento: string
  hora?: string | null
  hora_inicio?: string | null
  status?: string | null
  agendamento_servicos?: AgendamentoServico[] | null
}

function converterHoraParaMinutos(horaTexto?: string | null) {
  if (!horaTexto) return 0

  const valor = horaTexto.trim().slice(0, 5)
  const [horaParte, minutoParte] = valor.split(':')

  const horas = Number(horaParte || 0)
  const minutos = Number(minutoParte || 0)

  if (Number.isNaN(horas) || Number.isNaN(minutos)) return 0

  return horas * 60 + minutos
}

function formatarMinutosParaHora(totalMinutos: number) {
  const horas = Math.floor(totalMinutos / 60)
  const minutos = totalMinutos % 60

  return `${String(horas).padStart(2, '0')}:${String(minutos).padStart(2, '0')}`
}

function gerarHorariosBase(
  horaInicio = '08:00',
  horaFim = '18:00',
  intervaloMin = 10
) {
  const inicio = converterHoraParaMinutos(horaInicio)
  const fim = converterHoraParaMinutos(horaFim)

  const horarios: string[] = []

  for (let atual = inicio; atual <= fim; atual += intervaloMin) {
    horarios.push(formatarMinutosParaHora(atual))
  }

  return horarios
}

function horariosSeSobrepoem(
  inicioA: number,
  fimA: number,
  inicioB: number,
  fimB: number
) {
  if (fimA <= inicioA) return false
  if (fimB <= inicioB) return false

  return inicioA < fimB && fimA > inicioB
}

function hojeISO() {
  const agora = new Date()
  const ano = agora.getFullYear()
  const mes = String(agora.getMonth() + 1).padStart(2, '0')
  const dia = String(agora.getDate()).padStart(2, '0')
  return `${ano}-${mes}-${dia}`
}

const HORARIOS_BASE = gerarHorariosBase('08:00', '18:00', 10)
const DESCANSO_PROFISSIONAL_MIN = 10

function normalizarServico(raw: any): Servico | null {
  if (!raw || Array.isArray(raw)) return null

  return {
    id: String(raw.id),
    nome: String(raw.nome),
    duracao_padrao_minutos:
      raw.duracao_padrao_minutos != null
        ? Number(raw.duracao_padrao_minutos)
        : null,
  }
}

function normalizarAgendamentoServicos(raw: any): AgendamentoServico[] {
  if (!Array.isArray(raw)) return []

  return raw.map((item) => ({
    servico_id: String(item?.servico_id || ''),
    ordem: item?.ordem != null ? Number(item.ordem) : null,
    servicos: normalizarServico(item?.servicos),
  }))
}

function ConteudoReagendamento() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const idAgendamento = searchParams.get('id')

  const [loading, setLoading] = useState(true)
  const [salvando, setSalvando] = useState(false)
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState(false)

  const [agendamento, setAgendamento] = useState<Agendamento | null>(null)
  const [profissional, setProfissional] = useState<Profissional | null>(null)
  const [servicos, setServicos] = useState<Servico[]>([])
  const [agendamentosDoProfissional, setAgendamentosDoProfissional] = useState<
    Agendamento[]
  >([])

  const [novaData, setNovaData] = useState('')
  const [novoHorario, setNovoHorario] = useState('')

  useEffect(() => {
    async function carregar() {
      try {
        setLoading(true)
        setErro('')

        if (!idAgendamento) {
          setErro('Link inválido para reagendamento.')
          return
        }

        const { data: agendamentoData, error: agendamentoError } = await supabase
          .from('agendamentos')
          .select(`
            id,
            cliente_id,
            profissional_id,
            data_agendamento,
            hora,
            hora_inicio,
            status,
            agendamento_servicos (
              servico_id,
              ordem,
              servicos (
                id,
                nome,
                duracao_padrao_minutos
              )
            )
          `)
          .eq('id', idAgendamento)
          .single()

        if (agendamentoError || !agendamentoData) {
          setErro('Agendamento não encontrado.')
          return
        }

        const ag: Agendamento = {
          id: String(agendamentoData.id),
          cliente_id: String(agendamentoData.cliente_id),
          profissional_id: String(agendamentoData.profissional_id),
          data_agendamento: String(agendamentoData.data_agendamento),
          hora: agendamentoData.hora ? String(agendamentoData.hora) : null,
          hora_inicio: agendamentoData.hora_inicio
            ? String(agendamentoData.hora_inicio)
            : null,
          status: agendamentoData.status ? String(agendamentoData.status) : null,
          agendamento_servicos: normalizarAgendamentoServicos(
            agendamentoData.agendamento_servicos
          ),
        }

        setAgendamento(ag)
        setNovaData(ag.data_agendamento)
        setNovoHorario((ag.hora_inicio || ag.hora || '').slice(0, 5))

        const { data: profData } = await supabase
          .from('profissionais')
          .select('id, nome')
          .eq('id', ag.profissional_id)
          .single()

        if (profData) {
          setProfissional({
            id: String(profData.id),
            nome: String(profData.nome),
          })
        }

        const servicosDoAgendamento =
          ag.agendamento_servicos?.length
            ? ag.agendamento_servicos
                .sort((a, b) => Number(a.ordem || 0) - Number(b.ordem || 0))
                .map((item) => item.servicos)
                .filter(Boolean) as Servico[]
            : []

        setServicos(servicosDoAgendamento)
      } catch (e) {
        console.error(e)
        setErro('Não foi possível carregar os dados para reagendamento.')
      } finally {
        setLoading(false)
      }
    }

    carregar()
  }, [idAgendamento])

  useEffect(() => {
    async function carregarAgendaDoProfissional() {
      if (!agendamento?.profissional_id || !novaData) return

      const { data, error } = await supabase
        .from('agendamentos')
        .select(`
          id,
          cliente_id,
          profissional_id,
          data_agendamento,
          hora,
          hora_inicio,
          status,
          agendamento_servicos (
            servico_id,
            ordem,
            servicos (
              id,
              nome,
              duracao_padrao_minutos
            )
          )
        `)
        .eq('profissional_id', agendamento.profissional_id)
        .eq('data_agendamento', novaData)
        .neq('status', 'cancelado')

      if (!error) {
        const lista: Agendamento[] = ((data || []) as any[]).map((item) => ({
          id: String(item.id),
          cliente_id: String(item.cliente_id),
          profissional_id: String(item.profissional_id),
          data_agendamento: String(item.data_agendamento),
          hora: item.hora ? String(item.hora) : null,
          hora_inicio: item.hora_inicio ? String(item.hora_inicio) : null,
          status: item.status ? String(item.status) : null,
          agendamento_servicos: normalizarAgendamentoServicos(
            item.agendamento_servicos
          ),
        }))

        setAgendamentosDoProfissional(lista)
      }
    }

    carregarAgendaDoProfissional()
  }, [agendamento?.profissional_id, novaData])

  const duracaoTotal = useMemo(() => {
    const base = servicos.reduce(
      (acc, item) => acc + Number(item.duracao_padrao_minutos || 0),
      0
    )
    return base > 0 ? base + DESCANSO_PROFISSIONAL_MIN : 0
  }, [servicos])

  const horariosDisponiveis = useMemo(() => {
    if (!agendamento?.profissional_id || !novaData || duracaoTotal <= 0) {
      return HORARIOS_BASE.map((hora) => ({
        hora,
        livre: false,
        selecionado: hora === novoHorario,
      }))
    }

    return HORARIOS_BASE.map((horaBase) => {
      const inicioNovo = converterHoraParaMinutos(horaBase)
      const fimNovo = inicioNovo + duracaoTotal

      const conflito = agendamentosDoProfissional.some((item) => {
        if (item.id === agendamento.id) return false

        const inicioExistente = converterHoraParaMinutos(
          item.hora_inicio || item.hora
        )

        const duracaoExistenteBase =
          item.agendamento_servicos?.reduce((acc, atual) => {
            return acc + Number(atual.servicos?.duracao_padrao_minutos || 0)
          }, 0) || 0

        const duracaoExistente =
          duracaoExistenteBase > 0
            ? duracaoExistenteBase + DESCANSO_PROFISSIONAL_MIN
            : 0

        if (duracaoExistente <= 0) return false

        const fimExistente = inicioExistente + duracaoExistente

        return horariosSeSobrepoem(
          inicioNovo,
          fimNovo,
          inicioExistente,
          fimExistente
        )
      })

      return {
        hora: horaBase,
        livre: !conflito,
        selecionado: horaBase === novoHorario,
      }
    })
  }, [agendamento, agendamentosDoProfissional, duracaoTotal, novaData, novoHorario])

  async function salvarReagendamento() {
    try {
      setErro('')

      if (!agendamento?.id) {
        setErro('Agendamento inválido.')
        return
      }

      if (!novaData || !novoHorario) {
        setErro('Selecione a nova data e o novo horário.')
        return
      }

      if (duracaoTotal <= 0) {
        setErro('Os serviços deste agendamento não têm duração cadastrada.')
        return
      }

      setSalvando(true)

      const { error } = await supabase
        .from('agendamentos')
        .update({
          data_agendamento: novaData,
          hora: novoHorario,
          status: 'pendente',
        })
        .eq('id', agendamento.id)

      if (error) {
        console.error(error)
        setErro('Não foi possível reagendar agora.')
        return
      }

      setSucesso(true)
    } catch (e) {
      console.error(e)
      setErro('Não foi possível reagendar agora.')
    } finally {
      setSalvando(false)
    }
  }

  if (loading) {
    return <div style={styles.texto}>Carregando reagendamento...</div>
  }

  if (erro && !agendamento) {
    return (
      <div style={styles.cardErro}>
        <strong style={{ display: 'block', marginBottom: 8 }}>Ops!</strong>
        {erro}
      </div>
    )
  }

  if (sucesso) {
    return (
      <>
        <div style={styles.iconeSucesso}>✓</div>
        <h1 style={styles.titulo}>Reagendamento solicitado!</h1>
        <p style={styles.texto}>
          Seu novo horário foi atualizado com sucesso.
        </p>
        <hr style={styles.divisor} />
        <p style={styles.lembrete}>
          Nova data: <strong>{novaData}</strong>
          <br />
          Novo horário: <strong>{novoHorario}</strong>
        </p>
      </>
    )
  }

  return (
    <>
      <h1 style={styles.titulo}>Reagendar horário</h1>
      <p style={styles.texto}>
        Escolha uma nova data e um novo horário para seu atendimento.
      </p>

      <div style={styles.resumoBox}>
        <div>
          <strong>Profissional:</strong> {profissional?.nome || '-'}
        </div>
        <div>
          <strong>Serviços:</strong>{' '}
          {servicos.length ? servicos.map((s) => s.nome).join(' + ') : '-'}
        </div>
        <div>
          <strong>Horário atual:</strong> {agendamento?.data_agendamento} às{' '}
          {(agendamento?.hora_inicio || agendamento?.hora || '').slice(0, 5)}
        </div>
      </div>

      {erro ? <div style={styles.cardErro}>{erro}</div> : null}

      <div style={styles.field}>
        <label style={styles.label}>Nova data</label>
        <input
          type="date"
          value={novaData}
          min={hojeISO()}
          onChange={(e) => setNovaData(e.target.value)}
          style={styles.input}
        />
      </div>

      <div style={{ ...styles.field, marginTop: 18 }}>
        <label style={styles.label}>Novo horário</label>
        <div style={styles.gridHorarios}>
          {horariosDisponiveis.map((item) => (
            <button
              key={item.hora}
              type="button"
              disabled={!item.livre}
              onClick={() => setNovoHorario(item.hora)}
              style={{
                ...styles.botaoHorario,
                ...(item.selecionado ? styles.botaoHorarioSelecionado : {}),
                ...(!item.livre ? styles.botaoHorarioBloqueado : {}),
              }}
            >
              {item.hora}
            </button>
          ))}
        </div>
      </div>

      <div style={styles.actions}>
        <button
          type="button"
          onClick={salvarReagendamento}
          disabled={salvando}
          style={styles.botaoPrincipal}
        >
          {salvando ? 'Salvando...' : 'Confirmar reagendamento'}
        </button>

        <button
          type="button"
          onClick={() => router.push('/')}
          style={styles.botaoSecundario}
        >
          Voltar
        </button>
      </div>
    </>
  )
}

export default function ReagendarAgendamentoPage() {
  return (
    <div style={styles.pagina}>
      <div style={styles.container}>
        <img src="/logo.png" alt="Meu Espaço" style={styles.logo} />
        <Suspense fallback={<div>Carregando...</div>}>
          <ConteudoReagendamento />
        </Suspense>
      </div>
    </div>
  )
}

const styles: { [key: string]: React.CSSProperties } = {
  pagina: {
    minHeight: '100vh',
    background: '#f7f3ef',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '20px',
    fontFamily: 'sans-serif',
  },
  container: {
    background: '#fff',
    borderRadius: '24px',
    padding: '40px 30px',
    width: '100%',
    maxWidth: '720px',
    textAlign: 'center',
    boxShadow: '0 8px 30px rgba(0,0,0,0.08)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
  },
  logo: {
    maxWidth: '180px',
    marginBottom: '30px',
    display: 'block',
  },
  iconeSucesso: {
    width: '70px',
    height: '70px',
    borderRadius: '50%',
    background: '#4caf50',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'white',
    fontSize: '35px',
    marginBottom: '25px',
  },
  titulo: {
    margin: '0 0 15px 0',
    fontSize: '24px',
    color: '#4e3f34',
    fontWeight: 'bold',
  },
  texto: {
    margin: '0',
    fontSize: '15px',
    color: '#8b735d',
    lineHeight: '1.5',
  },
  divisor: {
    width: '100%',
    height: '1px',
    background: '#eadfd6',
    margin: '30px 0',
    border: 'none',
  },
  lembrete: {
    fontSize: '13px',
    color: '#8b735d',
    fontStyle: 'italic',
    margin: '0',
  },
  cardErro: {
    background: '#fff3f3',
    padding: '20px',
    borderRadius: '15px',
    border: '1px solid #ffcccc',
    color: '#cc0000',
    width: '100%',
    marginTop: 20,
  },
  resumoBox: {
    width: '100%',
    textAlign: 'left',
    background: '#faf6f4',
    border: '1px solid #eadfd6',
    borderRadius: 16,
    padding: 16,
    display: 'grid',
    gap: 8,
    marginTop: 20,
  },
  field: {
    width: '100%',
    textAlign: 'left',
  },
  label: {
    display: 'block',
    fontSize: 14,
    fontWeight: 700,
    color: '#5c4a43',
    marginBottom: 8,
  },
  input: {
    width: '100%',
    border: '1px solid #e8ded8',
    borderRadius: 14,
    padding: '12px 14px',
    outline: 'none',
    fontSize: 14,
    background: '#fff',
  },
  gridHorarios: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 1fr)',
    gap: 10,
    marginTop: 8,
  },
  botaoHorario: {
    border: '1px solid #e8ded8',
    borderRadius: 14,
    padding: '12px 10px',
    background: '#ecfdf3',
    cursor: 'pointer',
    fontWeight: 700,
    color: '#2f2724',
  },
  botaoHorarioSelecionado: {
    background: '#6f4b3d',
    color: '#fff',
  },
  botaoHorarioBloqueado: {
    background: '#f3f4f6',
    color: '#9ca3af',
    cursor: 'not-allowed',
  },
  actions: {
    width: '100%',
    display: 'flex',
    gap: 12,
    marginTop: 24,
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  botaoPrincipal: {
    border: 0,
    background: 'linear-gradient(135deg, #2d241f 0%, #59463b 100%)',
    color: '#fff',
    borderRadius: 16,
    padding: '15px 20px',
    fontWeight: 800,
    fontSize: 15,
    cursor: 'pointer',
  },
  botaoSecundario: {
    border: '1px solid #e6d9cf',
    background: '#fff',
    color: '#5c4a43',
    borderRadius: 16,
    padding: '15px 20px',
    fontWeight: 700,
    fontSize: 15,
    cursor: 'pointer',
  },
}