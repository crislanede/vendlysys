'use client'

import Image from 'next/image'
import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { createClient } from '@supabase/supabase-js'
import { theme } from '../../theme'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
)

type Empresa = {
  id: string
  nome: string
  slug: string
}

type Cliente = {
  id: string
  empresa_id: string
  nome: string
  data_nascimento?: string | null
  telefone?: string | null
}

type Profissional = {
  id: string
  empresa_id: string
  nome: string
  ativo?: boolean | null
}

type Servico = {
  id: string
  empresa_id: string
  nome: string
  valor?: number | null
  preco?: number | null
  preco_promocional?: number | null
  duracao_min?: number | null
  duracao_padrao_minutos?: number | null
  ativo?: boolean | null
}

type AgendamentoServico = {
  id?: string
  agendamento_id?: string
  servico_id: string
  servicos?: Servico | null
}

type Agendamento = {
  id: string
  empresa_id: string
  cliente_id: string
  profissional_id?: string | null
  servico_id?: string | null
  data_agendamento: string
  hora: string
  status: string
  cancelado_por?: string | null
  cancelado_em?: string | null
  motivo_cancelamento?: string | null
  servicos?: Servico | null
  agendamento_servicos?: AgendamentoServico[] | null
}

const HORARIOS_BASE = [
  '08:00',
  '08:30',
  '09:00',
  '09:30',
  '10:00',
  '10:30',
  '11:00',
  '11:30',
  '12:00',
  '12:30',
  '13:00',
  '13:30',
  '14:00',
  '14:30',
  '15:00',
  '15:30',
  '16:00',
  '16:30',
  '17:00',
  '17:30',
  '18:00',
]

const ANTECEDENCIA_MINIMA_HORAS = 2

export default function MeuEspacoPage() {
  const searchParams = useSearchParams()
  const empresaSlug = searchParams.get('empresa')
  const reagendamentoId = searchParams.get('reagendar')
  const cancelamentoId = searchParams.get('cancelar')

  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [cliente, setCliente] = useState<Cliente | null>(null)

  const [nome, setNome] = useState('')
  const [diaNascimento, setDiaNascimento] = useState('')
  const [mesNascimento, setMesNascimento] = useState('')
  const [anoNascimento, setAnoNascimento] = useState('')

  const [profissionais, setProfissionais] = useState<Profissional[]>([])
  const [servicos, setServicos] = useState<Servico[]>([])
  const [historico, setHistorico] = useState<Agendamento[]>([])
  const [agendamentosDoDia, setAgendamentosDoDia] = useState<Agendamento[]>([])

  const [profissionalSelecionado, setProfissionalSelecionado] = useState('')
  const [servicoParaAdicionar, setServicoParaAdicionar] = useState('')
  const [servicosSelecionados, setServicosSelecionados] = useState<Servico[]>([])
  const [dataSelecionada, setDataSelecionada] = useState('')
  const [horaSelecionada, setHoraSelecionada] = useState('')

  const [modoReagendamento, setModoReagendamento] = useState(false)
  const [modoCancelamento, setModoCancelamento] = useState(false)
  const [agendamentoOriginal, setAgendamentoOriginal] = useState<Agendamento | null>(null)

  const [loadingPagina, setLoadingPagina] = useState(true)
  const [loading, setLoading] = useState(false)
  const [loadingAgenda, setLoadingAgenda] = useState(false)
  const [erro, setErro] = useState('')
  const [sucesso, setSucesso] = useState('')

  const corPrimaria =
    (theme as any)?.colors?.primary ||
    (theme as any)?.primary ||
    '#9b6b5a'

  const corPrimariaEscura =
    (theme as any)?.colors?.secondary ||
    '#6f4b3d'

  const agendamentosPendentes = useMemo(() => {
    return historico.filter((item) => item.status === 'pendente')
  }, [historico])

  const agendamentosAtivos = useMemo(() => {
    return historico.filter(
      (item) => item.status === 'pendente' || item.status === 'confirmado'
    )
  }, [historico])

  const historicoEncerrado = useMemo(() => {
    return historico.filter(
      (item) => item.status === 'finalizado' || item.status === 'cancelado'
    )
  }, [historico])

  const valorTotalSelecionado = useMemo(() => {
    return servicosSelecionados.reduce((total, servico) => {
      const valor =
        Number(servico.preco_promocional || 0) > 0
          ? Number(servico.preco_promocional)
          : Number(servico.valor || servico.preco || 0)

      return total + valor
    }, 0)
  }, [servicosSelecionados])

  const duracaoTotalSelecionada = useMemo(() => {
    return servicosSelecionados.reduce((total, servico) => {
      return (
        total +
        Number(servico.duracao_min || servico.duracao_padrao_minutos || 0)
      )
    }, 0)
  }, [servicosSelecionados])

  function hojeISO() {
    const agora = new Date()
    const ano = agora.getFullYear()
    const mes = String(agora.getMonth() + 1).padStart(2, '0')
    const dia = String(agora.getDate()).padStart(2, '0')
    return `${ano}-${mes}-${dia}`
  }

  function montarDataNascimentoISO() {
    if (!diaNascimento || !mesNascimento || !anoNascimento) return ''
    const dia = diaNascimento.padStart(2, '0')
    const mes = mesNascimento.padStart(2, '0')
    const ano = anoNascimento.trim()
    return `${ano}-${mes}-${dia}`
  }

  function formatarMoeda(valor: number) {
    return valor.toLocaleString('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    })
  }

  function formatarDataBR(data?: string | null) {
    if (!data) return '-'
    const [ano, mes, dia] = data.split('-')
    if (!ano || !mes || !dia) return data
    return `${dia}/${mes}/${ano}`
  }

  function converterHoraParaMinutos(horaTexto: string) {
    const [horaParte, minutoParte] = horaTexto.split(':')
    const horas = Number(horaParte || 0)
    const minutos = Number(minutoParte || 0)
    return horas * 60 + minutos
  }

  function horariosSeSobrepoem(
    inicioA: number,
    fimA: number,
    inicioB: number,
    fimB: number
  ) {
    return inicioA < fimB && fimA > inicioB
  }

  function getDateTimeFromAgendamento(data: string, hora: string) {
    return new Date(`${data}T${hora}:00`)
  }

  function temAntecedenciaMinima(
    data: string,
    hora: string,
    horasMinimas = ANTECEDENCIA_MINIMA_HORAS
  ) {
    const agora = new Date()
    const dataHoraAgendamento = getDateTimeFromAgendamento(data, hora)
    const diferencaMs = dataHoraAgendamento.getTime() - agora.getTime()
    const diferencaHoras = diferencaMs / (1000 * 60 * 60)
    return diferencaHoras >= horasMinimas
  }

  function horarioJaPassou(data: string, hora: string) {
    const agora = new Date()
    const dataHora = getDateTimeFromAgendamento(data, hora)
    return dataHora.getTime() <= agora.getTime()
  }

  function dataEhPassada(data: string) {
    return data < hojeISO()
  }

  function obterValorServico(servico?: Servico | null) {
    if (!servico) return '-'

    const valor =
      Number(servico.preco_promocional || 0) > 0
        ? Number(servico.preco_promocional)
        : Number(servico.valor || servico.preco || 0)

    if (!valor) return '-'

    return formatarMoeda(valor)
  }

  function obterDuracaoServico(servico?: Servico | null) {
    if (!servico) return '-'
    const duracao = Number(servico.duracao_min || servico.duracao_padrao_minutos || 0)
    return duracao > 0 ? `${duracao} min` : '-'
  }

  function nomesDosServicos(servicosDoAgendamento?: AgendamentoServico[] | null) {
    if (!servicosDoAgendamento?.length) return '-'
    return servicosDoAgendamento
      .map((item) => item.servicos?.nome)
      .filter(Boolean)
      .join(' + ')
  }

  function duracaoTotalDoAgendamento(agendamento: Agendamento) {
    if (agendamento.agendamento_servicos?.length) {
      return agendamento.agendamento_servicos.reduce((total, item) => {
        return (
          total +
          Number(
            item.servicos?.duracao_min ||
              item.servicos?.duracao_padrao_minutos ||
              0
          )
        )
      }, 0)
    }

    return Number(
      agendamento.servicos?.duracao_min ||
        agendamento.servicos?.duracao_padrao_minutos ||
        0
    )
  }

  function existeConflitoDeHorario(
    lista: Agendamento[],
    profissionalIdBusca: string,
    dataBusca: string,
    horaBusca: string,
    duracaoBusca: number,
    ignorarAgendamentoId?: string
  ) {
    const inicioNovo = converterHoraParaMinutos(horaBusca)
    const fimNovo = inicioNovo + duracaoBusca

    return lista.some((item) => {
      if (ignorarAgendamentoId && item.id === ignorarAgendamentoId) return false
      if (item.status === 'cancelado') return false
      if (item.profissional_id !== profissionalIdBusca) return false
      if (item.data_agendamento !== dataBusca) return false

      const duracaoExistente = duracaoTotalDoAgendamento(item)
      const inicioExistente = converterHoraParaMinutos(item.hora)
      const fimExistente = inicioExistente + duracaoExistente

      return horariosSeSobrepoem(
        inicioNovo,
        fimNovo,
        inicioExistente,
        fimExistente
      )
    })
  }

  function profissionalDisponivelNoHorario(profissionalId: string, hora: string) {
    if (!dataSelecionada || !servicosSelecionados.length) return false
    if (dataEhPassada(dataSelecionada)) return false
    if (horarioJaPassou(dataSelecionada, hora)) return false
    if (duracaoTotalSelecionada <= 0) return false

    return !existeConflitoDeHorario(
      agendamentosDoDia,
      profissionalId,
      dataSelecionada,
      hora,
      duracaoTotalSelecionada,
      agendamentoOriginal?.id
    )
  }

  function horarioDisponivel(hora: string) {
    if (!servicosSelecionados.length || !dataSelecionada) return false
    if (!profissionais.length) return false
    if (dataEhPassada(dataSelecionada)) return false
    if (horarioJaPassou(dataSelecionada, hora)) return false

    if (profissionalSelecionado) {
      return profissionalDisponivelNoHorario(profissionalSelecionado, hora)
    }

    return profissionais.some((profissional) =>
      profissionalDisponivelNoHorario(profissional.id, hora)
    )
  }

  function encontrarProfissionalDisponivel(hora: string) {
    if (profissionalSelecionado) {
      return profissionalDisponivelNoHorario(profissionalSelecionado, hora)
        ? profissionalSelecionado
        : null
    }

    const profissionalLivre = profissionais.find((profissional) =>
      profissionalDisponivelNoHorario(profissional.id, hora)
    )

    return profissionalLivre?.id || null
  }

  const horariosComStatus = useMemo(() => {
    return HORARIOS_BASE.map((hora) => ({
      hora,
      livre: horarioDisponivel(hora),
      selecionado: horaSelecionada === hora,
    }))
  }, [
    horaSelecionada,
    dataSelecionada,
    servicosSelecionados,
    profissionalSelecionado,
    agendamentosDoDia,
    profissionais,
    agendamentoOriginal,
    duracaoTotalSelecionada,
  ])

  function podeCancelarAgendamento(agendamento?: Agendamento | null) {
    if (!agendamento) return false
    if (agendamento.status === 'cancelado') return false
    if (agendamento.status === 'finalizado') return false
    return temAntecedenciaMinima(agendamento.data_agendamento, agendamento.hora)
  }

  function podeReagendarAgendamento(agendamento?: Agendamento | null) {
    if (!agendamento) return false
    if (agendamento.status === 'cancelado') return false
    if (agendamento.status === 'finalizado') return false
    return temAntecedenciaMinima(agendamento.data_agendamento, agendamento.hora)
  }

  function podeConfirmarAgendamento(agendamento?: Agendamento | null) {
    if (!agendamento) return false
    if (agendamento.status !== 'pendente') return false
    if (horarioJaPassou(agendamento.data_agendamento, agendamento.hora)) return false
    return true
  }

  function adicionarServico() {
    if (!servicoParaAdicionar) return

    const servico = servicos.find((item) => item.id === servicoParaAdicionar)
    if (!servico) return

    setServicosSelecionados((prev) => {
      const existe = prev.some((item) => item.id === servico.id)
      if (existe) return prev
      return [...prev, servico]
    })

    setServicoParaAdicionar('')
  }

  function removerServico(servicoId: string) {
    setServicosSelecionados((prev) =>
      prev.filter((item) => item.id !== servicoId)
    )
  }

  function limparModoAcao() {
    setModoReagendamento(false)
    setModoCancelamento(false)
    setAgendamentoOriginal(null)
    setProfissionalSelecionado('')
    setServicoParaAdicionar('')
    setServicosSelecionados([])
    setDataSelecionada('')
    setHoraSelecionada('')
  }

  async function carregarEmpresa() {
    if (!empresaSlug) {
      setErro('Empresa não informada na URL.')
      setLoadingPagina(false)
      return
    }

    const { data, error } = await supabase
      .from('empresas')
      .select('*')
      .eq('slug', empresaSlug)
      .single()

    if (error || !data) {
      console.error('Erro ao carregar empresa:', error)
      setErro('Empresa não encontrada.')
      setLoadingPagina(false)
      return
    }

    setEmpresa(data)
    setLoadingPagina(false)
  }

  async function login() {
    const dataNascimento = montarDataNascimentoISO()

    if (!nome || !dataNascimento || !empresa?.id) {
      alert('Preencha nome e data de nascimento.')
      return
    }

    setLoading(true)
    setErro('')
    setSucesso('')

    const { data: clienteExistente, error } = await supabase
      .from('clientes')
      .select('*')
      .eq('empresa_id', empresa.id)
      .ilike('nome', nome.trim())
      .eq('data_nascimento', dataNascimento)
      .maybeSingle()

    if (error) {
      console.log('Erro ao buscar cliente:', error)
      setErro('Erro ao buscar cliente.')
      setLoading(false)
      return
    }

    if (!clienteExistente) {
      setErro('Cliente não encontrado.')
      setLoading(false)
      return
    }

    setCliente(clienteExistente)
    setSucesso(`Bem-vinda, ${clienteExistente.nome}!`)
    setLoading(false)
  }

  async function carregarServicos() {
    if (!empresa?.id) return

    const { data, error } = await supabase
      .from('servicos')
      .select('*')
      .eq('empresa_id', empresa.id)
      .eq('ativo', true)
      .order('nome', { ascending: true })

    if (error) {
      console.error('Erro ao carregar serviços:', error)
      setErro('Erro ao carregar serviços.')
      return
    }

    setServicos(data || [])
  }

  async function carregarProfissionais() {
    if (!empresa?.id) return

    const { data, error } = await supabase
      .from('profissionais')
      .select('*')
      .eq('empresa_id', empresa.id)
      .eq('ativo', true)
      .order('nome', { ascending: true })

    if (error) {
      console.error('Erro ao carregar profissionais:', error)
      setErro('Erro ao carregar profissionais.')
      return
    }

    setProfissionais(data || [])
  }

  async function carregarHistorico(clienteId: string) {
    if (!empresa?.id || !clienteId) return

    const { data, error } = await supabase
      .from('agendamentos')
      .select(`
        *,
        servicos (*),
        agendamento_servicos (
          id,
          servico_id,
          servicos (*)
        )
      `)
      .eq('empresa_id', empresa.id)
      .eq('cliente_id', clienteId)
      .order('data_agendamento', { ascending: false })
      .order('hora', { ascending: false })

    if (error) {
      console.error('Erro ao carregar histórico:', error)
      return
    }

    setHistorico(data || [])
  }

  async function carregarAgendaDoDia() {
    if (!empresa?.id || !dataSelecionada) return

    setLoadingAgenda(true)

    const { data, error } = await supabase
      .from('agendamentos')
      .select(`
        *,
        servicos (*),
        agendamento_servicos (
          id,
          servico_id,
          servicos (*)
        )
      `)
      .eq('empresa_id', empresa.id)
      .eq('data_agendamento', dataSelecionada)
      .in('status', ['pendente', 'confirmado', 'finalizado'])

    if (error) {
      console.error('Erro ao carregar agenda do dia:', error)
      setErro('Erro ao carregar agenda.')
      setLoadingAgenda(false)
      return
    }

    setAgendamentosDoDia(data || [])
    setLoadingAgenda(false)
  }

  async function carregarAgendamentoPorAcao() {
    const idAlvo = reagendamentoId || cancelamentoId
    if (!idAlvo || !empresa?.id) return

    const { data, error } = await supabase
      .from('agendamentos')
      .select(`
        *,
        servicos (*),
        agendamento_servicos (
          id,
          servico_id,
          servicos (*)
        )
      `)
      .eq('id', idAlvo)
      .eq('empresa_id', empresa.id)
      .single()

    if (error || !data) {
      console.error('Erro ao carregar agendamento:', error)
      return
    }

    setAgendamentoOriginal(data)

    const listaServicos =
      data.agendamento_servicos
        ?.map((item: AgendamentoServico) => item.servicos)
        .filter(
          (servico: Servico | null | undefined): servico is Servico =>
            Boolean(servico)
        ) || (data.servicos ? [data.servicos] : [])

    if (reagendamentoId) {
      if (!podeReagendarAgendamento(data)) {
        setErro(
          'Este atendimento não pode mais ser reagendado online. Entre em contato com o estabelecimento.'
        )
        return
      }

      setModoReagendamento(true)
      setModoCancelamento(false)
      setProfissionalSelecionado(String(data.profissional_id || ''))
      setServicosSelecionados(listaServicos)
      setDataSelecionada(data.data_agendamento || '')
      setHoraSelecionada(data.hora || '')
      setSucesso('Reagendamento carregado. Ajuste os dados e confirme.')
    }

    if (cancelamentoId) {
      if (!podeCancelarAgendamento(data)) {
        setErro(
          'Este atendimento não pode mais ser cancelado online. Entre em contato com o estabelecimento.'
        )
        return
      }

      setModoCancelamento(true)
      setModoReagendamento(false)
      setProfissionalSelecionado(String(data.profissional_id || ''))
      setServicosSelecionados(listaServicos)
      setDataSelecionada(data.data_agendamento || '')
      setHoraSelecionada(data.hora || '')
      setSucesso('Cancelamento carregado. Confira os dados e confirme.')
    }
  }

  async function salvarItensDoAgendamento(
    agendamentoId: string,
    servicosIds: string[]
  ) {
    await supabase
      .from('agendamento_servicos')
      .delete()
      .eq('agendamento_id', agendamentoId)

    const itens = servicosIds.map((servicoId) => ({
      agendamento_id: agendamentoId,
      servico_id: servicoId,
    }))

    const { error } = await supabase
      .from('agendamento_servicos')
      .insert(itens)

    if (error) {
      throw error
    }
  }

  async function confirmar() {
    if (!cliente) {
      setErro('Faça login para continuar.')
      return
    }

    if (!empresa?.id) {
      setErro('Empresa não encontrada.')
      return
    }

    if (!servicosSelecionados.length || !dataSelecionada || !horaSelecionada) {
      setErro('Selecione os serviços, a data e o horário.')
      return
    }

    if (dataEhPassada(dataSelecionada)) {
      setErro('Não é possível agendar ou reagendar para uma data passada.')
      return
    }

    if (horarioJaPassou(dataSelecionada, horaSelecionada)) {
      setErro('Esse horário já passou. Escolha um horário futuro.')
      return
    }

    if (duracaoTotalSelecionada <= 0) {
      setErro('Os serviços selecionados precisam ter duração cadastrada.')
      return
    }

    const profissionalDefinido = encontrarProfissionalDisponivel(horaSelecionada)

    if (!profissionalDefinido) {
      setErro('Não há profissional disponível para esse horário.')
      return
    }

    setLoading(true)
    setErro('')
    setSucesso('')

    const primeiroServicoId = servicosSelecionados[0]?.id || null

    const payload = {
      profissional_id: profissionalDefinido,
      servico_id: primeiroServicoId,
      data_agendamento: dataSelecionada,
      hora: horaSelecionada,
      status: 'confirmado',
    }

    try {
      if (modoReagendamento && agendamentoOriginal?.id) {
        if (!podeReagendarAgendamento(agendamentoOriginal)) {
          setErro(
            'Este atendimento não pode mais ser reagendado online. Entre em contato com o estabelecimento.'
          )
          setLoading(false)
          return
        }

        const { error } = await supabase
          .from('agendamentos')
          .update(payload)
          .eq('id', agendamentoOriginal.id)
          .eq('empresa_id', empresa.id)

        if (error) throw error

        await salvarItensDoAgendamento(
          agendamentoOriginal.id,
          servicosSelecionados.map((item) => item.id)
        )

        setSucesso('Reagendamento realizado com sucesso!')
        await carregarHistorico(cliente.id)
        await carregarAgendaDoDia()
        setLoading(false)
        return
      }

      const { data: novoAgendamento, error } = await supabase
        .from('agendamentos')
        .insert({
          ...payload,
          empresa_id: empresa.id,
          cliente_id: cliente.id,
        })
        .select()
        .single()

      if (error || !novoAgendamento) throw error

      await salvarItensDoAgendamento(
        novoAgendamento.id,
        servicosSelecionados.map((item) => item.id)
      )

      setSucesso('Agendamento realizado com sucesso!')
      await carregarHistorico(cliente.id)
      await carregarAgendaDoDia()
      limparModoAcao()
    } catch (error) {
      console.error('Erro ao salvar agendamento:', error)
      setErro('Erro ao salvar agendamento.')
    }

    setLoading(false)
  }

  async function confirmarAgendamentoPendente(id: string) {
    if (!empresa?.id) return

    setLoading(true)
    setErro('')
    setSucesso('')

    const { error } = await supabase
      .from('agendamentos')
      .update({ status: 'confirmado' })
      .eq('id', id)
      .eq('empresa_id', empresa.id)

    if (error) {
      console.error('Erro ao confirmar agendamento:', error)
      setErro('Erro ao confirmar agendamento.')
      setLoading(false)
      return
    }

    if (cliente?.id) {
      await carregarHistorico(cliente.id)
    }

    setSucesso('Agendamento confirmado com sucesso!')
    setLoading(false)
  }

  async function cancelarAgendamento() {
    if (!cliente) {
      setErro('Faça login para continuar.')
      return
    }

    if (!empresa?.id || !agendamentoOriginal?.id) {
      setErro('Agendamento não encontrado.')
      return
    }

    if (!podeCancelarAgendamento(agendamentoOriginal)) {
      setErro(
        'Este atendimento não pode mais ser cancelado online. Entre em contato com o estabelecimento.'
      )
      return
    }

    setLoading(true)
    setErro('')
    setSucesso('')

    const agora = new Date().toISOString()

    const { error } = await supabase
      .from('agendamentos')
      .update({
        status: 'cancelado',
        cancelado_por: 'cliente',
        cancelado_em: agora,
        motivo_cancelamento: 'cancelado pela cliente',
      })
      .eq('id', agendamentoOriginal.id)
      .eq('empresa_id', empresa.id)

    if (error) {
      console.error('Erro ao cancelar:', error)
      setErro('Erro ao cancelar agendamento.')
      setLoading(false)
      return
    }

    setSucesso('Agendamento cancelado com sucesso!')
    await carregarHistorico(cliente.id)
    limparModoAcao()
    setLoading(false)
  }

  async function cancelarAgendamentoDireto(item: Agendamento) {
    if (!cliente) return
    if (!empresa?.id) return

    if (!podeCancelarAgendamento(item)) {
      setErro(
        'Este atendimento não pode mais ser cancelado online. Entre em contato com o estabelecimento.'
      )
      return
    }

    setLoading(true)
    setErro('')
    setSucesso('')

    const agora = new Date().toISOString()

    const { error } = await supabase
      .from('agendamentos')
      .update({
        status: 'cancelado',
        cancelado_por: 'cliente',
        cancelado_em: agora,
        motivo_cancelamento: 'cancelado pela cliente',
      })
      .eq('id', item.id)
      .eq('empresa_id', empresa.id)

    if (error) {
      console.error('Erro ao cancelar agendamento:', error)
      setErro('Erro ao cancelar agendamento.')
      setLoading(false)
      return
    }

    await carregarHistorico(cliente.id)
    setSucesso('Agendamento cancelado com sucesso!')
    setLoading(false)
  }

  function abrirReagendamento(item: Agendamento) {
    if (!podeReagendarAgendamento(item)) {
      setErro(
        'Este atendimento não pode mais ser reagendado online. Entre em contato com o estabelecimento.'
      )
      return
    }

    const listaServicos =
      item.agendamento_servicos
        ?.map((ag: AgendamentoServico) => ag.servicos)
        .filter(
          (servico: Servico | null | undefined): servico is Servico =>
            Boolean(servico)
        ) || (item.servicos ? [item.servicos] : [])

    setModoReagendamento(true)
    setModoCancelamento(false)
    setAgendamentoOriginal(item)
    setProfissionalSelecionado(String(item.profissional_id || ''))
    setServicosSelecionados(listaServicos)
    setDataSelecionada(item.data_agendamento || '')
    setHoraSelecionada(item.hora || '')
    setSucesso('Reagendamento carregado. Ajuste os dados e confirme.')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function abrirCancelamento(item: Agendamento) {
    if (!podeCancelarAgendamento(item)) {
      setErro(
        'Este atendimento não pode mais ser cancelado online. Entre em contato com o estabelecimento.'
      )
      return
    }

    const listaServicos =
      item.agendamento_servicos
        ?.map((ag: AgendamentoServico) => ag.servicos)
        .filter(
          (servico: Servico | null | undefined): servico is Servico =>
            Boolean(servico)
        ) || (item.servicos ? [item.servicos] : [])

    setModoCancelamento(true)
    setModoReagendamento(false)
    setAgendamentoOriginal(item)
    setProfissionalSelecionado(String(item.profissional_id || ''))
    setServicosSelecionados(listaServicos)
    setDataSelecionada(item.data_agendamento || '')
    setHoraSelecionada(item.hora || '')
    setSucesso('Cancelamento carregado. Confira os dados e confirme.')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  useEffect(() => {
    carregarEmpresa()
  }, [])

  useEffect(() => {
    if (empresa?.id) {
      carregarServicos()
      carregarProfissionais()
    }
  }, [empresa])

  useEffect(() => {
    if (cliente?.id) {
      carregarHistorico(cliente.id)
    }
  }, [cliente])

  useEffect(() => {
    if (empresa?.id && dataSelecionada && !modoCancelamento) {
      carregarAgendaDoDia()
      if (!modoReagendamento) {
        setHoraSelecionada('')
      }
    }
  }, [empresa?.id, dataSelecionada])

  useEffect(() => {
    if (empresa?.id && cliente && (reagendamentoId || cancelamentoId)) {
      carregarAgendamentoPorAcao()
    }
  }, [empresa, cliente, reagendamentoId, cancelamentoId])

  if (loadingPagina) {
    return (
      <div style={pageBg}>
        <div style={shellStyle}>
          <div style={loadingCard}>
            <p style={{ margin: 0, color: '#6b7280' }}>Carregando Meu Espaço...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div style={pageBg}>
      <div style={shellStyle}>
        <header style={heroStyle}>
          <div style={heroOverlay} />

          <div style={heroContent}>
            <div style={brandBlock}>
              <div style={logoWrap}>
                <Image
                  src="/logo.png"
                  alt="Espaço Áurea"
                  width={78}
                  height={78}
                  style={{ objectFit: 'contain' }}
                />
              </div>

              <div>
                <span style={brandTag}>Espaço Áurea</span>
                <h1 style={heroTitle}>Meu Espaço</h1>
                <p style={heroSubtitle}>
                  Portal da cliente para acompanhar, confirmar, agendar, reagendar e cancelar.
                </p>
              </div>
            </div>

            <div style={heroBadge}>
              <span style={heroBadgeLabel}>Empresa</span>
              <strong>{empresa?.nome || 'Minha empresa'}</strong>
            </div>
          </div>
        </header>

        <main style={mainCard}>
          {erro ? <div style={alertaErro}>{erro}</div> : null}
          {sucesso ? <div style={alertaSucesso}>{sucesso}</div> : null}

          {!cliente ? (
            <section>
              <div style={sectionHeader}>
                <div>
                  <p style={sectionTag}>Identificação</p>
                  <h2 style={sectionTitle}>Entrar no Meu Espaço</h2>
                </div>
              </div>

              <div style={premiumCard}>
                <div style={cardHeaderRow}>
                  <div>
                    <h3 style={cardTitle}>Dados da cliente</h3>
                    <p style={cardSubtitle}>
                      Informe seu nome e data de nascimento para continuar.
                    </p>
                  </div>
                </div>

                <div style={gridFormStyle}>
                  <div style={{ gridColumn: '1 / -1' }}>
                    <label style={labelStyle}>Nome</label>
                    <input
                      type="text"
                      value={nome}
                      onChange={(e) => setNome(e.target.value)}
                      style={inputStyle}
                      placeholder="Digite seu nome"
                    />
                  </div>

                  <div style={{ gridColumn: '1 / -1' }}>
                    <label style={labelStyle}>Data de nascimento</label>
                    <div style={dobGrid}>
                      <input
                        type="tel"
                        inputMode="numeric"
                        maxLength={2}
                        value={diaNascimento}
                        onChange={(e) =>
                          setDiaNascimento(
                            e.target.value.replace(/\D/g, '').slice(0, 2)
                          )
                        }
                        placeholder="Dia"
                        style={inputStyle}
                      />
                      <input
                        type="tel"
                        inputMode="numeric"
                        maxLength={2}
                        value={mesNascimento}
                        onChange={(e) =>
                          setMesNascimento(
                            e.target.value.replace(/\D/g, '').slice(0, 2)
                          )
                        }
                        placeholder="Mês"
                        style={inputStyle}
                      />
                      <input
                        type="tel"
                        inputMode="numeric"
                        maxLength={4}
                        value={anoNascimento}
                        onChange={(e) =>
                          setAnoNascimento(
                            e.target.value.replace(/\D/g, '').slice(0, 4)
                          )
                        }
                        placeholder="Ano"
                        style={inputStyle}
                      />
                    </div>
                    <p style={hintText}>Exemplo: 07 / 09 / 1990</p>
                  </div>
                </div>

                <div style={footerActions}>
                  <button
                    type="button"
                    onClick={login}
                    disabled={loading}
                    style={{
                      ...primaryButton,
                      background: `linear-gradient(135deg, ${corPrimariaEscura}, ${corPrimaria})`,
                      opacity: loading ? 0.7 : 1,
                      cursor: loading ? 'not-allowed' : 'pointer',
                    }}
                  >
                    {loading ? 'Entrando...' : 'Entrar'}
                  </button>
                </div>
              </div>
            </section>
          ) : (
            <section>
              <div style={sectionHeader}>
                <div>
                  <p style={sectionTag}>Área da cliente</p>
                  <h2 style={sectionTitle}>Olá, {cliente.nome}</h2>
                </div>
              </div>

              {agendamentosPendentes.length > 0 && (
                <div style={pendentesBox}>
                  <div style={cardHeaderRow}>
                    <div>
                      <h3 style={cardTitle}>Aguardando sua confirmação</h3>
                      <p style={cardSubtitle}>
                        Você possui agendamentos pendentes. Confirme ou cancele abaixo.
                      </p>
                    </div>
                  </div>

                  <div style={{ display: 'grid', gap: 14 }}>
                    {agendamentosPendentes.map((item) => (
                      <div key={item.id} style={agendaCardCliente}>
                        <div style={agendaTopBarPendente} />
                        <div style={agendaContentCliente}>
                          <div>
                            <div style={agendaHeadRowCliente}>
                              <strong style={agendaClienteNome}>
                                {nomesDosServicos(item.agendamento_servicos)}
                              </strong>
                              <span style={statusBadge(item.status)}>
                                {item.status}
                              </span>
                            </div>

                            <div style={agendaMiniGrid}>
                              <div style={agendaMiniItem}>
                                <span style={agendaMiniLabel}>Data</span>
                                <span style={agendaMiniValue}>
                                  {formatarDataBR(item.data_agendamento)}
                                </span>
                              </div>

                              <div style={agendaMiniItem}>
                                <span style={agendaMiniLabel}>Hora</span>
                                <span style={agendaMiniValue}>{item.hora}</span>
                              </div>
                            </div>
                          </div>

                          <div style={agendaActionsCliente}>
                            <button
                              type="button"
                              onClick={() => confirmarAgendamentoPendente(item.id)}
                              disabled={!podeConfirmarAgendamento(item)}
                              style={{
                                ...acaoCardButton('#ecfdf3', '#027a48'),
                                opacity: podeConfirmarAgendamento(item) ? 1 : 0.5,
                                cursor: podeConfirmarAgendamento(item)
                                  ? 'pointer'
                                  : 'not-allowed',
                              }}
                            >
                              Confirmar
                            </button>

                            <button
                              type="button"
                              onClick={() => cancelarAgendamentoDireto(item)}
                              disabled={!podeCancelarAgendamento(item)}
                              style={{
                                ...acaoCardButton('#fff1f2', '#be123c'),
                                opacity: podeCancelarAgendamento(item) ? 1 : 0.5,
                                cursor: podeCancelarAgendamento(item)
                                  ? 'pointer'
                                  : 'not-allowed',
                              }}
                            >
                              Cancelar
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {agendamentosAtivos.length > 0 && (
                <div style={{ marginBottom: 24 }}>
                  <div style={cardHeaderRow}>
                    <div>
                      <h3 style={cardTitle}>Meus próximos agendamentos</h3>
                      <p style={cardSubtitle}>
                        Tudo o que está pendente ou confirmado para você.
                      </p>
                    </div>
                  </div>

                  <div style={{ display: 'grid', gap: 14 }}>
                    {agendamentosAtivos.map((item) => (
                      <div key={item.id} style={agendaCardCliente}>
                        <div style={agendaTopBar} />
                        <div style={agendaContentCliente}>
                          <div>
                            <div style={agendaHeadRowCliente}>
                              <strong style={agendaClienteNome}>
                                {nomesDosServicos(item.agendamento_servicos)}
                              </strong>
                              <span style={statusBadge(item.status)}>
                                {item.status}
                              </span>
                            </div>

                            <div style={agendaMiniGrid}>
                              <div style={agendaMiniItem}>
                                <span style={agendaMiniLabel}>Data</span>
                                <span style={agendaMiniValue}>
                                  {formatarDataBR(item.data_agendamento)}
                                </span>
                              </div>

                              <div style={agendaMiniItem}>
                                <span style={agendaMiniLabel}>Hora</span>
                                <span style={agendaMiniValue}>{item.hora}</span>
                              </div>
                            </div>
                          </div>

                          <div style={agendaActionsCliente}>
                            {item.status === 'pendente' && (
                              <button
                                type="button"
                                onClick={() => confirmarAgendamentoPendente(item.id)}
                                disabled={!podeConfirmarAgendamento(item)}
                                style={{
                                  ...acaoCardButton('#ecfdf3', '#027a48'),
                                  opacity: podeConfirmarAgendamento(item) ? 1 : 0.5,
                                  cursor: podeConfirmarAgendamento(item)
                                    ? 'pointer'
                                    : 'not-allowed',
                                }}
                              >
                                Confirmar
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => abrirReagendamento(item)}
                              disabled={!podeReagendarAgendamento(item)}
                              style={{
                                ...acaoCardButton('#fff7ed', '#c2410c'),
                                opacity: podeReagendarAgendamento(item) ? 1 : 0.5,
                                cursor: podeReagendarAgendamento(item)
                                  ? 'pointer'
                                  : 'not-allowed',
                              }}
                            >
                              Reagendar
                            </button>

                            <button
                              type="button"
                              onClick={() => abrirCancelamento(item)}
                              disabled={!podeCancelarAgendamento(item)}
                              style={{
                                ...acaoCardButton('#fff1f2', '#be123c'),
                                opacity: podeCancelarAgendamento(item) ? 1 : 0.5,
                                cursor: podeCancelarAgendamento(item)
                                  ? 'pointer'
                                  : 'not-allowed',
                              }}
                            >
                              Cancelar
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <p style={regraSegurancaText}>
                    Reagendamentos e cancelamentos online ficam disponíveis até{' '}
                    {ANTECEDENCIA_MINIMA_HORAS} horas antes do atendimento.
                  </p>
                </div>
              )}

              {modoReagendamento ? (
                <div style={alertaModoReagendamento}>
                  Você está reagendando um atendimento. Ajuste os serviços, a data e escolha um horário futuro disponível.
                </div>
              ) : null}

              {modoCancelamento ? (
                <div style={alertaModoCancelamento}>
                  Você está no modo de cancelamento. Confira os dados abaixo antes de cancelar.
                </div>
              ) : null}

              <div style={novoGrid}>
                <div style={premiumCard}>
                  <div style={cardHeaderRow}>
                    <div>
                      <h3 style={cardTitle}>
                        {modoCancelamento
                          ? 'Cancelar atendimento'
                          : modoReagendamento
                          ? 'Reagendar atendimento'
                          : 'Novo agendamento'}
                      </h3>
                      <p style={cardSubtitle}>
                        {modoCancelamento
                          ? 'Revise os dados do atendimento e confirme o cancelamento.'
                          : 'Selecione um ou mais serviços, escolha a data e o horário.'}
                      </p>
                    </div>
                  </div>

                  {!modoCancelamento ? (
                    <>
                      <div style={gridFormStyle}>
                        <div style={{ gridColumn: '1 / -1' }}>
                          <label style={labelStyle}>Adicionar serviço</label>
                          <div style={linhaAddServico}>
                            <select
                              value={servicoParaAdicionar}
                              onChange={(e) => setServicoParaAdicionar(e.target.value)}
                              style={inputStyle}
                            >
                              <option value="">Selecione</option>
                              {servicos.map((servico) => (
                                <option key={servico.id} value={servico.id}>
                                  {servico.nome}
                                </option>
                              ))}
                            </select>

                            <button
                              type="button"
                              onClick={adicionarServico}
                              style={{
                                ...primaryButton,
                                background: `linear-gradient(135deg, ${corPrimariaEscura}, ${corPrimaria})`,
                                padding: '12px 18px',
                              }}
                            >
                              Adicionar
                            </button>
                          </div>
                        </div>

                        <div style={{ gridColumn: '1 / -1' }}>
                          <label style={labelStyle}>Serviços escolhidos</label>

                          {!servicosSelecionados.length ? (
                            <div style={smartBox}>
                              <div style={smartHeader}>
                                <span style={smartIcon}>✦</span>
                                <strong>Nenhum serviço adicionado</strong>
                              </div>
                              <p style={smartText}>
                                Adicione um ou mais serviços para continuar.
                              </p>
                            </div>
                          ) : (
                            <div style={tagsWrap}>
                              {servicosSelecionados.map((servico) => (
                                <div key={servico.id} style={tagServico}>
                                  <div>
                                    <strong style={{ color: '#2f2725' }}>
                                      {servico.nome}
                                    </strong>
                                    <div style={tagServicoInfo}>
                                      {obterDuracaoServico(servico)} ·{' '}
                                      {obterValorServico(servico)}
                                    </div>
                                  </div>

                                  <button
                                    type="button"
                                    onClick={() => removerServico(servico.id)}
                                    style={tagRemoveButton}
                                  >
                                    Remover
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        <div>
                          <label style={labelStyle}>Profissional</label>
                          <select
                            value={profissionalSelecionado}
                            onChange={(e) => setProfissionalSelecionado(e.target.value)}
                            style={inputStyle}
                          >
                            <option value="">Sem preferência</option>
                            {profissionais.map((profissional) => (
                              <option key={profissional.id} value={profissional.id}>
                                {profissional.nome}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label style={labelStyle}>Data</label>
                          <input
                            type="date"
                            min={hojeISO()}
                            value={dataSelecionada}
                            onChange={(e) => setDataSelecionada(e.target.value)}
                            style={inputStyle}
                          />
                        </div>

                        <div>
                          <label style={labelStyle}>Valor total</label>
                          <input
                            type="text"
                            value={
                              servicosSelecionados.length
                                ? formatarMoeda(valorTotalSelecionado)
                                : '-'
                            }
                            readOnly
                            style={inputStyleReadOnly}
                          />
                        </div>

                        <div>
                          <label style={labelStyle}>Duração total</label>
                          <input
                            type="text"
                            value={
                              duracaoTotalSelecionada > 0
                                ? `${duracaoTotalSelecionada} min`
                                : '-'
                            }
                            readOnly
                            style={inputStyleReadOnly}
                          />
                        </div>
                      </div>

                      {dataSelecionada && servicosSelecionados.length ? (
                        <div style={{ marginTop: 22 }}>
                          <div style={cardHeaderRow}>
                            <div>
                              <h3 style={cardTitle}>Horários do dia</h3>
                              <p style={cardSubtitle}>
                                Apenas horários futuros e disponíveis podem ser selecionados.
                              </p>
                            </div>
                          </div>

                          {loadingAgenda ? (
                            <div style={loadingAgendaBox}>Carregando horários...</div>
                          ) : (
                            <>
                              <div style={legendaWrap}>
                                <div style={legendaItem}>
                                  <span style={bolinhaLivre} />
                                  <span>Livre</span>
                                </div>

                                <div style={legendaItem}>
                                  <span style={bolinhaBloqueado} />
                                  <span>Bloqueado</span>
                                </div>

                                <div style={legendaItem}>
                                  <span style={bolinhaSelecionado} />
                                  <span>Selecionado</span>
                                </div>
                              </div>

                              <div style={horariosGrid}>
                                {horariosComStatus.map((item) => (
                                  <button
                                    key={item.hora}
                                    type="button"
                                    disabled={!item.livre}
                                    onClick={() => item.livre && setHoraSelecionada(item.hora)}
                                    style={{
                                      ...horarioBotaoBase,
                                      ...(item.selecionado
                                        ? horarioSelecionadoStyle
                                        : item.livre
                                        ? horarioLivreStyle
                                        : horarioBloqueadoStyle),
                                    }}
                                  >
                                    {item.hora}
                                  </button>
                                ))}
                              </div>
                            </>
                          )}
                        </div>
                      ) : (
                        <div style={smartBox}>
                          <div style={smartHeader}>
                            <span style={smartIcon}>✦</span>
                            <strong>Visualização inteligente</strong>
                          </div>
                          <p style={smartText}>
                            Adicione os serviços e escolha a data para visualizar os horários livres e bloqueados.
                          </p>
                        </div>
                      )}

                      <div style={footerActions}>
                        <button
                          type="button"
                          onClick={confirmar}
                          disabled={loading}
                          style={{
                            ...primaryButton,
                            background: `linear-gradient(135deg, ${corPrimariaEscura}, ${corPrimaria})`,
                            opacity: loading ? 0.7 : 1,
                            cursor: loading ? 'not-allowed' : 'pointer',
                          }}
                        >
                          {loading
                            ? 'Salvando...'
                            : modoReagendamento
                            ? 'Confirmar reagendamento'
                            : 'Agendar'}
                        </button>

                        {(modoReagendamento || modoCancelamento) && (
                          <button
                            type="button"
                            onClick={limparModoAcao}
                            style={secondaryButton}
                          >
                            Sair do modo atual
                          </button>
                        )}
                      </div>
                    </>
                  ) : (
                    <>
                      <div style={summaryGrid}>
                        <div style={summaryBox}>
                          <span style={summaryLabel}>Serviços</span>
                          <strong style={summaryValueMenor}>
                            {nomesDosServicos(agendamentoOriginal?.agendamento_servicos)}
                          </strong>
                        </div>

                        <div style={summaryBox}>
                          <span style={summaryLabel}>Data</span>
                          <strong style={summaryValueMenor}>
                            {formatarDataBR(agendamentoOriginal?.data_agendamento || dataSelecionada)}
                          </strong>
                        </div>

                        <div style={summaryBox}>
                          <span style={summaryLabel}>Hora</span>
                          <strong style={summaryValueMenor}>
                            {agendamentoOriginal?.hora || horaSelecionada || '-'}
                          </strong>
                        </div>

                        <div style={summaryBox}>
                          <span style={summaryLabel}>Status</span>
                          <strong style={summaryValueMenor}>
                            {agendamentoOriginal?.status || '-'}
                          </strong>
                        </div>
                      </div>

                      <div style={footerActions}>
                        <button
                          type="button"
                          onClick={cancelarAgendamento}
                          disabled={loading || !podeCancelarAgendamento(agendamentoOriginal)}
                          style={{
                            ...primaryButton,
                            background: 'linear-gradient(135deg, #be123c, #ef4444)',
                            opacity:
                              loading || !podeCancelarAgendamento(agendamentoOriginal)
                                ? 0.7
                                : 1,
                            cursor:
                              loading || !podeCancelarAgendamento(agendamentoOriginal)
                                ? 'not-allowed'
                                : 'pointer',
                          }}
                        >
                          {loading ? 'Cancelando...' : 'Confirmar cancelamento'}
                        </button>

                        <button
                          type="button"
                          onClick={limparModoAcao}
                          style={secondaryButton}
                        >
                          Voltar
                        </button>
                      </div>
                    </>
                  )}
                </div>

                <div style={sideColumn}>
                  <div style={premiumCard}>
                    <div style={cardHeaderRow}>
                      <div>
                        <h3 style={cardTitle}>Resumo do atendimento</h3>
                        <p style={cardSubtitle}>Confira as informações antes de confirmar.</p>
                      </div>
                    </div>

                    <div style={summaryGrid}>
                      <div style={summaryBox}>
                        <span style={summaryLabel}>Serviços</span>
                        <strong style={summaryValueMenor}>
                          {servicosSelecionados.length
                            ? servicosSelecionados.map((item) => item.nome).join(' + ')
                            : '-'}
                        </strong>
                      </div>

                      <div style={summaryBox}>
                        <span style={summaryLabel}>Valor total</span>
                        <strong style={summaryValueMenor}>
                          {servicosSelecionados.length
                            ? formatarMoeda(valorTotalSelecionado)
                            : '-'}
                        </strong>
                      </div>

                      <div style={summaryBox}>
                        <span style={summaryLabel}>Duração total</span>
                        <strong style={summaryValueMenor}>
                          {duracaoTotalSelecionada > 0
                            ? `${duracaoTotalSelecionada} min`
                            : '-'}
                        </strong>
                      </div>

                      <div style={summaryBox}>
                        <span style={summaryLabel}>Horário</span>
                        <strong style={summaryValueMenor}>
                          {agendamentoOriginal?.hora || horaSelecionada || '-'}
                        </strong>
                      </div>
                    </div>
                  </div>

                  <div style={premiumCard}>
                    <div style={cardHeaderRow}>
                      <div>
                        <h3 style={cardTitle}>Histórico</h3>
                        <p style={cardSubtitle}>Atendimentos finalizados ou cancelados.</p>
                      </div>
                    </div>

                    {!historicoEncerrado.length ? (
                      <p style={emptyText}>
                        Nenhum agendamento encerrado encontrado.
                      </p>
                    ) : (
                      <div style={{ display: 'grid', gap: 12 }}>
                        {historicoEncerrado.slice(0, 5).map((item) => (
                          <div key={item.id} style={agendaInfoItem}>
                            <div
                              style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                gap: 12,
                              }}
                            >
                              <strong style={{ color: '#2f2725' }}>
                                {nomesDosServicos(item.agendamento_servicos)}
                              </strong>
                              <span style={statusBadge(item.status)}>
                                {item.status}
                              </span>
                            </div>

                            <div
                              style={{
                                marginTop: 10,
                                color: '#7b6d67',
                                fontSize: 14,
                              }}
                            >
                              {formatarDataBR(item.data_agendamento)} às {item.hora}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </section>
          )}
        </main>
      </div>
    </div>
  )
}

function statusBadge(status: string): React.CSSProperties {
  let bg = '#f3f4f6'
  let color = '#374151'

  if (status === 'pendente') {
    bg = '#fff7ed'
    color = '#c2410c'
  }

  if (status === 'confirmado') {
    bg = '#ecfdf3'
    color = '#027a48'
  }

  if (status === 'finalizado') {
    bg = '#eef4ff'
    color = '#1d4ed8'
  }

  if (status === 'cancelado') {
    bg = '#fff1f2'
    color = '#be123c'
  }

  return {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '8px 14px',
    borderRadius: 999,
    background: bg,
    color,
    fontWeight: 700,
    fontSize: 13,
    whiteSpace: 'nowrap',
  }
}

function acaoCardButton(bg: string, color: string): React.CSSProperties {
  return {
    border: '1px solid rgba(0,0,0,0.04)',
    borderRadius: 12,
    padding: '10px 14px',
    background: bg,
    color,
    cursor: 'pointer',
    fontWeight: 700,
    fontSize: 13,
    boxShadow: '0 6px 14px rgba(17, 24, 39, 0.04)',
  }
}

const pageBg: React.CSSProperties = {
  minHeight: '100vh',
  background:
    'radial-gradient(circle at top left, #f7efe9 0%, #f8f5f2 35%, #f4f1ef 100%)',
  padding: 24,
}

const shellStyle: React.CSSProperties = {
  maxWidth: 1380,
  margin: '0 auto',
}

const heroStyle: React.CSSProperties = {
  position: 'relative',
  overflow: 'hidden',
  borderRadius: 28,
  padding: 28,
  marginBottom: 24,
  background: 'linear-gradient(135deg, #4d342d 0%, #7a5648 52%, #b58774 100%)',
  boxShadow: '0 24px 60px rgba(66, 48, 43, 0.22)',
}

const heroOverlay: React.CSSProperties = {
  position: 'absolute',
  inset: 0,
  background:
    'radial-gradient(circle at top right, rgba(255,255,255,0.18), transparent 35%)',
  pointerEvents: 'none',
}

const heroContent: React.CSSProperties = {
  position: 'relative',
  zIndex: 1,
  display: 'flex',
  justifyContent: 'space-between',
  gap: 20,
  alignItems: 'center',
  flexWrap: 'wrap',
}

const brandBlock: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 18,
  flexWrap: 'wrap',
}

const logoWrap: React.CSSProperties = {
  width: 92,
  height: 92,
  borderRadius: 24,
  background: 'rgba(255,255,255,0.14)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  backdropFilter: 'blur(10px)',
  border: '1px solid rgba(255,255,255,0.18)',
  boxShadow: '0 12px 30px rgba(0,0,0,0.12)',
}

const brandTag: React.CSSProperties = {
  display: 'inline-block',
  marginBottom: 8,
  padding: '6px 12px',
  borderRadius: 999,
  background: 'rgba(255,255,255,0.14)',
  color: '#fff',
  fontSize: 12,
  fontWeight: 700,
  letterSpacing: 0.4,
  textTransform: 'uppercase',
}

const heroTitle: React.CSSProperties = {
  margin: 0,
  color: '#fff',
  fontSize: 34,
  lineHeight: 1.1,
}

const heroSubtitle: React.CSSProperties = {
  margin: '10px 0 0',
  color: 'rgba(255,255,255,0.86)',
  maxWidth: 580,
  fontSize: 15,
}

const heroBadge: React.CSSProperties = {
  minWidth: 220,
  padding: 18,
  borderRadius: 20,
  background: 'rgba(255,255,255,0.12)',
  color: '#fff',
  backdropFilter: 'blur(12px)',
  border: '1px solid rgba(255,255,255,0.16)',
  boxShadow: '0 10px 30px rgba(0,0,0,0.08)',
}

const heroBadgeLabel: React.CSSProperties = {
  display: 'block',
  fontSize: 12,
  marginBottom: 6,
  color: 'rgba(255,255,255,0.78)',
  textTransform: 'uppercase',
  letterSpacing: 0.4,
}

const mainCard: React.CSSProperties = {
  background: 'rgba(255,255,255,0.82)',
  backdropFilter: 'blur(12px)',
  border: '1px solid rgba(255,255,255,0.7)',
  borderRadius: 28,
  padding: 24,
  boxShadow: '0 20px 60px rgba(17, 24, 39, 0.08)',
}

const sectionHeader: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: 18,
}

const sectionTag: React.CSSProperties = {
  margin: 0,
  fontSize: 12,
  textTransform: 'uppercase',
  letterSpacing: 0.5,
  color: '#8a6a5d',
  fontWeight: 800,
}

const sectionTitle: React.CSSProperties = {
  margin: '6px 0 0',
  fontSize: 28,
  color: '#2f2725',
}

const novoGrid: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'minmax(0, 2fr) minmax(320px, 1fr)',
  gap: 22,
}

const sideColumn: React.CSSProperties = {
  display: 'grid',
  gap: 22,
  alignContent: 'start',
}

const premiumCard: React.CSSProperties = {
  background: '#fff',
  border: '1px solid #f0e6df',
  borderRadius: 24,
  padding: 22,
  boxShadow: '0 14px 34px rgba(17, 24, 39, 0.05)',
  marginBottom: 18,
}

const cardHeaderRow: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  gap: 16,
  marginBottom: 18,
}

const cardTitle: React.CSSProperties = {
  margin: 0,
  fontSize: 20,
  color: '#2f2725',
}

const cardSubtitle: React.CSSProperties = {
  margin: '6px 0 0',
  color: '#7b6d67',
  fontSize: 14,
}

const gridFormStyle: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
  gap: 16,
}

const labelStyle: React.CSSProperties = {
  display: 'block',
  marginBottom: 8,
  fontWeight: 700,
  color: '#5a4b45',
  fontSize: 14,
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  border: '1px solid #e8ddd6',
  borderRadius: 14,
  padding: '13px 14px',
  outline: 'none',
  background: '#fff',
  color: '#2f2725',
  fontSize: 14,
  boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.02)',
}

const inputStyleReadOnly: React.CSSProperties = {
  width: '100%',
  border: '1px solid #eee6e0',
  borderRadius: 14,
  padding: '13px 14px',
  outline: 'none',
  background: '#faf8f6',
  color: '#7b6d67',
  fontSize: 14,
}

const footerActions: React.CSSProperties = {
  display: 'flex',
  gap: 12,
  flexWrap: 'wrap',
  marginTop: 24,
}

const primaryButton: React.CSSProperties = {
  border: 'none',
  borderRadius: 16,
  padding: '14px 22px',
  color: '#fff',
  fontWeight: 800,
  boxShadow: '0 18px 35px rgba(111, 75, 61, 0.24)',
}

const secondaryButton: React.CSSProperties = {
  border: '1px solid #eadfd8',
  borderRadius: 16,
  padding: '14px 22px',
  background: '#fff',
  color: '#5d4c45',
  cursor: 'pointer',
  fontWeight: 700,
}

const summaryGrid: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
  gap: 12,
  marginTop: 14,
}

const summaryBox: React.CSSProperties = {
  borderRadius: 18,
  padding: 16,
  background: '#faf6f3',
  border: '1px solid #efe5df',
}

const summaryLabel: React.CSSProperties = {
  display: 'block',
  fontSize: 12,
  color: '#8a7a73',
  textTransform: 'uppercase',
  letterSpacing: 0.4,
  marginBottom: 8,
}

const summaryValueMenor: React.CSSProperties = {
  fontSize: 16,
  color: '#2f2725',
}

const agendaInfoItem: React.CSSProperties = {
  padding: 14,
  borderRadius: 16,
  background: '#faf7f5',
  border: '1px solid #f0e6df',
}

const emptyText: React.CSSProperties = {
  margin: 0,
  color: '#7b6d67',
}

const alertaErro: React.CSSProperties = {
  background: '#fff1f2',
  color: '#be123c',
  padding: 14,
  borderRadius: 16,
  marginBottom: 18,
  border: '1px solid #fecdd3',
  fontWeight: 600,
}

const alertaSucesso: React.CSSProperties = {
  background: '#ecfdf3',
  color: '#027a48',
  padding: 14,
  borderRadius: 16,
  marginBottom: 18,
  border: '1px solid #bbf7d0',
  fontWeight: 600,
}

const loadingCard: React.CSSProperties = {
  background: '#fff',
  borderRadius: 24,
  padding: 32,
  boxShadow: '0 20px 50px rgba(17, 24, 39, 0.08)',
  border: '1px solid #f0e6df',
}

const smartBox: React.CSSProperties = {
  marginTop: 20,
  padding: 18,
  borderRadius: 18,
  background: 'linear-gradient(180deg, #fcf8f5 0%, #f9f3ef 100%)',
  border: '1px solid #f0e4dc',
}

const smartHeader: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 10,
  marginBottom: 8,
  color: '#3f312d',
}

const smartIcon: React.CSSProperties = {
  display: 'inline-flex',
  width: 28,
  height: 28,
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: 999,
  background: '#f1e3da',
}

const smartText: React.CSSProperties = {
  margin: 0,
  color: '#7b6d67',
  lineHeight: 1.6,
  fontSize: 14,
}

const horariosGrid: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(auto-fill, minmax(110px, 1fr))',
  gap: 12,
  marginTop: 14,
}

const horarioBotaoBase: React.CSSProperties = {
  borderRadius: 16,
  padding: '14px 12px',
  fontWeight: 800,
  fontSize: 14,
  border: '1px solid transparent',
  transition: '0.2s ease',
}

const horarioLivreStyle: React.CSSProperties = {
  background: '#ecfdf3',
  color: '#027a48',
  border: '1px solid #bbf7d0',
  cursor: 'pointer',
}

const horarioBloqueadoStyle: React.CSSProperties = {
  background: '#f3f4f6',
  color: '#9ca3af',
  border: '1px solid #e5e7eb',
  cursor: 'not-allowed',
  opacity: 0.8,
}

const horarioSelecionadoStyle: React.CSSProperties = {
  background: 'linear-gradient(135deg, #6f4b3d, #9b6b5a)',
  color: '#fff',
  border: '1px solid transparent',
  cursor: 'pointer',
  boxShadow: '0 14px 30px rgba(111, 75, 61, 0.22)',
}

const legendaWrap: React.CSSProperties = {
  display: 'flex',
  gap: 16,
  flexWrap: 'wrap',
  marginTop: 6,
}

const legendaItem: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  gap: 8,
  color: '#6b7280',
  fontSize: 13,
  fontWeight: 600,
}

const bolinhaLivre: React.CSSProperties = {
  width: 12,
  height: 12,
  borderRadius: 999,
  background: '#22c55e',
  display: 'inline-block',
}

const bolinhaBloqueado: React.CSSProperties = {
  width: 12,
  height: 12,
  borderRadius: 999,
  background: '#d1d5db',
  display: 'inline-block',
}

const bolinhaSelecionado: React.CSSProperties = {
  width: 12,
  height: 12,
  borderRadius: 999,
  background: '#7a5648',
  display: 'inline-block',
}

const loadingAgendaBox: React.CSSProperties = {
  marginTop: 14,
  padding: 16,
  borderRadius: 16,
  background: '#faf7f5',
  border: '1px solid #f0e6df',
  color: '#7b6d67',
  fontWeight: 600,
}

const dobGrid: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '0.8fr 0.8fr 1.2fr',
  gap: 10,
}

const hintText: React.CSSProperties = {
  marginTop: 8,
  marginBottom: 0,
  color: '#8a7a73',
  fontSize: 12,
}

const agendaCardCliente: React.CSSProperties = {
  position: 'relative',
  overflow: 'hidden',
  background: '#fff',
  border: '1px solid #f0e6df',
  borderRadius: 24,
  boxShadow: '0 14px 34px rgba(17, 24, 39, 0.05)',
}

const agendaTopBar: React.CSSProperties = {
  height: 6,
  background: 'linear-gradient(90deg, #7a5648 0%, #b58774 100%)',
}

const agendaTopBarPendente: React.CSSProperties = {
  height: 6,
  background: 'linear-gradient(90deg, #d97706 0%, #f59e0b 100%)',
}

const agendaContentCliente: React.CSSProperties = {
  padding: 20,
  display: 'flex',
  justifyContent: 'space-between',
  gap: 18,
  flexWrap: 'wrap',
}

const agendaHeadRowCliente: React.CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  gap: 12,
  flexWrap: 'wrap',
  marginBottom: 12,
}

const agendaClienteNome: React.CSSProperties = {
  fontSize: 18,
  color: '#2f2725',
}

const agendaMiniGrid: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: 'repeat(2, minmax(100px, 1fr))',
  gap: 10,
}

const agendaMiniItem: React.CSSProperties = {
  padding: 12,
  borderRadius: 14,
  background: '#faf7f5',
  border: '1px solid #f0e6df',
}

const agendaMiniLabel: React.CSSProperties = {
  display: 'block',
  fontSize: 11,
  textTransform: 'uppercase',
  letterSpacing: 0.4,
  color: '#8a7a73',
  marginBottom: 6,
}

const agendaMiniValue: React.CSSProperties = {
  color: '#342b28',
  fontWeight: 700,
}

const agendaActionsCliente: React.CSSProperties = {
  display: 'flex',
  gap: 10,
  flexWrap: 'wrap',
  alignItems: 'flex-start',
}

const alertaModoReagendamento: React.CSSProperties = {
  marginBottom: 18,
  padding: 14,
  borderRadius: 16,
  background: '#fff7ed',
  border: '1px solid #fed7aa',
  color: '#9a3412',
  fontWeight: 600,
}

const alertaModoCancelamento: React.CSSProperties = {
  marginBottom: 18,
  padding: 14,
  borderRadius: 16,
  background: '#fff1f2',
  border: '1px solid #fecdd3',
  color: '#be123c',
  fontWeight: 600,
}

const regraSegurancaText: React.CSSProperties = {
  marginTop: 12,
  marginBottom: 0,
  color: '#8a7a73',
  fontSize: 13,
}

const linhaAddServico: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '1fr auto',
  gap: 10,
  alignItems: 'center',
}

const tagsWrap: React.CSSProperties = {
  display: 'grid',
  gap: 10,
}

const tagServico: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  gap: 12,
  alignItems: 'center',
  padding: 14,
  borderRadius: 16,
  background: '#faf7f5',
  border: '1px solid #f0e6df',
}

const tagServicoInfo: React.CSSProperties = {
  fontSize: 13,
  color: '#7b6d67',
  marginTop: 4,
}

const tagRemoveButton: React.CSSProperties = {
  border: '1px solid #fecdd3',
  background: '#fff1f2',
  color: '#be123c',
  borderRadius: 12,
  padding: '8px 12px',
  fontWeight: 700,
  cursor: 'pointer',
}

const pendentesBox: React.CSSProperties = {
  marginBottom: 24,
  padding: 18,
  borderRadius: 20,
  background: '#fffbeb',
  border: '1px solid #fde68a',
}