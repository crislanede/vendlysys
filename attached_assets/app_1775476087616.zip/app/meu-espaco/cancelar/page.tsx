'use client'

import { useEffect, useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'

function ConteudoCancelar() {
  const searchParams = useSearchParams()
  const id = searchParams.get('id')

  const [status, setStatus] = useState<'carregando' | 'sucesso' | 'erro'>('carregando')

  useEffect(() => {
    async function cancelar() {
      if (!id) {
        setStatus('erro')
        return
      }

      const { error } = await supabase
        .from('agendamentos')
        .update({ status: 'cancelado' })
        .eq('id', id)

      if (error) {
        console.error(error)
        setStatus('erro')
      } else {
        setStatus('sucesso')
      }
    }

    cancelar()
  }, [id])

  if (status === 'carregando') {
    return <div style={styles.texto}>Cancelando seu agendamento...</div>
  }

  if (status === 'erro') {
    return (
      <div style={styles.cardErro}>
        <strong>Ops!</strong><br />
        Não foi possível cancelar.
      </div>
    )
  }

  return (
    <>
      <div style={styles.icone}>✕</div>
      <h1 style={styles.titulo}>Agendamento cancelado</h1>
      <p style={styles.texto}>
        Seu horário foi cancelado com sucesso.
      </p>
    </>
  )
}

export default function CancelarPage() {
  return (
    <div style={styles.pagina}>
      <div style={styles.container}>
        <img src="/logo.png" style={styles.logo} />
        <Suspense fallback={<div>Carregando...</div>}>
          <ConteudoCancelar />
        </Suspense>
      </div>
    </div>
  )
}

const styles: any = {
  pagina: {
    minHeight: '100vh',
    background: '#f7f3ef',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  container: {
    background: '#fff',
    borderRadius: 20,
    padding: 30,
    textAlign: 'center',
  },
  logo: { width: 120, marginBottom: 20 },
  titulo: { fontSize: 22, marginBottom: 10 },
  texto: { color: '#666' },
  icone: {
    fontSize: 40,
    color: '#c0392b',
    marginBottom: 20,
  },
  cardErro: {
    background: '#ffecec',
    padding: 20,
    borderRadius: 10,
    color: '#c0392b',
  },
}