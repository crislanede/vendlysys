'use client'

import React from 'react'
import Image from 'next/image'
import { useRouter } from 'next/navigation'

export default function Home() {
  const router = useRouter()

  const cards = [
    {
      emoji: '📊',
      titulo: 'Dashboard',
      subtitulo: 'Métricas e Gráficos',
      rota: '/dashboard',
    },
    {
      emoji: '👥',
      titulo: 'Clientes',
      subtitulo: 'Cadastrar e gerenciar',
      rota: '/clientes',
    },
    {
      emoji: '🗓️',
      titulo: 'Agenda',
      subtitulo: 'Ver horários e reservas',
      rota: '/agendamentos',
    },
    {
      emoji: '💰',
      titulo: 'Financeiro',
      subtitulo: 'Extratos e faturamento',
      rota: '/financeiro',
    },
    {
      emoji: '💅',
      titulo: 'Serviços',
      subtitulo: 'Configurar procedimentos',
      rota: '/servicos',
    },
    {
      emoji: '✨',
      titulo: 'Área da Cliente',
      subtitulo: 'Link para agendamento',
      rota: '/confirmar',
    },
  ]

  return (
    <div style={s.page}>
      <div style={s.container}>
        <div style={s.topo}>
          <Image
            src="/logo.png"
            alt="Espaço Áurea"
            width={220}
            height={220}
            style={s.logo}
            priority
          />

          <h1 style={s.titulo}>PAINEL ADMINISTRATIVO</h1>
        </div>

        <div style={s.grid}>
          {cards.map((card) => (
            <button
              key={card.titulo}
              type="button"
              style={s.card}
              onClick={() => router.push(card.rota)}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)'
                e.currentTarget.style.boxShadow = '0 12px 28px rgba(80,60,40,0.10)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)'
                e.currentTarget.style.boxShadow = '0 4px 14px rgba(80,60,40,0.06)'
              }}
            >
              <div style={s.emoji}>{card.emoji}</div>
              <div style={s.cardTitulo}>{card.titulo}</div>
              <div style={s.cardSubtitulo}>{card.subtitulo}</div>
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

const s: Record<string, React.CSSProperties> = {
  page: {
    minHeight: '100vh',
    background: '#f4f1ee',
    padding: '40px 20px',
  },
  container: {
    maxWidth: 1120,
    margin: '0 auto',
  },
  topo: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginBottom: 36,
  },
  logo: {
    width: 'auto',
    height: 'auto',
    objectFit: 'contain',
  },
  titulo: {
    margin: '12px 0 0 0',
    fontSize: 18,
    letterSpacing: 4,
    fontWeight: 800,
    color: '#5a473b',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, minmax(0, 1fr))',
    gap: 26,
  },
  card: {
    background: '#ffffff',
    border: '1px solid #eadfd5',
    borderRadius: 26,
    minHeight: 200,
    padding: '28px 20px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    boxShadow: '0 4px 14px rgba(80,60,40,0.06)',
  },
  emoji: {
    fontSize: 44,
    marginBottom: 18,
  },
  cardTitulo: {
    fontSize: 18,
    fontWeight: 800,
    color: '#4c3b31',
    marginBottom: 8,
  },
  cardSubtitulo: {
    fontSize: 14,
    color: '#6e5a4d',
    lineHeight: 1.4,
  },
}