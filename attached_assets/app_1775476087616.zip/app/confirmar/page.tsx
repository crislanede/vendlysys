'use client'

import { useEffect, useState, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { supabase } from '@/lib/supabase'

// Criamos um componente interno para a lógica
function ConteudoConfirmacao() {
  const searchParams = useSearchParams()
  const idAgendamento = searchParams.get('id')
  const [status, setStatus] = useState<'carregando' | 'sucesso' | 'erro'>('carregando')

  useEffect(() => {
    async function confirmar() {
      if (!idAgendamento) {
        setStatus('erro')
        return
      }
      const { error } = await supabase
        .from('agendamentos')
        .update({ status: 'confirmado' })
        .eq('id', idAgendamento)

      if (error) {
        console.error('Erro:', error)
        setStatus('erro')
      } else {
        setStatus('sucesso')
      }
    }
    confirmar()
  }, [idAgendamento])

  if (status === 'carregando') return <div style={styles.texto}>Processando sua confirmação...</div>
  
  if (status === 'erro') return (
    <div style={styles.cardErro}>
      <strong style={{display: 'block', marginBottom: '8px'}}>Ops!</strong>
      O link parece inválido ou houve um problema.
    </div>
  )

  return (
    <>
      <div style={styles.iconeSucesso}>✓</div>
      <h1 style={styles.titulo}>Horário Confirmado!</h1>
      <p style={styles.texto}>
        Obrigada por confirmar. Mal podemos esperar para atender você no{' '}
        <span style={styles.linhaDestaque}>Espaço Áurea</span>!
      </p>
      <hr style={styles.divisor} />
      <p style={styles.lembrete}>
        Lembre-se: em caso de imprevistos, nos avise com antecedência. ✨
      </p>
    </>
  )
}

// Essa é a função principal que o Next.js chama
export default function ConfirmarAgendamento() {
  return (
    <div style={styles.pagina}>
      <div style={styles.container}>
        <img src="/logo.png" alt="Espaço Áurea" style={styles.logo} />
        {/* O Suspense resolve o erro de Prerender da Vercel */}
        <Suspense fallback={<div>Carregando...</div>}>
          <ConteudoConfirmacao />
        </Suspense>
      </div>
    </div>
  )
}

// Estilos (mantidos e centralizados)
const styles: { [key: string]: React.CSSProperties } = {
  pagina: { minHeight: '100vh', background: '#f7f3ef', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '20px', fontFamily: 'sans-serif' },
  container: { background: '#fff', borderRadius: '24px', padding: '40px 30px', width: '100%', maxWidth: '400px', textAlign: 'center', boxShadow: '0 8px 30px rgba(0,0,0,0.08)', display: 'flex', flexDirection: 'column', alignItems: 'center' },
  logo: { maxWidth: '180px', marginBottom: '30px', display: 'block' },
  iconeSucesso: { width: '70px', height: '70px', borderRadius: '50%', background: '#4caf50', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontSize: '35px', marginBottom: '25px' },
  titulo: { margin: '0 0 15px 0', fontSize: '24px', color: '#4e3f34', fontWeight: 'bold' },
  texto: { margin: '0', fontSize: '15px', color: '#8b735d', lineHeight: '1.5' },
  linhaDestaque: { fontWeight: 'bold', color: '#d8bfa3' },
  divisor: { width: '100%', height: '1px', background: '#eadfd6', margin: '30px 0', border: 'none' },
  lembrete: { fontSize: '13px', color: '#8b735d', fontStyle: 'italic', margin: '0' },
  cardErro: { background: '#fff3f3', padding: '20px', borderRadius: '15px', border: '1px solid #ffcccc', color: '#cc0000' }
}