export const HORA_INICIAL_PADRAO = 9
export const HORA_FINAL_PADRAO = 20
export const SLOT_MINUTOS_PADRAO = 30
export const SLOT_HEIGHT = 40

export function horaParaMinutos(hora: string) {
  const [h, m] = hora.split(':').map(Number)
  return h * 60 + m
}

export function minutosParaHora(totalMinutos: number) {
  const horas = Math.floor(totalMinutos / 60)
  const minutos = totalMinutos % 60

  return `${String(horas).padStart(2, '0')}:${String(minutos).padStart(2, '0')}`
}

export function somarHoraDuracao(hora: string, duracaoMinutos: number) {
  return minutosParaHora(horaParaMinutos(hora) + Number(duracaoMinutos || 0))
}

export function calcularTop(
  hora: string,
  horaInicial = HORA_INICIAL_PADRAO,
  slotMinutos = SLOT_MINUTOS_PADRAO
) {
  const inicioAgenda = horaInicial * 60
  const minutos = horaParaMinutos(hora)
  return ((minutos - inicioAgenda) / slotMinutos) * SLOT_HEIGHT
}

export function calcularAltura(
  duracaoMinutos: number,
  slotMinutos = SLOT_MINUTOS_PADRAO
) {
  return (Number(duracaoMinutos || 0) / slotMinutos) * SLOT_HEIGHT
}

export function gerarSlots(
  horaInicial = HORA_INICIAL_PADRAO,
  horaFinal = HORA_FINAL_PADRAO,
  intervalo = SLOT_MINUTOS_PADRAO
) {
  const slots: string[] = []

  for (let h = horaInicial; h < horaFinal; h++) {
    for (let m = 0; m < 60; m += intervalo) {
      slots.push(`${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`)
    }
  }

  return slots
}