import React from 'react'
import { TemaEmpresa } from '@/lib/temaEmpresa'

export function botaoPrimarioTema(tema: TemaEmpresa): React.CSSProperties {
  return {
    border: 'none',
    borderRadius: 12,
    padding: '12px 18px',
    background: `linear-gradient(135deg, ${tema.corSecundaria}, ${tema.corPrimaria})`,
    color: tema.corTextoClaro,
    fontWeight: 700,
    cursor: 'pointer',
  }
}

export function botaoSecundarioTema(tema: TemaEmpresa): React.CSSProperties {
  return {
    border: `1px solid ${tema.corBorda}`,
    borderRadius: 12,
    padding: '12px 18px',
    background: '#fff',
    color: '#3a2f28',
    fontWeight: 700,
    cursor: 'pointer',
  }
}

export function cardTema(tema: TemaEmpresa): React.CSSProperties {
  return {
    background: tema.corCard,
    border: `1px solid ${tema.corBorda}`,
    borderRadius: 20,
    padding: 20,
    boxShadow: '0 10px 24px rgba(17,24,39,0.04)',
  }
}

export function badgeTema(tema: TemaEmpresa): React.CSSProperties {
  return {
    display: 'inline-block',
    padding: '6px 10px',
    borderRadius: 999,
    background: tema.corPrimaria,
    color: '#fff',
    fontSize: 12,
    fontWeight: 700,
  }
}