
import { supabase } from '@/lib/supabase'
import {
  calcularStatusPagamento,
  normalizarFormaPagamento,
} from '@/lib/pagamentos'

export type ServicoSelecionado = {
  id: string
  valor?: number | null
  preco?: number | null
  duracao_minutos?: number | null
  duracao_min?: number | null
  duracao_padrao_minutos?: number | null
}

export function obterValorServico(servico?: {
  valor?: number | null
  preco?: number | null
} | null) {
  return Number(servico?.valor ?? servico?.preco ?? 0)
}

export function obterDuracaoServico(servico?: {
  duracao_minutos?: number | null
  duracao_min?: number | null
  duracao_padrao_minutos?: number | null
} | null) {
  return Number(
    servico?.duracao_minutos ??
      servico?.duracao_min ??
      servico?.duracao_padrao_minutos ??
      0
  )
}

export function valorTotalDoAgendamento(item: {
  valor_total?: number | null
  valor_cobrado?: number | null
  agendamento_servicos?: Array<{
    servicos?: {
      valor?: number | null
      preco?: number | null
    } | null
  }> | null
}) {
  if (Number(item.valor_total || 0) > 0) {
    return Number(item.valor_total)
  }

  if (
    Array.isArray(item.agendamento_servicos) &&
    item.agendamento_servicos.length > 0
  ) {
    return item.agendamento_servicos.reduce((acc, atual) => {
      return acc + obterValorServico(atual?.servicos)
    }, 0)
  }

  return Number(item.valor_cobrado || 0)
}

export function duracaoTotalDoAgendamento(item: {
  duracao_minutos?: number | null
  agendamento_servicos?: Array<{
    servicos?: {
      duracao_minutos?: number | null
      duracao_min?: number | null
      duracao_padrao_minutos?: number | null
    } | null
  }> | null
}) {
  if (Number(item.duracao_minutos || 0) > 0) {
    return Number(item.duracao_minutos)
  }

  if (!Array.isArray(item.agendamento_servicos)) return 0

  return item.agendamento_servicos.reduce((acc, atual) => {
    return acc + obterDuracaoServico(atual?.servicos)
  }, 0)
}

type CriarAgendamentoInput = {
  clienteId: string
  empresaId: string
  profissionalId: string
  dataAgendamento: string
  hora: string
  servicos: ServicoSelecionado[]
  status?: string
}

export async function criarAgendamento(input: CriarAgendamentoInput) {
  const valorTotal = input.servicos.reduce(
    (acc, servico) => acc + obterValorServico(servico),
    0
  )

  const duracaoTotal = input.servicos.reduce(
    (acc, servico) => acc + obterDuracaoServico(servico),
    0
  )

  const { data: agendamento, error } = await supabase
    .from('agendamentos')
    .insert({
      cliente_id: input.clienteId,
      empresa_id: input.empresaId,
      profissional_id: input.profissionalId,
      data_agendamento: input.dataAgendamento,
      hora: input.hora,
      status: input.status || 'confirmado',
      valor_total: valorTotal,
      valor_pago: 0,
      valor_cobrado: valorTotal,
      duracao_minutos: duracaoTotal,
      status_pagamento: 'nao_pago',
      forma_pagamento: null,
    })
    .select()
    .single()

  if (error || !agendamento) {
    throw new Error(error?.message || 'Erro ao criar agendamento.')
  }

  const relacoes = input.servicos.map((servico) => ({
    agendamento_id: agendamento.id,
    servico_id: servico.id,
  }))

  if (relacoes.length > 0) {
    const { error: relacaoError } = await supabase
      .from('agendamento_servicos')
      .insert(relacoes)

    if (relacaoError) {
      throw new Error(relacaoError.message || 'Erro ao vincular serviços.')
    }
  }

  return agendamento
}

export async function atualizarPagamento(
  agendamentoId: string,
  valorPagoInformado: number,
  forma?: string | null
) {
  const formaPagamento = normalizarFormaPagamento(forma)

  const { data, error } = await supabase
    .from('agendamentos')
    .select('id, valor_total, valor_pago, status_pagamento')
    .eq('id', agendamentoId)
    .single()

  if (error || !data) {
    throw new Error('Não foi possível localizar o agendamento.')
  }

  const valorTotal = Number(data.valor_total || 0)
  const valorPago = Number(valorPagoInformado || 0)

  if (valorPago < 0) {
    throw new Error('O valor pago não pode ser negativo.')
  }

  const statusPagamento = calcularStatusPagamento(valorTotal, valorPago)

  const { error: updateError } = await supabase
    .from('agendamentos')
    .update({
      valor_pago: valorPago,
      status_pagamento: statusPagamento,
      forma_pagamento: formaPagamento,
    })
    .eq('id', agendamentoId)

  if (updateError) {
    throw new Error(updateError.message || 'Erro ao atualizar pagamento.')
  }

  return {
    ok: true,
    statusPagamento,
    valorTotal,
    valorPago,
  }
}

export async function cancelarAgendamento(
  agendamentoId: string,
  canceladoPor: 'cliente' | 'empresa' | 'profissional' | 'sistema',
  motivoCancelamento?: string
) {
  const { error } = await supabase
    .from('agendamentos')
    .update({
      status: 'cancelado',
      cancelado_por: canceladoPor,
      cancelado_em: new Date().toISOString(),
      motivo_cancelamento: motivoCancelamento || null,
    })
    .eq('id', agendamentoId)

  if (error) {
    throw new Error(error.message || 'Erro ao cancelar agendamento.')
  }

  return { ok: true }
}

export async function buscarAgendamentosAgendaVisual(
  empresaId: string,
  dataInicio: string,
  dataFim: string,
  profissionalId?: string
) {
  let query = supabase
    .from('agendamentos')
    .select(`
      id,
      cliente_id,
      empresa_id,
      data_agendamento,
      hora,
      status,
      valor_total,
      valor_pago,
      valor_cobrado,
      duracao_minutos,
      profissional_id,
      status_pagamento,
      forma_pagamento,
      cancelado_por,
      cancelado_em,
      motivo_cancelamento,
      clientes (
        id,
        nome,
        telefone
      ),
      profissionais (
        id,
        nome
      ),
      agendamento_servicos (
        servicos (
          id,
          nome,
          valor,
          preco,
          duracao_minutos,
          duracao_min,
          duracao_padrao_minutos
        )
      )
    `)
    .eq('empresa_id', empresaId)
    .gte('data_agendamento', dataInicio)
    .lte('data_agendamento', dataFim)
    .order('data_agendamento', { ascending: true })
    .order('hora', { ascending: true })

  if (profissionalId) {
    query = query.eq('profissional_id', profissionalId)
  }

  const { data, error } = await query

  if (error) {
    throw new Error(error.message || 'Erro ao buscar agendamentos.')
  }

  return data || []
}

export async function buscarAgendamentoPorId(agendamentoId: string) {
  const { data, error } = await supabase
    .from('agendamentos')
    .select(`
      id,
      cliente_id,
      empresa_id,
      data_agendamento,
      hora,
      status,
      valor_total,
      valor_pago,
      valor_cobrado,
      duracao_minutos,
      profissional_id,
      status_pagamento,
      forma_pagamento,
      cancelado_por,
      cancelado_em,
      motivo_cancelamento,
      clientes (
        id,
        nome,
        telefone
      ),
      profissionais (
        id,
        nome
      ),
      agendamento_servicos (
        servicos (
          id,
          nome,
          valor,
          preco,
          duracao_minutos,
          duracao_min,
          duracao_padrao_minutos
        )
      )
    `)
    .eq('id', agendamentoId)
    .single()

  if (error) {
    throw new Error(error.message || 'Erro ao buscar agendamento.')
  }

  return data
}