import { supabase } from "@/lib/supabase"

type EnviarLembreteParams = {
  telefone: string
  mensagem: string
  empresaId: string
  agendamentoId: string
}

function limparTelefone(telefone: string) {
  return telefone.replace(/\D/g, "")
}

export async function enviarLembreteWhatsapp({
  telefone,
  mensagem,
  empresaId,
  agendamentoId,
}: EnviarLembreteParams) {
  const telefoneLimpo = limparTelefone(telefone)

  if (!telefoneLimpo) {
    throw new Error("Telefone inválido para envio de WhatsApp.")
  }

  // Aqui você pode trocar para API real depois.
  // Por enquanto, grava log do envio e deixa preparado.
  const payload = {
    empresa_id: empresaId,
    agendamento_id: agendamentoId,
    telefone: telefoneLimpo,
    mensagem,
    tipo: "lembrete",
    status: "pendente",
    criado_em: new Date().toISOString(),
  }

  const { error } = await supabase.from("whatsapp_logs").insert([payload])

  if (error) {
    throw error
  }

  return { ok: true }
}