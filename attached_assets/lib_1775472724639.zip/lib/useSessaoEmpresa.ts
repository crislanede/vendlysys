'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

type Empresa = {
  id: string
  nome: string
  slug: string
  logo_url?: string | null
  cor_primaria?: string | null
  cor_secundaria?: string | null
  ativa?: boolean | null
}

type UsuarioEmpresa = {
  auth_user_id: string
  empresa_id: string
  nome: string
  email: string
  perfil?: string | null
  ativo?: boolean | null
  empresas?: Empresa | null
}

type ResultadoSessaoEmpresa = {
  usuario: any
  empresa: Empresa | null
  logado: boolean
  loading: boolean
  perfil: string | null
  recarregarSessao: () => Promise<void>
}

export function useSessaoEmpresa(): ResultadoSessaoEmpresa {
  const [usuario, setUsuario] = useState<any>(null)
  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [logado, setLogado] = useState(false)
  const [loading, setLoading] = useState(true)
  const [perfil, setPerfil] = useState<string | null>(null)

  useEffect(() => {
    carregarSessao()

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(() => {
      carregarSessao()
    })

    return () => {
      subscription.unsubscribe()
    }
  }, [])

  async function carregarSessao() {
    try {
      setLoading(true)

      const {
        data: { session },
        error: sessionError,
      } = await supabase.auth.getSession()

      if (sessionError) {
        throw new Error(sessionError.message || 'Erro ao obter sessão.')
      }

      if (!session?.user) {
        setUsuario(null)
        setEmpresa(null)
        setLogado(false)
        setPerfil(null)
        setLoading(false)
        return
      }

      const user = session.user

      setUsuario(user)
      setLogado(true)

      const { data: vinculo, error: vinculoError } = await supabase
        .from('usuarios_empresa')
        .select(`
          auth_user_id,
          empresa_id,
          nome,
          email,
          perfil,
          ativo,
          empresas (
            id,
            nome,
            slug,
            logo_url,
            cor_primaria,
            cor_secundaria,
            ativa
          )
        `)
        .eq('auth_user_id', user.id)
        .maybeSingle()

      if (vinculoError) {
        throw new Error(vinculoError.message || 'Erro ao buscar vínculo do usuário.')
      }

      if (!vinculo) {
        setEmpresa(null)
        setPerfil(null)
        setLoading(false)
        return
      }

      const resultado = vinculo as unknown as UsuarioEmpresa

      setPerfil(resultado.perfil || null)

      if (!resultado.empresas) {
        setEmpresa(null)
        setLoading(false)
        return
      }

      setEmpresa(resultado.empresas)
    } catch (error: unknown) {
      const mensagem =
        error instanceof Error
          ? error.message
          : typeof error === 'string'
          ? error
          : JSON.stringify(error)

      console.error('Erro ao carregar sessão:', mensagem, error)

      setLogado(false)
      setEmpresa(null)
      setUsuario(null)
      setPerfil(null)
    } finally {
      setLoading(false)
    }
  }

  return {
    usuario,
    empresa,
    logado,
    loading,
    perfil,
    recarregarSessao: carregarSessao,
  }
}