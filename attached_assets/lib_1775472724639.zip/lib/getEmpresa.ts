import { supabase } from "@/lib/supabase"

export type Empresa = {
  id: string
  nome: string
  slug: string
  logo_url?: string | null
  cor_primaria?: string | null
  cor_secundaria?: string | null
  ativo?: boolean | null
}

export async function getEmpresaBySlug(
  slug?: string | null
): Promise<Empresa | null> {
  try {
    const slugFinal =
      slug || process.env.NEXT_PUBLIC_EMPRESA_SLUG_PADRAO || null

    if (!slugFinal) {
      console.error("Slug da empresa não informado")
      return null
    }

    const { data, error } = await supabase
      .from("empresas")
      .select("*")
      .eq("slug", slugFinal)
      .maybeSingle()

    if (error) {
      console.error("Erro ao carregar empresa:", error)
      return null
    }

    if (!data) {
      console.warn("Empresa não encontrada para o slug:", slugFinal)
      return null
    }

    return data as Empresa
  } catch (err) {
    console.error("Erro inesperado ao buscar empresa:", err)
    return null
  }
}