export type TemaEmpresa = {
  corPrimaria: string
  corSecundaria: string
  corTextoClaro: string
  corFundo: string
  corCard: string
  corBorda: string
}

export function getTemaEmpresa(empresa?: {
  cor_primaria?: string | null
  cor_secundaria?: string | null
} | null): TemaEmpresa {
  const corPrimaria = empresa?.cor_primaria || '#b8956f'
  const corSecundaria = empresa?.cor_secundaria || '#6f4b3d'

  return {
    corPrimaria,
    corSecundaria,
    corTextoClaro: '#ffffff',
    corFundo: '#f6f1ee',
    corCard: '#ffffff',
    corBorda: '#eadfd8',
  }
}