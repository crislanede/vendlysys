export type FormaPagamento =
  | 'pix'
  | 'dinheiro'
  | 'cartao'
  | 'cartao_credito'
  | 'cartao_debito'
  | null

export type StatusPagamento =
  | 'nao_pago'
  | 'parcial'
  | 'pago'
  | 'estornado'

export function normalizarFormaPagamento(
  forma?: string | null
): FormaPagamento {
  if (!forma) return null

  const valor = forma
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, '_')
    .trim()

  if (
    valor === 'pix' ||
    valor === 'dinheiro' ||
    valor === 'cartao' ||
    valor === 'cartao_credito' ||
    valor === 'cartao_debito'
  ) {
    return valor
  }

  return null
}

export function calcularStatusPagamento(
  valorTotal: number,
  valorPago: number
): StatusPagamento {
  const total = Number(valorTotal || 0)
  const pago = Number(valorPago || 0)

  if (pago <= 0) return 'nao_pago'
  if (pago < total) return 'parcial'
  return 'pago'
}

export function calcularSaldo(valorTotal: number, valorPago: number) {
  return Math.max(Number(valorTotal || 0) - Number(valorPago || 0), 0)
}

export function formatarFormaPagamento(forma?: string | null) {
  if (!forma) return '-'
  if (forma === 'pix') return 'Pix'
  if (forma === 'dinheiro') return 'Dinheiro'
  if (forma === 'cartao') return 'Cartão'
  if (forma === 'cartao_credito') return 'Cartão crédito'
  if (forma === 'cartao_debito') return 'Cartão débito'
  return forma
}