import { supabase } from '@/lib/supabase'

type CriarLogWhatsappInput = {
  empresaId: string
  agendamentoId?: string | null
  clienteId?: string | null
  telefone: string
  tipo:
    | 'confirmacao'
    | 'lembrete_24h'
    | 'lembrete_2h'
    | 'cancelamento'
    | 'reagendamento'
    | 'pagamento'
  conteudo: string
  statusEnvio?: 'pendente' | 'enviado' | 'erro'
  erro?: string | null
}

export async function criarLogWhatsapp(input: CriarLogWhatsappInput) {
  const { data, error } = await supabase
    .from('mensagens_whatsapp')
    .insert({
      empresa_id: input.empresaId,
      agendamento_id: input.agendamentoId || null,
      cliente_id: input.clienteId || null,
      telefone: input.telefone,
      tipo: input.tipo,
      conteudo: input.conteudo,
      status_envio: input.statusEnvio || 'pendente',
      erro: input.erro || null,
      enviado_em: input.statusEnvio === 'enviado' ? new Date().toISOString() : null,
    })
    .select()
    .single()

  if (error) {
    throw new Error(error.message || 'Erro ao registrar log de WhatsApp.')
  }

  return data
}