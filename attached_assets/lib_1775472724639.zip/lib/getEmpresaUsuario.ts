import { supabase } from "@/lib/supabase"

export async function getEmpresaDoUsuarioLogado() {
  const { data: userData, error: userError } = await supabase.auth.getUser()

  if (userError) throw userError

  const user = userData.user
  if (!user) return null

  const { data: vinculo, error } = await supabase
    .from("usuarios_empresa")
    .select(`
      id,
      auth_user_id,
      empresa_id,
      nome,
      email,
      perfil,
      ativo,
      empresas (
        id,
        nome,
        slug,
        logo_url,
        cor_primaria,
        cor_secundaria,
        ativo
      )
    `)
    .eq("auth_user_id", user.id)
    .eq("ativo", true)
    .maybeSingle()

  if (error) throw error
  if (!vinculo) return null

  const empresa = Array.isArray(vinculo.empresas)
    ? vinculo.empresas[0]
    : vinculo.empresas

  return {
    usuario: vinculo,
    empresa,
  }
}