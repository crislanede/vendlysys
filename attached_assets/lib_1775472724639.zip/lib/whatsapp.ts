type MensagemConfirmacaoInput = {
  nomeCliente: string
  data: string
  hora: string
  servicos: string[]
}

type MensagemCancelamentoInput = {
  nomeCliente: string
  data: string
  hora: string
}

type MensagemLembreteInput = {
  nomeCliente: string
  data: string
  hora: string
  servicos: string[]
}

export function montarMensagemConfirmacao({
  nomeCliente,
  data,
  hora,
  servicos,
}: MensagemConfirmacaoInput) {
  return `Olá, ${nomeCliente}! Seu agendamento foi confirmado para ${data} às ${hora}. Serviço(s): ${servicos.join(', ')}.`
}

export function montarMensagemCancelamento({
  nomeCliente,
  data,
  hora,
}: MensagemCancelamentoInput) {
  return `Olá, ${nomeCliente}. Seu agendamento do dia ${data} às ${hora} foi cancelado.`
}

export function montarMensagemLembrete24h({
  nomeCliente,
  data,
  hora,
  servicos,
}: MensagemLembreteInput) {
  return `Olá, ${nomeCliente}! Lembrete: você tem agendamento em ${data} às ${hora}. Serviço(s): ${servicos.join(', ')}.`
}

export function montarMensagemLembrete2h({
  nomeCliente,
  data,
  hora,
  servicos,
}: MensagemLembreteInput) {
  return `Olá, ${nomeCliente}! Seu atendimento será hoje às ${hora}. Serviço(s): ${servicos.join(', ')}.`
}