"use client"

import { useEffect, useState } from "react"
import { getEmpresaBySlug, type Empresa } from "@/lib/getEmpresa"

export function useEmpresa() {
  const [empresa, setEmpresa] = useState<Empresa | null>(null)
  const [loadingEmpresa, setLoadingEmpresa] = useState(true)

  useEffect(() => {
    async function carregarEmpresa() {
      try {
        const params = new URLSearchParams(window.location.search)
        const slug =
          params.get("empresa") ||
          process.env.NEXT_PUBLIC_EMPRESA_SLUG_PADRAO ||
          null

        const empresaEncontrada = await getEmpresaBySlug(slug)
        setEmpresa(empresaEncontrada)
      } catch (error) {
        console.error("Erro ao carregar empresa:", error)
        setEmpresa(null)
      } finally {
        setLoadingEmpresa(false)
      }
    }

    carregarEmpresa()
  }, [])

  return {
    empresa,
    loadingEmpresa,
  }
}