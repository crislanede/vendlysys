'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
const menu = [
  { label: 'Início', href: '/inicio' },
  { label: 'Dashboard', href: '/dashboard' },
  { label: 'Agenda', href: '/agenda' },
  { label: 'Agendamentos', href: '/agendamentos' },
  { label: 'Clientes', href: '/clientes' },
  { label: 'Financeiro', href: '/financeiro' },
]
type Empresa = {
  nome?: string | null
}

type Props = {
  empresa?: Empresa | null
  nomeUsuario?: string
}

export default function HeaderGlobal({
  empresa,
  nomeUsuario = 'Usuário',
}: Props) {
  const pathname = usePathname()

  const menu = [
    { label: 'Dashboard', href: '/dashboard' },
    { label: 'Agenda', href: '/agendamentos' },
    { label: 'Clientes', href: '/clientes' },
    { label: 'Financeiro', href: '/financeiro' },
  ]

  return (
    <header
      style={{
        width: '100%',
        background: '#ffffff',
        borderBottom: '1px solid #e5e7eb',
        position: 'sticky',
        top: 0,
        zIndex: 50,
      }}
    >
      <div
        style={{
          maxWidth: 1200,
          margin: '0 auto',
          padding: '12px 20px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: 20,
          flexWrap: 'wrap',
        }}
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 16,
            minWidth: 0,
          }}
        >
          <Link
            href="/dashboard"
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: 14,
              textDecoration: 'none',
            }}
          >
            <img
              src="/vendlysys-logo.png"
              alt="VendlySys"
              style={{
                height: 52,
                width: 'auto',
                objectFit: 'contain',
                display: 'block',
              }}
            />
          </Link>

          <span style={{ color: '#d1d5db' }}>|</span>

          <div style={{ minWidth: 0 }}>
            <div
              style={{
                fontSize: 11,
                fontWeight: 700,
                letterSpacing: 1,
                textTransform: 'uppercase',
                color: '#9ca3af',
              }}
            >
              Empresa ativa
            </div>

            <div
              style={{
                fontSize: 16,
                fontWeight: 700,
                color: '#111827',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                maxWidth: 220,
              }}
            >
              {empresa?.nome || 'Empresa'}
            </div>
          </div>
        </div>

        <nav
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            flexWrap: 'wrap',
          }}
        >
          {menu.map((item) => {
            const ativo = pathname === item.href

            return (
              <Link
                key={item.href}
                href={item.href}
                style={{
                  padding: '8px 12px',
                  borderRadius: 10,
                  textDecoration: 'none',
                  background: ativo ? '#eff6ff' : 'transparent',
                  color: ativo ? '#1d4ed8' : '#374151',
                  border: ativo ? '1px solid #bfdbfe' : '1px solid transparent',
                  fontWeight: ativo ? 700 : 500,
                }}
              >
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 10,
            background: '#f9fafb',
            border: '1px solid #e5e7eb',
            borderRadius: 999,
            padding: '8px 12px',
          }}
        >
          <div
            style={{
              width: 34,
              height: 34,
              borderRadius: '50%',
              background: '#dbeafe',
              color: '#1d4ed8',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 800,
              fontSize: 14,
              flexShrink: 0,
            }}
          >
            {nomeUsuario.charAt(0).toUpperCase()}
          </div>

          <div>
            <div
              style={{
                fontSize: 12,
                color: '#6b7280',
                lineHeight: 1.1,
              }}
            >
              Logado como
            </div>

            <div
              style={{
                fontSize: 14,
                fontWeight: 700,
                color: '#111827',
                lineHeight: 1.2,
              }}
            >
              {nomeUsuario}
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}