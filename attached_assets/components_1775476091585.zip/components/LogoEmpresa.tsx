type Props = {
  logoUrl?: string | null
  nome?: string
  size?: number
}

export default function LogoEmpresa({
  logoUrl,
  nome,
  size = 40,
}: Props) {
  const src = logoUrl || "/logo.png"

  return (
    <img
      src={src}
      alt={nome || "Logo"}
      style={{
        width: size,
        height: size,
        objectFit: "contain",
        borderRadius: 8,
      }}
    />
  )
}