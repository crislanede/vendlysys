export default function HeaderEmpresa() {
  return null
}