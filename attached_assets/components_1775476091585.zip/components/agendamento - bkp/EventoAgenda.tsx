'use client'

import { calcularAltura, calcularTop } from '@/lib/agenda'

type EventoAgendaProps = {
  evento: {
    id: string
    clienteNome: string
    inicio: string
    fim: string
    duracaoMinutos: number
    status: string
    statusPagamento: string | null
    servicos: string[]
  }
  onClick?: (id: string) => void
}

function corPorStatus(status: string) {
  switch (status) {
    case 'confirmado':
      return 'bg-green-100 border-green-400 text-green-900'
    case 'pendente':
      return 'bg-yellow-100 border-yellow-400 text-yellow-900'
    case 'cancelado':
      return 'bg-red-100 border-red-400 text-red-900'
    case 'concluido':
      return 'bg-blue-100 border-blue-400 text-blue-900'
    default:
      return 'bg-gray-100 border-gray-300 text-gray-900'
  }
}

function bordaPagamento(statusPagamento?: string | null) {
  switch (statusPagamento) {
    case 'pago':
      return 'border-solid'
    case 'parcial':
      return 'border-dashed'
    default:
      return 'border-dotted'
  }
}

export function EventoAgenda({ evento, onClick }: EventoAgendaProps) {
  return (
    <button
      type="button"
      onClick={() => onClick?.(evento.id)}
      className={[
        'absolute left-1 right-1 rounded-md border-l-4 p-2 text-left shadow-sm overflow-hidden',
        corPorStatus(evento.status),
        bordaPagamento(evento.statusPagamento),
      ].join(' ')}
      style={{
        top: `${calcularTop(evento.inicio)}px`,
        height: `${calcularAltura(evento.duracaoMinutos)}px`,
      }}
    >
      <div className="text-xs font-semibold">
        {evento.inicio} - {evento.fim}
      </div>

      <div className="text-sm font-bold truncate">
        {evento.clienteNome}
      </div>

      <div className="text-xs truncate">
        {evento.servicos.join(', ')}
      </div>

      <div className="mt-1 text-[11px] uppercase">
        {evento.status} • {evento.statusPagamento || 'nao_pago'}
      </div>
    </button>
  )
}