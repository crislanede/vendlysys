'use client'

import { EventoAgenda } from './EventoAgenda'
import { gerarSlots } from '@/lib/agenda'

type Profissional = {
  id: string
  nome: string
}

type Evento = {
  id: string
  profissionalId: string
  clienteNome: string
  inicio: string
  fim: string
  duracaoMinutos: number
  status: string
  statusPagamento: string | null
  servicos: string[]
}

type AgendaGridProps = {
  profissionais: Profissional[]
  eventos: Evento[]
  onEventoClick?: (id: string) => void
  onSlotClick?: (profissionalId: string, hora: string) => void
}

export function AgendaGrid({
  profissionais,
  eventos,
  onEventoClick,
  onSlotClick,
}: AgendaGridProps) {
  const slots = gerarSlots(8, 20, 30)
  const alturaTotal = slots.length * 40

  return (
    <div className="w-full overflow-auto rounded-xl border bg-white">
      <div
        className="grid min-w-[900px]"
        style={{
          gridTemplateColumns: `80px repeat(${profissionais.length}, minmax(220px, 1fr))`,
        }}
      >
        <div className="sticky top-0 z-20 border-b bg-white p-3 font-semibold">
          Hora
        </div>

        {profissionais.map((profissional) => (
          <div
            key={profissional.id}
            className="sticky top-0 z-20 border-b border-l bg-white p-3 text-center font-semibold"
          >
            {profissional.nome}
          </div>
        ))}

        <div className="relative border-r">
          {slots.map((slot) => (
            <div
              key={slot}
              className="h-10 border-b px-2 pt-1 text-xs text-gray-500"
            >
              {slot}
            </div>
          ))}
        </div>

        {profissionais.map((profissional) => {
          const eventosDoProfissional = eventos.filter(
            (evento) => evento.profissionalId === profissional.id
          )

          return (
            <div
              key={profissional.id}
              className="relative border-l"
              style={{ height: `${alturaTotal}px` }}
            >
              {slots.map((slot) => (
                <button
                  key={`${profissional.id}-${slot}`}
                  type="button"
                  onClick={() => onSlotClick?.(profissional.id, slot)}
                  className="block h-10 w-full border-b hover:bg-gray-50"
                />
              ))}

              {eventosDoProfissional.map((evento) => (
                <EventoAgenda
                  key={evento.id}
                  evento={evento}
                  onClick={onEventoClick}
                />
              ))}
            </div>
          )
        })}
      </div>
    </div>
  )
}