'use client'

import { useEffect, useMemo, useState } from 'react'
import { atualizarPagamento, cancelarAgendamento } from '@/lib/agendamentos'
import { calcularSaldo, podeEditarPagamento } from '@/lib/pagamentos'

type DetalheAgendamentoProps = {
  aberto: boolean
  agendamento: {
    id: string
    clienteNome: string
    profissionalNome: string
    data: string
    inicio: string
    fim: string
    status: string
    statusPagamento: string | null
    formaPagamento: string | null
    valorTotal: number
    valorPago: number
    servicos: string[]
    motivoCancelamento?: string | null
    canceladoPor?: string | null
    telefoneCliente?: string | null
  } | null
  onFechar: () => void
  onAtualizado?: () => void
}

export function DetalheAgendamento({
  aberto,
  agendamento,
  onFechar,
  onAtualizado,
}: DetalheAgendamentoProps) {
  const [valorPago, setValorPago] = useState('')
  const [formaPagamento, setFormaPagamento] = useState('pix')
  const [motivoCancelamento, setMotivoCancelamento] = useState('')
  const [salvandoPagamento, setSalvandoPagamento] = useState(false)
  const [cancelando, setCancelando] = useState(false)

  useEffect(() => {
    if (agendamento) {
      setValorPago(String(agendamento.valorPago || ''))
      setFormaPagamento(agendamento.formaPagamento || 'pix')
      setMotivoCancelamento('')
    }
  }, [agendamento])

  const saldo = useMemo(() => {
    if (!agendamento) return 0
    return calcularSaldo(agendamento.valorTotal, agendamento.valorPago)
  }, [agendamento])

  if (!aberto || !agendamento) return null

  const agendamentoAtual = agendamento

  async function handleSalvarPagamento() {
    try {
      setSalvandoPagamento(true)

      await atualizarPagamento(
        agendamentoAtual.id,
        Number(valorPago || 0),
        formaPagamento
      )

      onAtualizado?.()
      onFechar()
    } catch (error) {
      console.error(error)
      alert('Erro ao atualizar pagamento.')
    } finally {
      setSalvandoPagamento(false)
    }
  }

  async function handleCancelar() {
    try {
      setCancelando(true)

      await cancelarAgendamento(
        agendamentoAtual.id,
        'empresa',
        motivoCancelamento || undefined
      )

      onAtualizado?.()
      onFechar()
    } catch (error) {
      console.error(error)
      alert('Erro ao cancelar agendamento.')
    } finally {
      setCancelando(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="flex-1 bg-black/30" onClick={onFechar} />

      <div className="w-full max-w-md overflow-y-auto bg-white p-5 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-xl font-bold">Detalhes do agendamento</h2>
          <button
            type="button"
            onClick={onFechar}
            className="rounded-md border px-3 py-1"
          >
            Fechar
          </button>
        </div>

        <div className="space-y-4">
          <div className="rounded-xl border p-4">
            <div><strong>Cliente:</strong> {agendamentoAtual.clienteNome}</div>
            <div><strong>Profissional:</strong> {agendamentoAtual.profissionalNome}</div>
            <div><strong>Data:</strong> {agendamentoAtual.data}</div>
            <div><strong>Horário:</strong> {agendamentoAtual.inicio} - {agendamentoAtual.fim}</div>
            <div><strong>Status:</strong> {agendamentoAtual.status}</div>
            <div><strong>Serviços:</strong> {agendamentoAtual.servicos.join(', ')}</div>
          </div>

          <div className="rounded-xl border p-4">
            <div><strong>Valor total:</strong> R$ {agendamentoAtual.valorTotal.toFixed(2)}</div>
            <div><strong>Valor pago:</strong> R$ {agendamentoAtual.valorPago.toFixed(2)}</div>
            <div><strong>Saldo:</strong> R$ {saldo.toFixed(2)}</div>
            <div><strong>Status pagamento:</strong> {agendamentoAtual.statusPagamento || 'nao_pago'}</div>
            <div><strong>Forma pagamento:</strong> {agendamentoAtual.formaPagamento || '-'}</div>
          </div>

          {podeEditarPagamento({ status_pagamento: agendamentoAtual.statusPagamento }) && (
            <div className="space-y-3 rounded-xl border p-4">
              <h3 className="font-semibold">Atualizar pagamento</h3>

              <input
                type="number"
                step="0.01"
                value={valorPago}
                onChange={(e) => setValorPago(e.target.value)}
                placeholder="Valor pago"
                className="w-full rounded-lg border px-3 py-2"
              />

              <select
                value={formaPagamento}
                onChange={(e) => setFormaPagamento(e.target.value)}
                className="w-full rounded-lg border px-3 py-2"
              >
                <option value="pix">Pix</option>
                <option value="dinheiro">Dinheiro</option>
                <option value="cartao">Cartão</option>
                <option value="cartao_credito">Cartão crédito</option>
                <option value="cartao_debito">Cartão débito</option>
              </select>

              <button
                type="button"
                onClick={handleSalvarPagamento}
                disabled={salvandoPagamento}
                className="w-full rounded-lg bg-black px-4 py-2 text-white disabled:opacity-50"
              >
                {salvandoPagamento ? 'Salvando...' : 'Salvar pagamento'}
              </button>
            </div>
          )}

          {agendamentoAtual.status !== 'cancelado' && (
            <div className="space-y-3 rounded-xl border p-4">
              <h3 className="font-semibold">Cancelar agendamento</h3>

              <textarea
                value={motivoCancelamento}
                onChange={(e) => setMotivoCancelamento(e.target.value)}
                placeholder="Motivo do cancelamento"
                className="min-h-[100px] w-full rounded-lg border px-3 py-2"
              />

              <button
                type="button"
                onClick={handleCancelar}
                disabled={cancelando}
                className="w-full rounded-lg bg-red-600 px-4 py-2 text-white disabled:opacity-50"
              >
                {cancelando ? 'Cancelando...' : 'Cancelar agendamento'}
              </button>
            </div>
          )}

          {agendamentoAtual.status === 'cancelado' && (
            <div className="rounded-xl border border-red-200 bg-red-50 p-4">
              <div><strong>Cancelado por:</strong> {agendamentoAtual.canceladoPor || '-'}</div>
              <div><strong>Motivo:</strong> {agendamentoAtual.motivoCancelamento || '-'}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}