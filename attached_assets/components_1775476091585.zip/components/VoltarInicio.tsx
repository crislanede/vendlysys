'use client'

import { useRouter } from 'next/navigation'

export default function VoltarInicio() {
  const router = useRouter()

  return (
    <div style={{ marginBottom: 16 }}>
      <button
        onClick={() => router.push('/inicio')}
        style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 8,
          background: '#111827',
          color: '#ffffff',
          border: 'none',
          padding: '10px 14px',
          borderRadius: 12,
          cursor: 'pointer',
          fontWeight: 700,
        }}
      >
        ← Voltar para início
      </button>
    </div>
  )
}