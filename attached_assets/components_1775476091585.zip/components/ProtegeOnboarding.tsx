'use client'

import { useEffect, ReactNode } from 'react'
import { useRouter, usePathname } from 'next/navigation'
import { useSessaoEmpresa } from '@/lib/useSessaoEmpresa'

type Props = {
  children: ReactNode
}

function onboardingConcluido(empresa: any) {
  if (!empresa) return false

  return (
    !!empresa.nome &&
    !!empresa.cor_primaria &&
    !!empresa.cor_secundaria
  )
}

export default function ProtegeOnboarding({ children }: Props) {
  const router = useRouter()
  const pathname = usePathname()
  const { empresa, loading } = useSessaoEmpresa()

  useEffect(() => {
    if (loading) return

    if (!empresa) {
      router.push('/login')
      return
    }

    const concluido = onboardingConcluido(empresa)

    // Se NÃO concluiu onboarding → força ir para onboarding
    if (!concluido && pathname !== '/onboarding') {
      router.push('/onboarding')
      return
    }

    // Se JÁ concluiu onboarding → bloqueia voltar para onboarding
    if (concluido && pathname === '/onboarding') {
      router.push('/dashboard')
      return
    }
  }, [empresa, loading, pathname, router])

  if (loading || !empresa) {
    return (
      <div style={{ padding: 24 }}>
        Carregando...
      </div>
    )
  }

  return <>{children}</>
}