"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useSessaoEmpresa } from "@/lib/useSessaoEmpresa"

export default function ProtegePagina({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const { loading, logado, empresa } = useSessaoEmpresa()

  useEffect(() => {
    if (!loading && (!logado || !empresa)) {
      router.push("/login")
    }
  }, [loading, logado, empresa, router])

  if (loading) {
    return <div style={{ padding: 24 }}>Carregando...</div>
  }

  if (!logado || !empresa) {
    return null
  }

  return <>{children}</>
}