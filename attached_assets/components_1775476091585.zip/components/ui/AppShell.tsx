'use client'

import React from 'react'
import { ui } from '@/styles/tema'

type Props = {
  children: React.ReactNode
}

export default function AppShell({ children }: Props) {
  return (
    <div style={ui.page}>
      <div style={ui.container}>
        {children}
      </div>
    </div>
  )
}