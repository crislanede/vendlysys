'use client'

import React from 'react'
import Image from 'next/image'
import { theme } from '@/styles/tema'

type HeroAction = {
  label: string
  onClick?: () => void
  href?: string
  variant?: 'primary' | 'secondary'
}

type HeroHeaderProps = {
  titulo: string
  subtitulo: string
  eyebrow?: string
  empresaNome?: string
  actions?: HeroAction[]
}

export default function HeroHeader({
  titulo,
  subtitulo,
  eyebrow = 'Sistema Premium',
  empresaNome = 'Espaço Áurea',
  actions = [],
}: HeroHeaderProps) {
  return (
    <div style={s.hero}>
      <div style={s.heroLeft}>
        <div style={s.brandRow}>
          <div style={s.logoBox}>
            <Image
              src="/logo.png"
              alt={empresaNome}
              width={102}
              height={102}
              style={{ objectFit: 'contain' }}
              priority
            />
          </div>

          <div style={s.brandTextWrap}>
            <span style={s.eyebrow}>{eyebrow}</span>
            <h1 style={s.h1}>{titulo}</h1>
            <span style={s.brandSub}>{subtitulo}</span>
          </div>
        </div>
      </div>

      {actions.length > 0 && (
        <div style={s.heroActions}>
          {actions.map((action, index) => {
            const styleBotao =
              action.variant === 'secondary' ? s.heroButtonSecondary : s.heroButtonPrimary

            if (action.href) {
              return (
                <a key={index} href={action.href} style={styleBotao}>
                  {action.label}
                </a>
              )
            }

            return (
              <button key={index} style={styleBotao} onClick={action.onClick} type="button">
                {action.label}
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}

const s: Record<string, React.CSSProperties> = {
  hero: {
    background: `linear-gradient(135deg, ${theme.colors.primary} 0%, ${theme.colors.primaryAlt} 100%)`,
    color: '#fff',
    borderRadius: 28,
    padding: '28px 32px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 20,
    flexWrap: 'wrap',
    boxShadow: theme.shadow.hero,
  },
  heroLeft: {
    display: 'grid',
    gap: 12,
  },
  brandRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 20,
    flexWrap: 'wrap',
  },
  logoBox: {
    width: 108,
    height: 108,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'transparent',
    border: 'none',
    boxShadow: 'none',
    padding: 0,
    flexShrink: 0,
  },
  brandTextWrap: {
    display: 'grid',
    gap: 3,
  },
  eyebrow: {
    fontSize: 11,
    letterSpacing: 1.8,
    textTransform: 'uppercase',
    opacity: 0.78,
    fontWeight: 700,
  },
  h1: {
    margin: 0,
    fontSize: 28,
    fontWeight: 800,
    lineHeight: 1.05,
  },
  brandSub: {
    fontSize: 13,
    color: 'rgba(255,255,255,0.78)',
    fontWeight: 500,
  },
  heroActions: {
    display: 'flex',
    gap: 12,
    flexWrap: 'wrap',
  },
  heroButtonPrimary: {
    background: theme.colors.accent,
    color: theme.colors.primary,
    border: 0,
    borderRadius: 14,
    padding: '12px 18px',
    fontWeight: 800,
    cursor: 'pointer',
    boxShadow: '0 10px 25px rgba(216,176,140,0.28)',
    textDecoration: 'none',
  },
  heroButtonSecondary: {
    background: 'rgba(255,255,255,0.08)',
    color: '#fff',
    border: '1px solid rgba(255,255,255,0.16)',
    borderRadius: 14,
    padding: '12px 18px',
    fontWeight: 700,
    cursor: 'pointer',
    backdropFilter: 'blur(6px)',
    textDecoration: 'none',
  },
}