import React from 'react'

export const theme = {
  colors: {
    bg: '#f8f5f2',
    bgSoft: '#f3ede8',
    primary: '#2d241f',
    primaryAlt: '#59463b',
    accent: '#d8b08c',
    text: '#2d241f',
    textSoft: '#7a695d',
    textMuted: '#8d7c70',
    border: '#e6d9cf',
    borderSoft: '#eee2d8',
    white: '#ffffff',
    card: 'rgba(255,255,255,0.82)',
    cardInner: '#fcfaf8',
    successBg: '#e8f6ec',
    successText: '#1f6a3d',
    warningBg: '#fff4df',
    warningText: '#8e6200',
    dangerBg: '#fdebec',
    dangerText: '#b4232d',
  },
  radius: {
    xs: 10,
    sm: 14,
    md: 16,
    lg: 18,
    xl: 24,
    xxl: 28,
    pill: 999,
  },
  shadow: {
    card: '0 15px 40px rgba(80,60,40,0.08)',
    soft: '0 10px 24px rgba(80,60,40,0.06)',
    button: '0 12px 24px rgba(45,36,31,0.18)',
    hero: '0 20px 50px rgba(45,36,31,0.18)',
  },
}

export const ui = {
  page: {
    minHeight: '100vh',
    background: `linear-gradient(180deg, ${theme.colors.bg} 0%, ${theme.colors.bgSoft} 100%)`,
    padding: 24,
    color: theme.colors.text,
  } as React.CSSProperties,

  container: {
    maxWidth: 1440,
    margin: '0 auto',
    display: 'grid',
    gap: 20,
  } as React.CSSProperties,

  card: {
    background: theme.colors.card,
    border: '1px solid rgba(255,255,255,0.72)',
    backdropFilter: 'blur(10px)',
    borderRadius: theme.radius.xl,
    padding: 22,
    boxShadow: theme.shadow.card,
  } as React.CSSProperties,

  cardInner: {
    background: theme.colors.cardInner,
    border: `1px solid ${theme.colors.borderSoft}`,
    borderRadius: theme.radius.lg,
    padding: 16,
  } as React.CSSProperties,

  sectionTitle: {
    margin: 0,
    fontSize: 22,
    fontWeight: 800,
    color: theme.colors.text,
  } as React.CSSProperties,

  sectionSub: {
    margin: 0,
    fontSize: 14,
    color: theme.colors.textSoft,
  } as React.CSSProperties,

  label: {
    fontSize: 13,
    fontWeight: 700,
    color: '#6a5a4f',
  } as React.CSSProperties,

  input: {
    width: '100%',
    borderRadius: theme.radius.md,
    border: `1px solid ${theme.colors.border}`,
    background: theme.colors.white,
    padding: '14px 16px',
    fontSize: 14,
    outline: 'none',
    color: theme.colors.text,
    boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.03)',
  } as React.CSSProperties,

  buttonPrimary: {
    border: 0,
    background: `linear-gradient(135deg, ${theme.colors.primary} 0%, ${theme.colors.primaryAlt} 100%)`,
    color: theme.colors.white,
    borderRadius: theme.radius.md,
    padding: '14px 20px',
    fontWeight: 800,
    cursor: 'pointer',
    boxShadow: theme.shadow.button,
  } as React.CSSProperties,

  buttonSecondary: {
    border: `1px solid ${theme.colors.border}`,
    background: theme.colors.white,
    color: '#4f433a',
    borderRadius: theme.radius.md,
    padding: '14px 20px',
    fontWeight: 700,
    cursor: 'pointer',
  } as React.CSSProperties,

  tabsWrap: {
    background: 'rgba(255,255,255,0.76)',
    backdropFilter: 'blur(8px)',
    border: '1px solid rgba(255,255,255,0.7)',
    borderRadius: 20,
    padding: 8,
    display: 'flex',
    gap: 8,
    flexWrap: 'wrap',
    boxShadow: '0 10px 28px rgba(100,80,60,0.06)',
  } as React.CSSProperties,

  tab: {
    border: 0,
    background: 'transparent',
    padding: '12px 18px',
    borderRadius: 14,
    cursor: 'pointer',
    color: '#6e5d52',
    fontWeight: 700,
  } as React.CSSProperties,

  tabActive: {
    border: 0,
    background: theme.colors.primary,
    padding: '12px 18px',
    borderRadius: 14,
    cursor: 'pointer',
    color: theme.colors.white,
    fontWeight: 800,
    boxShadow: '0 8px 20px rgba(45,36,31,0.16)',
  } as React.CSSProperties,
}